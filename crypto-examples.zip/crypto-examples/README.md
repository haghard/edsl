


Keytool is a key and certificate management JDK utility that helps in managing a keystore of private/public keys and associated certificates. 
Java keytool stores the keys and certificates in what is called a keystore. The Java keystore is implemented as a file by default. It protects private keys with a password.


### Links
http://tutorials.jenkov.com/java-cryptography/keytool.html
https://docs.oracle.com/javase/8/docs/technotes/guides/security/jsse/JSSERefGuide.html#CreateKeystore


https://lightbend.github.io/ssl-config/CertificateGeneration.html

https://www.47deg.com/blog/mu-rpc-securing-communications-with-mu/


SelfSignedCertificateX509
https://www.opencodez.com/java/read-x509-certificate-java-keystore.htm


https://dzone.com/articles/keytool-commandutility-to-generate-a-keystorecerti
https://dzone.com/articles/jdpr-java-data-protection-recommendations


https://blogs.oracle.com/java-platform-group/self-signed-certificates-for-a-known-community



https://github.com/rchain/rchain/tree/dev/crypto

https://dzone.com/articles/encryption-part-2-public-key-private-key-encryptio?edition=479225&utm_source=Weekly%20Digest&utm_medium=email&utm_campaign=Weekly%20Digest%202019-05-01

https://github.com/spoofzu/DeepViolet



### TO DO

Check Lazysodium

https://github.com/SwissBorg/lazysodium-java
https://github.com/terl/lazysodium-examples

https://blog.knoldus.com/how-to-encrypt-and-decrypt-files-using-gpg/