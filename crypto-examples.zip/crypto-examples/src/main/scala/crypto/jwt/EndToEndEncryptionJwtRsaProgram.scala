package crypto.jwt

import java.security.interfaces._

import com.nimbusds.jose._
import com.nimbusds.jose.crypto.{RSADecrypter, RSAEncrypter}
import com.nimbusds.jwt._

/*

  https://connect2id.com/products/nimbus-jose-jwt/examples/jwt-with-rsa-encryption

  End to end encryption example
    https://heimdalsecurity.com/blog/the-best-encrypted-messaging-apps/
    https://heimdalsecurity.com/blog/wp-content/uploads/end_to_end_encryption_infographic-1.png
    https://martin.kleppmann.com/2015/11/10/investigatory-powers-bill.html


  runMain crypto.jwt.EndToEndEncryptionJwtRsaProgram
 */
object EndToEndEncryptionJwtRsaProgram {

  def receiveAndDecrypt(msg: String, privateKey: RSAPrivateCrtKey): Unit = {
    val jwt: EncryptedJWT = EncryptedJWT.parse(msg)
    //println(jwt.getJWTClaimsSet) //null
    val decrypter = new RSADecrypter(privateKey)
    jwt.decrypt(decrypter)
    val claims = jwt.getJWTClaimsSet
    println(claims.getIssuer + " says: " + claims.getClaim(ChatUser.msgClaim))
    println("******************************************************************************************")
  }

  def encryptAndSend(sender: String, receiver: String, receiverPubKey: RSAPublicKey): String = {
    //val now = new Date()
    val jwtMessage = new JWTClaimsSet.Builder()
      .issuer(sender)
      //.subject(receiver)
      //.expirationTime(new Date(now.getTime + 1000 * 60 * 10)) // expires in 10 minutes
      //.jwtID(UUID.randomUUID.toString)
      .claim(ChatUser.msgClaim, s"hello $receiver")
      .build

    //println(jwtClaims.toJSONObject)

    // Request JWT encrypted with RSA-OAEP-256 and 128-bit AES/GCM
    val header = new JWEHeader(JWEAlgorithm.RSA_OAEP_256, EncryptionMethod.A128GCM)
    // Create the encrypted JWT object
    val jwt = new EncryptedJWT(header, jwtMessage)
    // Create an encrypter with the specified public RSA key
    val encrypter = new RSAEncrypter(receiverPubKey)
    // Do the actual encryption
    jwt.encrypt(encrypter)

    jwt.serialize
  }

  def main(args: Array[String]): Unit = {
    val alice = ChatUser.generate()
    val bob   = ChatUser.generate()

    //Bob says hello to Alice, Bob needs to access  Alice's pub key
    val msgToAlice = encryptAndSend(bob.handle.toString, alice.handle.toString, alice.pub)

    println(s"Msg:${msgToAlice.length} - $msgToAlice")
    receiveAndDecrypt(msgToAlice, alice.priv)

    //Alice says hello back, Alice needs to access Bob's  public key
    val msgToBob = encryptAndSend(alice.handle.toString, bob.handle.toString, bob.pub)
    println(s"Msg:${msgToBob.length} - $msgToBob")
    receiveAndDecrypt(msgToBob, bob.priv)
  }
}
