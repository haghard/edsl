package crypto.jwt

import java.util.Date

import com.nimbusds.jose.{JWSAlgorithm, JWSHeader}
import com.nimbusds.jose.crypto.{RSASSASigner, RSASSAVerifier}
import com.nimbusds.jose.jwk.{KeyUse, RSAKey}
import com.nimbusds.jose.jwk.gen.RSAKeyGenerator
import com.nimbusds.jwt.{JWTClaimsSet, SignedJWT}

object JwtRSAProgram2 {

  // Prepare JWT with claims set
  val chatterJWTClaims = new JWTClaimsSet.Builder()
    .issuer("https://chatter.com")
    .subject("haghard")
    .claim("chat", "**")
    .expirationTime(new Date(System.currentTimeMillis + 60 * 1000))
    .issueTime(new Date())
    .build()

  //Option 2
  //Public and private RSA JSON Web Key with metadata
  val jwkRSAKey1: RSAKey = new RSAKeyGenerator(2048)
    .keyID("auth")
    .asInstanceOf[RSAKeyGenerator]
    .keyUse(KeyUse.SIGNATURE)
    .asInstanceOf[RSAKeyGenerator]
    .generate

  val bts = jwkRSAKey1.toString.getBytes("utf-8")

  val publicKey = jwkRSAKey1.toPublicJWK
  //val privateKey = jwkRSAKey1.toPrivateKey.getEncoded

  val publicKeyBytes = publicKey.toString.getBytes("utf-8")

  val signer1 = new RSASSASigner(jwkRSAKey1)
  val signedJWT1 = new SignedJWT(
    new JWSHeader.Builder(JWSAlgorithm.RS256)
      .keyID(jwkRSAKey1.getKeyID)
      .build,
    chatterJWTClaims
  )

  signedJWT1.sign(signer1)
  val rootSighedJwt1 = signedJWT1.serialize

  // On the consumer side, parse the JWS and verify its RSA signature
  val signedJWT11 = SignedJWT.parse(rootSighedJwt1)

  val recoveredFromPK1 = RSAKey.parse(new String(publicKeyBytes))
  val verifier1        = new RSASSAVerifier(recoveredFromPK1)
  signedJWT11.verify(verifier1)
  val claims1 = signedJWT11.getJWTClaimsSet
  claims1.getIssuer
  claims1.getClaim("chat")
}
