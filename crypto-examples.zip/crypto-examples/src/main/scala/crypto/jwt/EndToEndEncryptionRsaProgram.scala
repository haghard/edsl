package crypto.jwt

import java.io.{ByteArrayInputStream, ByteArrayOutputStream}

import javax.crypto.{Cipher, CipherOutputStream}
import java.nio.charset.StandardCharsets
import java.security.{PrivateKey, PublicKey, Signature}

//runMain crypto.jwt.EndToEndEncryptionRsaProgram
object EndToEndEncryptionRsaProgram {
  val limit = 190

  val cipherName =
    //"RSA/ECB/PKCS1Padding"
    "RSA/ECB/OAEPWithSHA-256AndMGF1Padding"
  val algorithm = "SHA256withRSA"

  val cipher = Cipher.getInstance(cipherName)
  val sigAlg = Signature.getInstance(algorithm)

  //encrypted and signed
  case class Packet(content: String, sign: String)

  @scala.annotation.tailrec
  def readChunk(in: ByteArrayInputStream, out: ByteArrayOutputStream, buffer: Array[Byte]): Unit =
    in.read(buffer) match {
      case -1 ⇒ ()
      case n  ⇒
        //println("write chunk: " + n)
        out.write(buffer, 0, n)
        readChunk(in, out, buffer)
    }

  def encryptAndSend(sender: String, senderPrivKey: PrivateKey, receiver: String, receiverPubKey: PublicKey): Packet = {

    //encrypt using receiver's public key
    cipher.init(Cipher.ENCRYPT_MODE, receiverPubKey)

    val msg =
      s"$sender -> $receiver: aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
    val msgBts = msg.getBytes(StandardCharsets.UTF_8)
    println("Original msg: " + msg + " size:" + msgBts.size)

    val cipherBts =
      if (msgBts.size > limit) {
        val in  = new ByteArrayInputStream(msgBts)
        val out = new ByteArrayOutputStream()
        try readChunk(in, out, Array.ofDim[Byte](limit))
        catch {
          case scala.util.control.NonFatal(ex) ⇒
            throw new Exception("Encryption error", ex)
        } finally {
          in.close
          out.flush
          out.close
        }
        out.toByteArray
      } else
        //Data must not be longer than 190 bytes
        cipher.doFinal(msgBts)

    //sigh using sender's private key
    sigAlg.initSign(senderPrivKey)
    sigAlg.update(msgBts)
    val signatureBts = sigAlg.sign
    Packet(crypto.base64Encode(cipherBts), crypto.base64Encode(signatureBts))
  }

  def receiveAndDecrypt(msg: Packet, receiverPrivKey: PrivateKey, senderPubKey: PublicKey): Unit = {

    //decrypt using receiver's private key
    cipher.init(Cipher.DECRYPT_MODE, receiverPrivKey)

    val encBts = crypto.base64Decode(msg.content).get

    //To use doFinal data must not be longer than 190 bytes
    val decryptedBts = if (encBts.size > limit) {
      val in  = new ByteArrayInputStream(encBts)
      val out = new ByteArrayOutputStream()
      try readChunk(in, out, Array.ofDim[Byte](limit))
      catch {
        case scala.util.control.NonFatal(ex) ⇒
          throw new Exception("Decryption error", ex)
      } finally {
        in.close
        out.flush
        out.close
      }
      out.toByteArray
    } else cipher.doFinal(encBts)

    val decryptedLine = new String(decryptedBts, StandardCharsets.UTF_8)
    println("Decrypted: " + decryptedLine)

    //Verify signature using sender's public key
    sigAlg.initVerify(senderPubKey)
    sigAlg.update(decryptedBts)
    val signatureValid = sigAlg.verify(crypto.base64Decode(msg.sign).get)
    //check that the message came from a sender associated with senderPubKey
    println("Checking signature ..." + signatureValid)
  }

  def main(args: Array[String]): Unit = {
    /*val keyPairGen = KeyPairGenerator.getInstance("RSA")
    keyPairGen.initialize(2048, new SecureRandom())
    val alice = keyPairGen.generateKeyPair
    val bob = keyPairGen.generateKeyPair*/

    val alice = ChatUser.generate()
    val bob   = ChatUser.generate()

    //Alice owns Bob's public key, so she can use it to encrypt the packet
    val packToBob = encryptAndSend(alice.handle.toString, alice.priv, bob.handle.toString, bob.pub)

    println(
      "Content size: " + packToBob.content.getBytes(StandardCharsets.UTF_8).size +
      " Sign size:" + packToBob.sign.getBytes(StandardCharsets.UTF_8).size
    )

    /*
    Bob receives message from Alice and:
      1. Decrypt
      2. Check signature to make sure it came from Alice
     */
    receiveAndDecrypt(packToBob, bob.priv, alice.pub)

    //Bob owns Alice's public key, so he  can use it to encrypt the packet
    val packToAlice = encryptAndSend(bob.handle.toString, bob.priv, alice.handle.toString, alice.pub)

    println(
      "Content size: " + packToAlice.content.getBytes(StandardCharsets.UTF_8).size +
      " Sign size:" + packToAlice.sign.getBytes(StandardCharsets.UTF_8).size
    )

    /*
      Alice receives message from Bob and:
      1. Decrypt
      2. Check signature to make sure it came from Bob
     */
    receiveAndDecrypt(packToAlice, alice.priv, bob.pub)
  }
}
