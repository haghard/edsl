package crypto
package jwt

import java.math.BigInteger
import java.security.cert.X509Certificate
import java.security.interfaces.{RSAPrivateCrtKey, RSAPrivateKey, RSAPublicKey}
import java.security.spec.{PKCS8EncodedKeySpec, RSAKeyGenParameterSpec, X509EncodedKeySpec}
import java.security.{KeyFactory, KeyPairGenerator, SecureRandom}
import java.util.Date

import com.nimbusds.jose._
import com.nimbusds.jose.crypto.{RSASSASigner, RSASSAVerifier}
import com.nimbusds.jose.jwk._
import com.nimbusds.jwt._

object JwtRSAProgram {

  val ALG                         = "RSA"
  val PublicExponentUsedByArweave = new BigInteger("65537")

  //Generate 2048-bit RSA key pair in JWK format, attach some metadata
  // with the standard Java cryptographic facilities
  def generateRSAPair(
    sr: SecureRandom = new SecureRandom(),
    keySize: Int = 2048 /*4096*/
  ): (RSAPublicKey, RSAPrivateCrtKey) = {
    val kpg = KeyPairGenerator.getInstance(ALG)
    kpg.initialize(new RSAKeyGenParameterSpec(keySize, PublicExponentUsedByArweave), sr)
    val kp = kpg.generateKeyPair()
    (kp.getPublic.asInstanceOf[RSAPublicKey], kp.getPrivate.asInstanceOf[RSAPrivateCrtKey])
  }

  /*

    JSON Web Token (JWT) with RSA signature

    RSA signatures require a public and private RSA key pair, the public key
    must be made known to the JWS recipient in order to verify the signatures

    https://connect2id.com/products/nimbus-jose-jwt/examples/jwt-with-rsa-signature

   */

  def main(args: Array[String]): Unit = {

    // Prepare JWT with claims set
    val someJWTClaims = new JWTClaimsSet.Builder()
      .issuer("https://some.com")
      .subject("haghard")
      .claim("a", "rw")
      .claim("b", "r")
      .expirationTime(new Date(System.currentTimeMillis + 60 * 1000))
      .issueTime(new Date())
      .build()

    //Generate sender RSA key pair, make public key available to recipient:
    val (rsaPublicKey, rsaPrivateKey) = generateRSAPair()

    val publicKeyString = base64Encode(rsaPublicKey.getEncoded)
    println("Public key: " + publicKeyString)

    //val privateKeyBts = rsaPrivateKey.getEncoded
    val publicKeyBts = rsaPublicKey.getEncoded

    //Public and private RSA JSON Web Key (JWK) with metadata
    val jwkRSAKey: RSAKey = new RSAKey.Builder(rsaPublicKey)
      .privateKey(rsaPrivateKey)
      .keyUse(KeyUse.SIGNATURE)
      .keyID("fsa")
      .build()

    // Create RSA-signer using RSA JSON Web Key
    val signer = new RSASSASigner(jwkRSAKey)

    //Sign with RSA JSON Web Key and compute the RSA signature
    val sighedJWT = new SignedJWT(new JWSHeader(JWSAlgorithm.RS256), someJWTClaims)
    sighedJWT.sign(signer)
    val sighedJwt = sighedJWT.serialize
    println("signed-jwt :" + sighedJwt)

    // On the recipient side, parse the JWT and verify its RSA signature
    val signedJWT00 = SignedJWT.parse(sighedJwt)

    val recoveredPK0 = KeyFactory
      .getInstance(ALG)
      .generatePublic(new X509EncodedKeySpec(publicKeyBts))
      .asInstanceOf[RSAPublicKey]

    val recoveredPK = base64Decode(publicKeyString)
      .map(bts ⇒
        KeyFactory
          .getInstance(ALG)
          .generatePublic(new X509EncodedKeySpec(bts))
          .asInstanceOf[RSAPublicKey]
      )
      .get

    val verifier = new RSASSAVerifier(recoveredPK)

    //TRUE tells us that only haghard could've issued this token
    //that means that the jwt token came from the sender above
    val r = signedJWT00.verify(verifier)

    val claims = signedJWT00.getJWTClaimsSet

    println(claims.getIssuer + " " + claims.getClaim("a") + " " + claims.getClaim("b"))

    println("Verified: " + r)
  }
}
