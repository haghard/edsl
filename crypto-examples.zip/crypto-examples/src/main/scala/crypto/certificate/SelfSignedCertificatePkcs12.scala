package crypto
package certificate

import java.io.FileInputStream
import java.security.spec.X509EncodedKeySpec
import java.security.{KeyFactory, KeyStore}
import java.security.interfaces.{RSAPrivateCrtKey, RSAPublicKey}

/*

http://tutorials.jenkov.com/java-cryptography/keytool.html
https://lightbend.github.io/ssl-config/CertificateGeneration.html
https://github.com/lihaoyi/os-lib
runMain crypto.certificate.SelfSignedCertificatePkcs12

 */

object SelfSignedCertificatePkcs12 {

  val outputDir = "pkcs12-jks"
  val jksFile   = "hag.jks"

  def main(args: Array[String]) = {
    //val keyPws = "qwerty0"
    val storePws = "qwerty"
    val alias    = "hag.com"

    val wd = os.pwd
    if (os.isFile(wd / outputDir / jksFile))
      println(s"ERROR: $outputDir/$jksFile exists. Delete it first")

    /*

    Generating RSA key pair and self-signed certificate

    To create a root certificate authority that will sign the fsa.com certificate.
    The root CA certificate has a couple of additional attributes (ca:true, keyCertSign) that mark it explicitly as a CA certificate
     */
    val p = os
      .proc(
        "keytool",
        "-genkeypair",
        "-v",
        "-alias",
        alias,
        "-dname",
        "CN=fsa.com, O=Codelf Solutions, L=Spb, ST=Spb, C=RU",
        "-keystore",
        "./" + outputDir + "/" + jksFile,
        //"-keypass", keyPws,
        "-storepass",
        storePws,
        "-keyalg",
        "RSA",
        "-keysize",
        "2048", //4096
        "-ext",
        "san=dns:localhost",
        "-ext",
        "KeyUsage:critical=keyCertSign",
        "-ext",
        "BasicConstraints:critical=ca:true",
        "-deststoretype",
        "pkcs12",
        "-validity",
        "9999"
      )
      .call()

    val ec = p.exitCode
    println("keytool exitCode: " + ec)
    println("out > " + new String(p.out.bytes))
    println("err > " + new String(p.err.bytes))

    //read from jks
    val password = storePws.toCharArray

    val ks: KeyStore = KeyStore.getInstance("pkcs12")
    ks.load(new FileInputStream("./" + outputDir + "/" + jksFile), password)

    //private key
    val extractedPrivKey: RSAPrivateCrtKey =
      ks.getKey(alias, password).asInstanceOf[RSAPrivateCrtKey]

    println("Private key: " + base64Encode(extractedPrivKey.getEncoded))

    val cert = ks.getCertificate(alias)

    val pubKeyLine = base64Encode(cert.getPublicKey.getEncoded)
    println("Public key: " + pubKeyLine)

    // This method can be used to verify that the Certificate is really signed with the private key matching the expected public key.
    cert.verify(cert.getPublicKey)

    println("verify0")

    val recPubKey = base64Decode(pubKeyLine)
      .map(bts ⇒ KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(bts)).asInstanceOf[RSAPublicKey])
      .get

    cert.verify(recPubKey)
    println("verify1")

    println("Certificate: " + cert.toString)
  }
}
