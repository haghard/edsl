package crypto
package certificate

import java.io.FileInputStream
import java.security.{KeyFactory, KeyStore}
import java.security.interfaces.{RSAPrivateCrtKey, RSAPublicKey}
import java.security.spec.X509EncodedKeySpec

/*
https://www.opencodez.com/java/read-x509-certificate-java-keystore.htm

```

keytool -genkey -alias fsa  -keyalg RSA -validity 9999 -keystore fsa.jks -storetype JKS \
-dname "CN=fsa.com, O=Codelf Solutions, L=Spb, ST=Spb, C=RU" \
-ext san=dns:fsa.com,dns:FSA.COM  \
-keypass qwerty -storepass qwerty

keytool -exportcert -alias haghard.com -keystore x509-jks/haghard.jks -storepass qwerty -file x509-jks/haghard.cer


```

This will create a keystore locally called fsa-ssl-keystore with the certificate.
 */

//runMain crypto.certificate.SelfSignedCertificateX509
object SelfSignedCertificateX509 {

  val outputDir = "x509-jks"
  val jksFile   = "haghard.jks"

  def main(args: Array[String]) = {
    val storePws = "qwerty"
    val alias    = "haghard.com"

    val wd = os.pwd
    if (os.isFile(wd / outputDir / jksFile))
      println(s"ERROR: $outputDir/$jksFile exists. Delete it first")

    /*
      Generate a key store which will have our self signed X509 certificate and its corresponding private key.
     */
    val p = os
      .proc(
        "keytool",
        "-genkey",
        "-alias",
        alias,
        "-keyalg",
        "RSA",
        "-dname",
        "CN=fsa.com, O=Codelf Solutions, L=Spb, ST=Spb, C=RU",
        "-keystore",
        "./" + outputDir + "/" + jksFile,
        "-storetype",
        "JKS",
        "-keypass",
        storePws,
        "-storepass",
        storePws,
        "-keysize",
        "2048", //4096
        "-ext",
        "san=dns:localhost",
        "-ext",
        "KeyUsage:critical=keyCertSign",
        "-ext",
        "BasicConstraints:critical=ca:true",
        "-validity",
        "9999"
      )
      .call()

    val ec = p.exitCode
    println("keytool -genkey exitCode: " + ec)
    println("out > " + new String(p.out.bytes))
    println("err > " + new String(p.err.bytes))

    //exportcert cert
    val p0 = os
      .proc(
        "keytool",
        "-exportcert",
        "-alias",
        alias,
        "-keystore",
        "./" + outputDir + "/" + jksFile,
        "-storepass",
        storePws,
        "-file",
        outputDir + "/haghard.cer"
      )
      .call()
    println("keytool -exportcert exitCode: " + ec)
    println("out > " + new String(p0.out.bytes))
    println("err > " + new String(p0.err.bytes))

    //read X509 Certificate from jks
    val password     = storePws.toCharArray
    val ks: KeyStore = KeyStore.getInstance("JKS")
    ks.load(new FileInputStream("./" + outputDir + "/" + jksFile), password)

    //private key
    val extractedPrivKey: RSAPrivateCrtKey =
      ks.getKey(alias, password).asInstanceOf[RSAPrivateCrtKey]

    println("Private key: " + base64Encode(extractedPrivKey.getEncoded))

    val cert = ks.getCertificate(alias)

    val pubKeyLine = base64Encode(cert.getPublicKey.getEncoded)
    println("Public key: " + pubKeyLine)

    cert.verify(cert.getPublicKey)
    println("verify0")

    val recPubKey = base64Decode(pubKeyLine)
      .map(bts ⇒ KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(bts)).asInstanceOf[RSAPublicKey])
      .get

    cert.verify(recPubKey)
    println("verify1")

    println("Certificate: " + cert.toString)
  }
}
