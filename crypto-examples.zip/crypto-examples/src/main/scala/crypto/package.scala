import java.nio.ByteBuffer
import java.security.MessageDigest
import java.util.{Base64, UUID}

import scala.util.Try
import org.bouncycastle.crypto.digests.Blake2bDigest

package object crypto {

  //com.nimbusds.jose.util.Base64URL.encode()

  def base64Encode(bs: Array[Byte]): String =
    new String(Base64.getUrlEncoder.withoutPadding.encode(bs))

  def base64Decode(s: String): Option[Array[Byte]] =
    Try(Base64.getUrlDecoder.decode(s)).toOption

  def sha256(bts: Array[Byte]): Array[Byte] =
    MessageDigest.getInstance("SHA-256").digest(bts)

  def blake2bHash(input: Array[Byte]): Array[Byte] = {
    val digestFn = new Blake2bDigest(256)
    digestFn.update(input, 0, input.length)
    val res = new Array[Byte](32)
    digestFn.doFinal(res, 0)
    res
  }

  /** Return a nicely formatted byte string
    */
  def bytes2Hex(bytes: Array[Byte]): String = {
    val sb = new StringBuilder
    for (b ← bytes)
      sb.append(String.format("%02X ", b: java.lang.Byte))
    sb.toString
  }

  def hex2bytes(hex: String): Array[Byte] =
    hex
      .replaceAll("[^0-9A-Fa-f]", "")
      .sliding(2, 2)
      .toArray
      .map(Integer.parseInt(_, 16).toByte)

  private[crypto] val HexArray = "0123456789ABCDEF".toCharArray

  /** Converts this hash to a hex encoded string */
  def bytes2Hex2(bytes: Array[Byte]): String = {
    // from https://stackoverflow.com/questions/9655181/how-to-convert-a-byte-array-to-a-hex-string-in-java
    val hexChars = new Array[Char](bytes.length * 2)
    var j        = 0
    while (j < bytes.length) {
      val v = bytes(j) & 0xff
      hexChars(j * 2) = HexArray(v >>> 4)
      hexChars(j * 2 + 1) = HexArray(v & 0x0f)
      j += 1
    }
    new String(hexChars)
  }

  /** Converts this hash to a hex encoded string */
  def bytes3Hex2(bytes: Array[Byte]): String = {
    val buf = new StringBuilder(bytes.length * 2)
    bytes.foreach { b ⇒
      buf.append(HexArray((b & 0xf0) >> 4))
      buf.append(HexArray(b & 0x0f))
    }
    buf.toString
  }

  def hex2bytes2(hexString: String): Array[Byte] = {
    // https://stackoverflow.com/questions/140131/convert-a-string-representation-of-a-hex-dump-to-a-byte-array-using-java
    val len  = hexString.length
    val data = new Array[Byte](len / 2)
    var i    = 0
    while (i < len) {
      data(i / 2) = ((Character.digit(hexString.charAt(i), 16) << 4) +
        Character.digit(hexString.charAt(i + 1), 16)).toByte
      i += 2
    }

    data
  }

  def uuidToBytes(uuid: UUID): Array[Byte] = {
    val bb = ByteBuffer.wrap(Array.ofDim[Byte](16))
    bb.putLong(uuid.getMostSignificantBits)
    bb.putLong(uuid.getLeastSignificantBits)
    bb.array
  }

  def bytesToUUID(bytes: Array[Byte]): UUID = {
    val bb   = ByteBuffer.wrap(bytes)
    val high = bb.getLong
    val low  = bb.getLong
    new UUID(high, low)
  }

  def resource[A <: { def close(): Unit }, B](resource: A)(f: A ⇒ B): B =
    try f(resource)
    finally resource.close()
}
