package crypto

import java.util
import java.security.SecureRandom

import org.spongycastle.crypto.engines.RSAEngine
import org.spongycastle.crypto.signers.PSSSigner
import org.spongycastle.crypto.digests.SHA256Digest
import java.security.interfaces.{RSAPrivateCrtKey, RSAPublicKey}

import org.spongycastle.crypto.params.{ParametersWithRandom, RSAKeyParameters, RSAPrivateCrtKeyParameters}

/*

RSA (Rivest–Shamir–Adleman) is one of the first public-key cryptosystems and is widely used for secure data transmission.
In such a cryptosystem, the encryption key(public) is public and it is different from the decryption key(private) which is kept secret (private).
In RSA, this asymmetry is based on the practical difficulty of the factorization of the product of two large prime numbers,
the "factoring problem".

 */
package object rsa {

  class Signature(val bytes: Array[Byte]) extends Base64EncodedBytes

  object Signature {
    def fromEncoded(s: String): Option[Signature] =
      base64Decode(s).map(new Signature(_))
  }

  case class SignedDocument[T](data: T, sign: Signature)

  abstract class Base64EncodedBytes {

    def bytes: Array[Byte]

    def size: Int = bytes.size

    final override def toString: String =
      base64Encode(bytes)

    override def equals(that: Any): Boolean = that match {
      case bs: Base64EncodedBytes ⇒ bs.bytes.sameElements(bytes)
      case _                      ⇒ false
    }

    override def hashCode(): Int = util.Arrays.hashCode(bytes)
  }

  trait Signable {
    def signingBts: Array[Byte]
  }

  object Signable {
    implicit class SignableSyntax[T <: Signable](t: T) {
      def sign(priv: RSAPrivateCrtKey): SignedDocument[T] = {
        val sigBts = t.signingBts
        val params = new RSAPrivateCrtKeyParameters(
          priv.getModulus,
          priv.getPublicExponent,
          priv.getPrivateExponent,
          priv.getPrimeP,
          priv.getPrimeQ,
          priv.getPrimeExponentP,
          priv.getPrimeExponentQ,
          priv.getCrtCoefficient
        )

        val signer = new PSSSigner(new RSAEngine, new SHA256Digest, 20)
        signer.init(false, new ParametersWithRandom(params, new SecureRandom()))
        signer.update(sigBts, 0, sigBts.length)
        SignedDocument(t, new Signature(signer.generateSignature))
      }
    }

    implicit class VerifiableSyntax[T <: Signable](sd: SignedDocument[T]) {
      def verify(pub: RSAPublicKey): Boolean = {
        val sigBts = sd.signingBts
        val signer = new PSSSigner(new RSAEngine, new SHA256Digest, 20)
        signer.init(true, new RSAKeyParameters(false, pub.getModulus, pub.getPublicExponent))
        signer.update(sigBts, 0, sigBts.length)
        signer.verifySignature(sd.sign.bytes)
      }
    }

    implicit def castSignable[T](st: SignedDocument[T]): T = st.data
  }

  object UnsignedBigInt {
    def ofBigEndianBytes(bs: Array[Byte]): Option[BigInt] =
      if (bs.isEmpty) None else Some(BigInt(0.toByte +: bs))

    def toBigEndianBytes(bi: BigInt): Array[Byte] = {
      val bs = bi.toByteArray
      if (bs.length > 1 && bs.head == 0.toByte) bs.tail else bs
    }
  }

  case class SignableData(s: String) extends Signable {
    override def signingBts: Array[Byte] = s.getBytes
  }
}
