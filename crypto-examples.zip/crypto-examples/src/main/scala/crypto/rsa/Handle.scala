package crypto
package rsa

import java.security.interfaces.RSAKey

import scala.util.Try

class Handle protected (val bytes: Array[Byte]) extends Base64EncodedBytes

object Handle {

  def apply(bs: Array[Byte]): Try[Handle] = Try(new Handle(bs))

  def fromEncoded(s: String): Option[Handle] =
    base64Decode(s).map(new Handle(_))

  def ofModulus(n: BigInt): Handle =
    new Handle(sha256(UnsignedBigInt.toBigEndianBytes(n)))

  def ofKey(k: RSAKey): Handle = ofModulus(k.getModulus)
}
