package crypto.aes

import java.io.{ByteArrayInputStream, ByteArrayOutputStream}

import javax.crypto.spec.IvParameterSpec
import javax.crypto.{Cipher, CipherInputStream}

import scala.annotation.tailrec
import scala.util.control.NonFatal

class Decrypter(secretKey: javax.crypto.SecretKey, algorithm: String) {

  def decrypt(content: Array[Byte], bufferSize: Int = 1024): Array[Byte] = {
    val cipher  = Cipher.getInstance(algorithm)
    val ivBytes = Array.ofDim[Byte](16)
    val buffer  = new Array[Byte](bufferSize)
    val in      = new ByteArrayInputStream(content)

    in.read(ivBytes)
    cipher.init(Cipher.DECRYPT_MODE, secretKey, new IvParameterSpec(ivBytes))

    val cipherIn = new CipherInputStream(in, cipher)
    val out      = new ByteArrayOutputStream()

    @tailrec def readChunk(): Unit = cipherIn.read(buffer) match {
      case -1 ⇒ ()
      case n  ⇒
        //println("write chunk: " + n)
        out.write(buffer, 0, n)
        readChunk()
    }

    try readChunk()
    catch {
      case NonFatal(ex) ⇒
        throw new Exception("Decryption error", ex)
    } finally {
      in.close
      cipherIn.close
      out.flush
      out.close
    }
    out.toByteArray
  }
}
