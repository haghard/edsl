package crypto.aes

import java.security.{KeyStore, SecureRandom}
import java.nio.file.{Files, Paths}
import java.io.{FileInputStream, FileOutputStream}
import java.math.BigInteger
import java.security.cert.CertificateException
import java.util.Date

import javax.crypto.{Cipher, KeyGenerator}
import org.bouncycastle.asn1.x500.X500Name
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo
import org.bouncycastle.cert.X509v3CertificateBuilder
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder
import org.bouncycastle.jce.provider.BouncyCastleProvider
import java.security.KeyPair
import java.time.LocalDate
import java.time.ZoneOffset
import java.time.temporal.ChronoUnit

/*

  Symmetric cryptography

  The Advanced Encryption Standard, or AES, is a symmetric block cipher chosen by the U.S.
  government to protect classified information and is implemented in software and hardware
  throughout the world to encrypt sensitive data.


  https://www.baeldung.com/java-cipher-input-output-stream
  https://www.baeldung.com/java-keystore

  https://www.tutorialspoint.com/java_cryptography/java_cryptography_keygenerator.htm
  https://github.com/eugenp/tutorials/blob/master/core-java-modules/core-java-security/src/test/java/com/baeldung/keystore/JavaKeyStoreUnitTest.java
  http://stackoverflow.com/a/21952301#1#L0

 */

//runMain crypto.aes.AESProgram
object AESProgram {

  val ALGORITHM = "AES"

  val CIPHER = "AES/CBC/PKCS5Padding" //AES

  val jksFileName = "haghard-secret.jks"
  val jksFilePath = "./jks/" + jksFileName

  val keyEntryName = "haghard-secret"

  val jksPassword = "qwerty"

  def generateSymmetricKeyAndPutItInJKS: Unit = {

    println("deleteIfExists: " + Files.deleteIfExists(Paths.get(jksFilePath)))

    val secretKey: javax.crypto.SecretKey = KeyGenerator.getInstance(ALGORITHM).generateKey
    //OR

    /*val secureRandom = new SecureRandom()
    val key = Array.ofDim[Byte](16)
    secureRandom.nextBytes(key)
    val secKey: javax.crypto.SecretKey = new javax.crypto.spec.SecretKeySpec(key, Alg)*/

    //create key-store with a Symmetric Key (AES)
    val pwdArray     = jksPassword.toCharArray()
    val ks: KeyStore = KeyStore.getInstance("pkcs12")

    //We tell KeyStore to create a new one by passing null as the first parameter
    ks.load(null, pwdArray)

    //Saving a Symmetric Key
    val secret   = new KeyStore.SecretKeyEntry(secretKey)
    val password = new KeyStore.PasswordProtection(pwdArray)

    ks.setEntry(keyEntryName, secret, password)

    crypto.resource(new FileOutputStream(jksFilePath)) { fos ⇒
      ks.store(fos, pwdArray)
    }
  }

  def main(args: Array[String]): Unit = {

    println("MaxAllowedKey: " + Cipher.getMaxAllowedKeyLength(ALGORITHM))

    generateSymmetricKeyAndPutItInJKS

    val jksFile = Paths.get(jksFilePath)

    println("Load jks file from:  " + jksFile)
    println("jks exists:" + Files.exists(jksFile))

    //symmetric
    val password     = jksPassword.toCharArray
    val ks: KeyStore = KeyStore.getInstance("pkcs12")
    ks.load(new FileInputStream(jksFilePath), password)

    //ks.aliases()

    val secretKey: javax.crypto.SecretKey =
      ks.getKey(keyEntryName, password).asInstanceOf[javax.crypto.SecretKey]

    val encrypter = new Encrypter(secretKey, CIPHER)
    val decrypter = new Decrypter(secretKey, CIPHER)

    val content =
      "bla-bla-bla-bla-bla-bla-bla-bla-bla-bla-bla-bla-bla-bla-bla-bla-bla-bla-blabla-bla-bla-bla-bla-blabla-bla-bla-bla-bla-bla"
    val dataBts = content.getBytes
    val encData = encrypter.encrypt(dataBts)
    println("OrgSize:" + dataBts.size + " EncSize:" + encData.size)

    println("Encrypted base64: " + java.util.Base64.getEncoder.encodeToString(encData))
    println("Encrypted hex : " + crypto.bytes2Hex(encData))

    val originalData = decrypter.decrypt(encData)

    println("Decrypted: " + new String(originalData))

    println("eq: " + (content == new String(originalData)))
  }

  @throws[CertificateException]
  def generateCertificate(keyPair: KeyPair): java.security.cert.Certificate = {
    val name          = new X500Name("cn=Annoying Wrapper")
    val subPubKeyInfo = SubjectPublicKeyInfo.getInstance(keyPair.getPublic.getEncoded)
    val start         = new Date()
    val until         = Date.from(LocalDate.now.plus(365, ChronoUnit.DAYS).atStartOfDay.toInstant(ZoneOffset.UTC))
    val builder = new X509v3CertificateBuilder(
      name,
      new BigInteger(10, new SecureRandom()), //Choose something better for real use
      start,
      until,
      name,
      subPubKeyInfo
    )
    val signer =
      new JcaContentSignerBuilder("SHA256WithRSA").setProvider(new BouncyCastleProvider).build(keyPair.getPrivate)
    val holder = builder.build(signer)
    val cert   = new JcaX509CertificateConverter().setProvider(new BouncyCastleProvider).getCertificate(holder)
    cert
  }

}
