package crypto.aes

import java.io.{ByteArrayInputStream, ByteArrayOutputStream}
import javax.crypto.{Cipher, CipherOutputStream}

import scala.annotation.tailrec
import scala.util.control.NonFatal

/*
The idea that the public key can be shared for access to anyone over untrusted networks,
who then encrypts messages using their own private key. The owner of the public key can then decrypt the message using
their own private key, enabling the two to talk.
 */
final class Encrypter(secretKey: javax.crypto.SecretKey, alg: String) {

  @tailrec private final def readByChunk(in: ByteArrayInputStream, out: CipherOutputStream, buffer: Array[Byte]): Unit =
    in.read(buffer) match {
      case -1 ⇒ ()
      case n  ⇒
        //println("read chunk: " + n)
        out.write(buffer, 0, n)
        readByChunk(in, out, buffer)
    }

  def encrypt(content: Array[Byte], bufferSize: Int = 1024): Array[Byte] = {
    val cipher = Cipher.getInstance(alg)
    cipher.init(Cipher.ENCRYPT_MODE, secretKey)
    val initBytes = cipher.getIV
    val in        = new ByteArrayInputStream(content)
    val out       = new ByteArrayOutputStream()
    val cipherOut = new CipherOutputStream(out, cipher)

    try {
      out.write(initBytes)
      readByChunk(in, cipherOut, new Array[Byte](bufferSize))
    } catch {
      case NonFatal(ex) ⇒
        throw new Exception("Encryption error", ex)
    } finally {
      if (out != null) {
        out.flush
        out.close
      }
      if (cipherOut != null) {
        cipherOut.flush
        cipherOut.close
      }
    }
    //string pers
    //java.util.Base64.getEncoder().encodeToString(out.toByteArray)
    out.toByteArray
  }
}
