package crypto.hashing

import java.util.Base64
import javax.crypto.spec.PBEKeySpec
import javax.crypto.SecretKeyFactory

//runMain crypto.hashing.PasswordBasedKeyDerivationProgram
object PasswordBasedKeyDerivationProgram {

  //Hashing is used to produce encrypted credentials. Works like bcrypt
  //Given user's password and salt we generate a hash so that later
  //when the user comes back we could generate new hash and compare with the prev generated.
  def main(args: Array[String]): Unit = {

    //Use Password Based Key Derivation (PBKDF2) to produce a hash of information that should be secret and harder to precompute
    val password   = "uNRNATDQs2mtVMLJeXPHTTUFRoBdRptmieqKnAnN"
    val salt       = "haghard@gmail.com"
    val iterations = 32

    val keySpec = new PBEKeySpec(password.toCharArray, salt.getBytes, iterations, 512)

    val cipher = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")

    val hashedCreds = cipher.generateSecret(keySpec).getEncoded

    println("Hash size: " + hashedCreds.size)
    println("Base64 encoded: " + Base64.getEncoder.encodeToString(hashedCreds))
    //println("Hex encoded: " +  crypto.bytes2Hex(hashedCreds))
    println("The SHA-256 value salted with PBKDF2 is " + crypto.bytes2Hex(hashedCreds))

    import com.roundeights.hasher.Implicits._
    val hashMe = "Some String"
    hashMe.salt("sweet").md5.hex
  }
}
