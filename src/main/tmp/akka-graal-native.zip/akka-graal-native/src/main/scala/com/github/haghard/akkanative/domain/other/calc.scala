package com.github.haghard.akkanative.domain.other

import scala.annotation.implicitNotFound


object Program {

  //https://medium.com/@yevgennerush/part-1-application-of-literal-and-dependent-object-types-in-scala-2-13-62dbe4493dce
  trait Func[I, O] {
    type Input = I
    type Output = O

    def eval: Input => Output
  }

  @implicitNotFound("LiteralFunc[${T}] not found")
  trait LiteralFunc[T <: String with Singleton] {
    type Input
    type Output
    val expr: Func[Input, Output]
  }

  type OPS[T <: String with Singleton, I, O] =
    LiteralFunc[T] {
      type Input = I
      type Output = O
    }

  def mk[T <: String with Singleton : ValueOf, I, O](f: I => O): OPS[T, I, O] =
    new LiteralFunc[T] {
      type Input = I
      type Output = O
      val expr = new Func[Input, Output] {
        val eval: Input => Output = (i: I) => f(i)
      }
    }


  val AddDoublesOp: String = "add_doubles"
  implicit val _0: OPS[AddDoublesOp.type, (Double, Double), Double] = mk(x => x._1 + x._2)

  
  implicit val addInts: OPS["add_ints", (Int, Int), Int] = mk(x => x._1 + x._2)
  implicit val addInts2: OPS["add_int_dbl", (Int, Double), Double] = mk(x => x._1 + x._2)

  implicit val subtract: OPS["subtract", (Int, Int), Int] = mk(x => x._1 - x._2)
  implicit val multiply: OPS["multiply", (Int, Int), Int] = mk(x => x._1 * x._2)
  implicit val divide: OPS["divide", (Int, Int), Int] = mk(x => x._1 / x._2)


  def expr[T <: String with Singleton](implicit p: LiteralFunc[T]): Func[p.Input, p.Output] =
    p.expr

  def expr(opName: String)(implicit p: LiteralFunc[opName.type]): Func[p.Input, p.Output] = p.expr

  expr("multiply").eval((6, 2))

  expr["multiply"].eval((6, 2))
  expr["divide"].eval((6, 2))

  expr["add_ints"].eval((6, 4))

  expr["add_int_dbl"].eval((6, 1.4))

  expr["subtract"].eval((6, 2))

  expr[AddDoublesOp.type].eval((6.67, 2.91))

  //expr("add_doubles").eval((6.67, 2.91))

}