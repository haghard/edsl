package com.github.haghard.akkanative.domain.diff

//import com.github.haghard.akkanative.domain.diff.Domain.AccessorBuilder2

import zio.schema.{DynamicValue, Patch, StandardType}

import scala.annotation.nowarn

/*
  https://github.com/domdorn/zio-schema-example

*/

object Domain {

  import zio.schema.{DeriveSchema, Schema}
  //import zio.schema.syntax._

  /*
  import zio._
  import zio.schema.Schema._
  import zio.schema._
  */

  sealed trait PaymentMethod //Wire ACH

  object PaymentMethod {
    final case class CreditCard(number: String, expirationMonth: Int, expirationYear: Int) extends PaymentMethod
    final case class WireTransfer(accountNumber: String, bankCode: String) extends PaymentMethod
    implicit val Schema: Schema[PaymentMethod] = DeriveSchema.gen[PaymentMethod]
  }

  sealed trait PaymentMethod2 //Wire ACH

  object PaymentMethod2 {
    final case class CreditCard(number: String, expirationMonth: Int, expirationYear: Int) extends PaymentMethod2
    final case class WireTransfer(accountNumber: String, bankCode: Option[String]) extends PaymentMethod2
    final case class ACH(accountNumber: String, bankCode: String) extends PaymentMethod2
    implicit val Schema: Schema[PaymentMethod2] = DeriveSchema.gen[PaymentMethod2]
  }

  val a = PaymentMethod.CreditCard("1111", 1, 2001)
  //val b = PaymentMethod.CreditCard("2222", 2, 2001)
  val b = PaymentMethod.WireTransfer("12345", "awe")

  val a2 = PaymentMethod2.CreditCard("1111", 1, 2001)
  val b2 = PaymentMethod2.WireTransfer("12345", Some("sfdsfas"))

  //PaymentMethod.Schema.ast
  val a2bPatch: Patch[PaymentMethod] = PaymentMethod.Schema.diff(a, b)
  val b0 = PaymentMethod.Schema.patch(a, a2bPatch)

  val b2aPatch = PaymentMethod.Schema.diff(b, a)
  val a0 = PaymentMethod.Schema.patch(b, b2aPatch)

  PaymentMethod.Schema
    //.migrate()
    .coerce(PaymentMethod2.Schema)


  PaymentMethod2.Schema.coerce(PaymentMethod.Schema).getOrElse(throw new Exception("Boom!!!"))
  PaymentMethod2.Schema.migrate(PaymentMethod.Schema).getOrElse(throw new Exception("Boom!!!"))
  //gives you this Left(value = "Failed to update leaf node at path ACH: Cannot remove instantiated case")
  //but if you want customizable errors then you
  val v1Tov2: Schema[PaymentMethod2] =
    PaymentMethod.Schema.transformOrFail(
      { v1: PaymentMethod =>
        Right(v1 match {
          case c: PaymentMethod.CreditCard => PaymentMethod2.CreditCard(c.number, c.expirationMonth, c.expirationYear)
          case w: PaymentMethod.WireTransfer => PaymentMethod2.WireTransfer(w.accountNumber, Some(w.bankCode))
        })
      }, { v2: PaymentMethod2 =>
        v2 match {
          case c: PaymentMethod2.CreditCard => Right(PaymentMethod.CreditCard(c.number, c.expirationMonth, c.expirationYear))
          case w: PaymentMethod2.WireTransfer => Right(PaymentMethod.WireTransfer(w.accountNumber, w.bankCode.getOrElse("0000")))
          case _: PaymentMethod2.ACH => Left(s"It's impossible to convert ${classOf[PaymentMethod2.ACH].getSimpleName()} term to PaymentMethod ")
        }
      }
    )

  val mig0 = v1Tov2.migrate(PaymentMethod.Schema).getOrElse(throw new Exception("Boom!!!"))
  //PaymentMethod2.Schema.migrate(PaymentMethod.Schema).getOrElse(throw new Exception("Boom!!!"))
  mig0.apply(PaymentMethod2.ACH("13","999"))

  //v1Tov2.<+>()

  val v2Tov1: Schema[PaymentMethod] =
    PaymentMethod2.Schema.transformOrFail(
      { v1: PaymentMethod2 =>
        v1 match {
          case c: PaymentMethod2.CreditCard => Right(PaymentMethod.CreditCard(c.number, c.expirationMonth, c.expirationYear))
          case w: PaymentMethod2.WireTransfer => Right(PaymentMethod.WireTransfer(w.accountNumber, w.bankCode.getOrElse("0000")))
          case _: PaymentMethod2.ACH => Left(s"We don't support ${classOf[PaymentMethod2.ACH].getName()}")
        }
      }, { v2: PaymentMethod =>
        Right(v2 match {
          case c: PaymentMethod.CreditCard => PaymentMethod2.CreditCard(c.number, c.expirationMonth, c.expirationYear)
          case w: PaymentMethod.WireTransfer => PaymentMethod2.WireTransfer(w.accountNumber, Some(w.bankCode))
        })
      }
    )

  v2Tov1.migrate(PaymentMethod2.Schema).getOrElse(throw new Exception("Boom !")).apply(a)

  //Automatic migration
  val f = PaymentMethod.Schema.migrate(PaymentMethod2.Schema).getOrElse(throw new Exception("Boom!!!"))
  f.apply(a)
  f.apply(b)
  PaymentMethod.Schema.serializable

  val f1 = PaymentMethod2.Schema.migrate(PaymentMethod.Schema).getOrElse(throw new Exception("Boom!!!"))
  f1.apply(a2)
  f1.apply(b2)

  PaymentMethod.Schema.migrate(PaymentMethod2.Schema) match {
    case Right(f) =>
      f.apply(???)
    /*v1 match {
      case c: PaymentMethod.CreditCard => PaymentMethod2.CreditCard(c.number, c.expirationMonth, c.expirationYear))
      case w: PaymentMethod.WireTransfer => PaymentMethod.WireTransfer(w.accountNumber, w.bankCode))
    }*/
    case Left(err) => Left(err)
  }

  sealed trait Accessor[S, A] { self =>
    def apply(value: S): Either[String, A]
    def widen[A1](implicit ev: A <:< A1) =
      //self.asInstanceOf[Accessor[A1, A1]]
      self.asInstanceOf[Accessor[S, A1]]
  }
  object Accessor {
    final case class Eq[S, A](s: Accessor[S, A], v: A) extends Accessor[S, Boolean] {

      def go(schema: Schema.Record[S], rec: DynamicValue.Record, path: List[String]): Either[String, Boolean] = {
        path.foreach { p =>
          println(p + " : " + rec.values.getOrElse(p, "none"))
        }

        val r =
        path.collectFirst { case p if rec.values.contains(p) =>
          val dv = rec.values.apply(p)
          println(dv)
          val from = schema.fromDynamic(dv)
          println(from)
          from
        }.get


        r.asInstanceOf[Either[String, Boolean]]
        /*path.map { p =>
          if(rec.values.contains(p))
            schema.fromDynamic(rec.values(p))
        }.head.asInstanceOf[Either[String, Boolean]]*/
      }

      def apply(value: S): Either[String, Boolean] = {
        s match {
          case _:Accessor.Eq[_,_] =>
            Left("Expected Selector")

          case Selector(schema, path) =>
            schema.toDynamic(value) match {
              case rec0: DynamicValue.Record =>
                rec0.values(path) match {
                  case p: DynamicValue.Primitive[A] /*@unchecked*/ =>
                    println(s"$p == $v")
                    Right(p.standardType.compare(p.value, v) == 0)
                  case other =>
                    Left(s"Expected DynamicValue.Primitive but ${other.toString}")
                }
                /*schema.fromDynamic(rec0).map { r =>
                  println(s"$r  $v")
                  r == v
                  //schema.ordering.compare(r, v) == 0
                }*/
              case other  =>
                Left(other.toString)
            }

            /*schema.toDynamic(value) match {
              case rec: DynamicValue.Record =>
                val f = path.tail.head
                rec.values(f) match {
                  case rec0: DynamicValue.Primitive[_] =>
                    schema.fromDynamic(rec0).map { record =>
                      println(s"$record  $v")
                      record == v
                    }
                  case other => Left(s"$f / $other")
                }
              case _ => Left("!!!")
            }*/
        }
      }
    }

    final case class Selector[S, A](
      schema: Schema.Record[S], path: String  //, segments: List[Schema.Field[_, _]]
    ) extends Accessor[S, A] { self =>

      def apply(value: S): Either[String, A] = ???
      /*{

        def go(rec: DynamicValue.Record, path: List[String]): Either[String, A] = {
          path.map { p =>
            //rec.values.contains(p)
            schema.fromDynamic(rec.values(p))
          }.head.asInstanceOf[Either[String, A]]
        }

        schema.toDynamic(value) match {
          case rec@DynamicValue.Record(_, _) => go(rec, path)
          case _=>  Left("!!!")
        }
      }*/

      def ~>[A1](that: Selector[S, A1]): Selector[S, A1] =
        self.copy(path = self.path ++ that.path)

      def /[A1](that: Selector[A, A1]): Selector[A, A1] = {
        //self.schema
        //self.copy(path = self.path ++ that.path, segment = that.segment)
        that.copy(path = that.path)
      }

      /*def =:=[A1](that: A1)(implicit ev: A <:< A1): Accessor[/*S*/A1, Boolean] =
        Accessor.Eq(self.widen, that)*/

      def =:=[A1](that: A1)(implicit ev: A <:< A1): Accessor[S, Boolean] =
        Accessor.Eq(self.widen, that)

      /*def =:=[A1](that: A1)(implicit ev: A <:< A1): Accessor[S, Boolean] =
        Accessor.Eq(self.widen, that)*/

      //def >>[A1 >: A](that: A1): Accessor[S, Seq[A]] = ???
      def >>[A1](that: A1)(implicit ev: A <:<  A1): Accessor[S, Seq[A]] = ???

      def <<[A1](that: A1)(implicit ev: A <:<  A1): Accessor[S, Seq[A]] = ???

    }
  }

  object AccessorBuilderSelector extends zio.schema.AccessorBuilder {
    override type Lens[F, S, A] = Accessor.Selector[S, A]
    override type Prism[F, S, A] = Unit
    override type Traversal[S, A] = Unit

    override def makeLens[F, S, A](schema: Schema.Record[S], field: Schema.Field[S, A]) =
      Accessor.Selector(schema, field.name)

    override def makePrism[F, S, A](sum: Schema.Enum[S], term: Schema.Case[S, A]): Unit = ()
    override def makeTraversal[S, A](collection: Schema.Collection[S, A], element: Schema[A]): Unit = ()
  }

  sealed trait Plan[S, R] {
    self =>

    import Plan._

    private def widen[R1](implicit ev: R <:< R1) = self.asInstanceOf[Plan[S, R1]]

    def find[R1](p: Plan[S, Boolean])(implicit ev: R <:< R1): Plan[S, Option[R1]] =
      Plan.Find(self.widen, p)

    def filter[R1](p: Plan[S, Seq[R1]])(implicit ev: R <:< R1): Plan[S, Seq[R1]] =
      Plan.Filter(self.widen, p)

    /*def project[R1,R2](proj: Plan[R1, R2])(implicit ev: R <:< Seq[R1]): Plan[S, Seq[R1]] =
      Plan.Projection(self.widen, proj)
    */

  }

  object Plan {
    final case class Find[Q, R](self: Plan[Q, R], predicate: Plan[Q, Boolean]) extends Plan[Q, Option[R]]

    final case class Filter[Q, R](self: Plan[Q, R], predicate: Plan[Q, Seq[R]]) extends Plan[Q, Seq[R]]

    //final case class Projection[Q,R,R1](self: Plan[Q, Seq[R]], predicate: Plan[R, R1]) extends Plan[Q, Seq[R]]

    final case class Eq[S, R](self: Plan[S, R], v: R) extends Plan[S, Boolean]

    final case class GreaterThan[S, R](self: Plan[S, R], v: R) extends Plan[S, Seq[R]]

    final case class LessThan[S, R](self: Plan[S, R], v: R) extends Plan[S, Seq[R]]

    final case class Like[S, R](self: Plan[S, R], v: R) extends Plan[S, Seq[R]]

    final case class Max[S, R](self: Plan[S, R]) extends Plan[S, Seq[R]]

    final case class Avg[S, R](self: Plan[S, R])(implicit ev: Numeric[R]) extends Plan[S, Seq[R]]
  }

  case class PlanSelector[S, A](product: Schema.Record[S], term: Schema.Field[S, A]) extends Plan[S, A] {
    self =>

    def =:=(that: A): Plan[S, Boolean] = Plan.Eq(self, that)

    def >>(that: A): Plan[S, Seq[A]] = Plan.GreaterThan(self, that)

    def <<(that: A): Plan[S, Seq[A]] = Plan.LessThan(self, that)

    def like_%(that: A)(implicit ev: A =:= String): Plan[S, Seq[A]] = Plan.Like(self, that)

    def max: Plan[S, Seq[A]] = Plan.Max(self)

    def avg(implicit ev: Numeric[A]): Plan[S, Seq[A]] = Plan.Avg(self)(ev)
    //def avg[A: Numeric]: Plan[S, Seq[A]] = Plan.Avg(self)
  }

  object AccessorBuilder2 extends zio.schema.AccessorBuilder {
    override type Lens[F, S, A] = PlanSelector[S, A]
    override type Prism[F, S, A] = Unit
    override type Traversal[S, A] = Unit


    override def makeLens[F, S, A](product: Schema.Record[S], term: Schema.Field[S, A]) = {
      PlanSelector(product, term)
    }

    override def makePrism[F, S, A](sum: Schema.Enum[S], term: Schema.Case[S, A]): Unit = ???

    override def makeTraversal[S, A](collection: Schema.Collection[S, A], element: Schema[A]): Unit = ???
  }


  final case class User(id: Long, name: String, age: Int)

  object User {
    private val schema: Schema[User] = DeriveSchema.gen[User]

    val (id: zio.optics.Lens[User, Long], name: zio.optics.Lens[User, String],
      age: zio.optics.Lens[User, Int]) = schema.makeAccessors(zio.schema.optics.ZioOpticsBuilder) : @unchecked
  }

  //final case class UserSchema(Id: PlanSelector[User, Long], Name: PlanSelector[User, String], Age: PlanSelector[User, Int])

  final case class User2(id: Long, name: String, age: Int)

  object User2 {
    private val schema: Schema[User2] = DeriveSchema.gen[User2]
    /*@nowarn val S: UserSchema = {
      val (id: PlanSelector[User, Long], name: PlanSelector[User, String], age: PlanSelector[User, Int]) =
        schema.makeAccessors(AccessorBuilder2)
      UserSchema(id, name, age)
    }*/

    val (id: PlanSelector[User, Long], name: PlanSelector[User, String], age: PlanSelector[User, Int]) =
      schema.makeAccessors(AccessorBuilder2): @unchecked

  }


  final case class User3(id: Long, name: String, age: Int)
  //final case class UserSchema3(Id: Accessor.Selector[User, Long], Name: Accessor.Selector[User, String], Age: Accessor.Selector[User, Int])
  object User3 {
    private val schema: Schema[User3] = DeriveSchema.gen[User3]
    /*@nowarn val S: UserSchema3 = {
      val (id: Accessor.Selector[User, Long], name: Accessor.Selector[User, String], age: Accessor.Selector[User, Int]) =
        schema.makeAccessors(AccessorBuilderSelector)
      UserSchema3(id, name, age)
    }*/

    val (id: Accessor.Selector[User3, Long], name: Accessor.Selector[User3, String], age: Accessor.Selector[User3, Int]) =
      schema.makeAccessors(AccessorBuilderSelector): @unchecked
  }

  final case class Tenant(id: Long, user: User3)

  //final case class UserSchema3(Id: Accessor.Selector[User, Long], Name: Accessor.Selector[User, String], Age: Accessor.Selector[User, Int])
  object Tenant {
    private val schema: Schema[Tenant] = DeriveSchema.gen[Tenant]
    //private val schemaU: Schema[User4] = DeriveSchema.gen[User4]

    val (id: Accessor.Selector[Tenant, Long], user: Accessor.Selector[Tenant, User3]) =
      schema.makeAccessors(AccessorBuilderSelector): @unchecked

  }


  val selector = Tenant.user / User3.name
  //selector.schema.ordering.compare()

  val res8 = selector.schema.toDynamic(User3(1L, "aaa", 10))
  res8.toValue(selector.schema)// Right(User3(1L, "aaa", 10))

  res8 match {
    case rec: DynamicValue.Record => selector.schema.fromDynamic(rec)
    case other => Left(other.toString)
  }

  val acc = Tenant.user / User3.name =:= "sss"

  /*acc.schema match {
    case Schema.GenericRecord(id, fieldSet, annotations) => ???
    case clazz3: Schema.CaseClass3[_, _, _, _] => ???
  }*/

  /*val res = res8 match {
    case rec: DynamicValue.Record =>
      rec.values("name") match {
        case rec2: DynamicValue.Primitive[_] =>
          x.schema.fromDynamic(rec2)
        case rec0: DynamicValue.Record =>
          x.schema.fromDynamic(rec0)
        case other =>
          Left(other.toString)
      }
    case _ => Left("")
  }*/


  Tenant.user / User3.name

  val urs3 = User3(1L, "aaa", 10)
  ((Tenant.user / User3.name) =:= "aaa") apply urs3
  ((Tenant.user / User3.age) =:= 10) apply urs3
  ((Tenant.user / User3.id) =:= 42L) apply urs3

  User3.id >> 10L

  User3.id ~> User3.name ~> User3.age >> 10
  User3.id ~> User3.name ~> User3.age =:= 10

  val u = User(1L, "vadim", 90)
  User.age.set(34)(u)
  User.age.get(u)
  User.name.getOptic(u)
  User.name.setOptic("bb")


  //----------------
  User2.id =:= 99L
  User2.age >> 12

  User2.id.>>(99L)
  
  User2.id.max
  User2.id.avg
  User2.id =:= 99
  User2.name =:= "bla"

  //------------------
  User2.id.find(User2.id.=:=(99L))
  User2.id.filter(User2.id.<<(999L))

  val like = User2.name like_% "aaa"
  User2.name.filter(like)

  
  //https://github.com/domdorn/zio-schema-example.git
  //https://github.com/zio/zio-schema/blob/26bb289a166d23d346abe09939eeb7fa31397ea6/zio-schema-examples/shared/src/main/scala/dev/zio/schema/example/example1/Example1.scala
  //https://github.com/zio/zio-schema/blob/26bb289a166d23d346abe09939eeb7fa31397ea6/zio-schema-examples/shared/src/main/scala/dev/zio/schema/example/example2/Example2.scala
  //etc ..

}