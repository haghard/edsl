package com.github.haghard.akkanative.domain

import com.github.haghard.akkanative.domain.diff.Patch

import java.time.Instant

final case class UserId(value: Long) extends AnyVal

sealed trait BOREvent

object BOREvent {

  implicit class Ops[T <: BOREvent](val self: T) extends AnyVal {

    def patchTo[E](implicit P: Patch[T, E]): E =
      eval[T, E](self)

    private def eval[From, To](event: From)(implicit P: Patch[From, To]): To =
      P match {
        case Patch.OwnershipChanged1to3 =>
          event // =:= OwnershipChanged
          BOREvent.OwnershipChanged3(event.id, event.newOwner, event.firstName + " " + event.lastName, UserId(-1), "label", event.userId, event.when)
        case Patch.OwnershipChanged2to3 =>
          event // =:= OwnershipChanged2
          BOREvent.OwnershipChanged3(event.id, event.newOwner, "John Doe", UserId(-1), event.label, event.userId, event.when)
        case Patch.OwnershipChanged3to2 =>
          event // =:= OwnershipChanged3
          BOREvent.OwnershipChanged2(event.id, event.newOwner, event.label, event.userId, event.when)
      }
  }


  implicit val schema: zio.schema.Schema[BOREvent] = zio.schema.DeriveSchema.gen[BOREvent]

  final case class Created(id: Long, userId: UserId, when: Instant) extends BOREvent

  final case class Updated(id: Long, userId: UserId, when: Instant) extends BOREvent

  final case class Deleted(id: Long, userId: UserId, when: Instant) extends BOREvent

  final case class OwnershipChanged(
    id: Long,
    firstName: String,
    lastName: String,
    newOwner: UserId, userId: UserId, when: Instant
  ) extends BOREvent


  object OwnershipChanged2 {
    implicit val schema: zio.schema.Schema[OwnershipChanged2] = zio.schema.DeriveSchema.gen[OwnershipChanged2]
  }

  final case class OwnershipChanged2(
    id: Long, newOwner: UserId, label: String, userId: UserId, when: Instant
  ) extends BOREvent


  object OwnershipChanged3 {
    implicit val schema: zio.schema.Schema[OwnershipChanged3] = zio.schema.DeriveSchema.gen[OwnershipChanged3]
  }

  final case class OwnershipChanged3(
    id: Long, newOwner: UserId,
    fullName: String,
    prevOwner: UserId,
    label: String, userId: UserId, when: Instant
  ) extends BOREvent

}


sealed trait Location

object Location {
  final case class Address(str: String, id: Long) extends Location

  final case class Email(str: String) extends Location
}


final case class Changed(id: Long, newOwner: UserId, prevOwner: UserId, contactPoint: Location, label: String, userId: UserId, when: Instant)

