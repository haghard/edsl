package com.github.haghard.akkanative.domain.diff

import DiffResult.Labeled
import com.github.haghard.akkanative.domain.serialization.ETag
import com.github.haghard.akkanative.domain.{BOREvent, UserId}

import language.experimental.macros
import magnolia1.*
import zio.schema.Schema

import java.time.Instant
import scala.annotation.implicitNotFound


object DeriveDiffer {

  type Typeclass[A] = Differ[A]

  def join[A](ctx: CaseClass[Differ, A]): Differ[A] =
    (a1: A, a2: A) =>
      if (a1 == a2) {
        DiffResult.Identical(a1)
      } else {
        val labeleds: List[Labeled] = ctx.parameters.toList.map { param =>
          Labeled.Diff(param.label, param.typeclass.diff(param.dereference(a1), param.dereference(a2)))
        }
        DiffResult.Nested(ctx.typeName.full, labeleds)
      }

  def split[A](ctx: SealedTrait[Differ, A]): Differ[A] =
    (a1: A, a2: A) =>
      if (a1 == a2) {
        DiffResult.Identical(a1)
      } else {
        ctx.split(a1) { subtype =>
          val cast = subtype.cast
          (a1, a2) match {
            case (cast(a1), cast(a2)) => subtype.typeclass.diff(a1, a2)
            case _ => DiffResult.Different(a1, a2)
          }
        }
      }

  implicit def gen[A]: Differ[A] = macro Magnolia.gen[A]
}

// Today's Topic: Differ
// - functional domain
// - type-class
// - encoder/decoder
// - magnolia
// - zio-json
// - JSON diffing

object DiffResult {

  final case class Identical(value: Any) extends DiffResult

  final case class Different(left: Any, right: Any) extends DiffResult

  final case class Nested(name: String, labeled: List[Labeled]) extends DiffResult

  //Uncomparable

  sealed trait Labeled extends Product with Serializable {
    def label: String
  }

  object Labeled {
    final case class Added(label: String, value: Any) extends Labeled

    final case class Removed(label: String, value: Any) extends Labeled

    final case class Diff(label: String, diffResult: DiffResult) extends Labeled
  }

  /*
  val map1: Map[String, Map[String, Int]] =
    Map(
      "first" -> Map("one" -> 1, "two" -> 2, "three" -> 3),
      "second" -> Map.empty,
      "fifth" -> Map("good" -> 300)
    )

  val map2: Map[String, Map[String, Int]] =
    Map(
      "first" -> Map("one" -> 1, "two" -> 3, "four" -> 4),
      "second" -> Map.empty,
      "fourth" -> Map("hello" -> 300)
    )

  def main(args: Array[String]): Unit = {
    println(Differ.diff(map1, map2).render)
  }*/
}

sealed trait DiffResult extends Product with Serializable {
  self =>

  def indent(string: String): String =
    string.linesIterator.map(s => s"  $s").mkString("\n")

  def red(string: String): String =
    s"\u001b[31m$string\u001b[0m"

  def green(string: String): String =
    s"\u001b[32m$string\u001b[0m"

  def cyan(string: String): String =
    s"\u001b[36m$string\u001b[0m"

  def render: String = self match {
    case DiffResult.Identical(value) =>
      s"$value"
    case DiffResult.Different(left, right) =>
      cyan(s"$left -> $right")
    case DiffResult.Nested(name, labeled) =>
      val rendered = labeled.map {
        case Labeled.Added(label, value) =>
          green(s"+ $label = $value")
        case Labeled.Removed(label, value) =>
          red(s"- $label = $value")
        case Labeled.Diff(label, diffResult) =>
          s"$label = ${diffResult.render}"
      }.mkString(",\n")

      s"""
$name(
${indent(rendered)}
)
""".trim
  }

}

trait Differ[A] {
  def diff(a1: A, a2: A): DiffResult
}

object Differ {

  def diff[A](was: A, is: A)(implicit differ: Differ[A]): DiffResult =
    differ.diff(was, is)

  implicit val stringDiffer: Differ[String] =
    (a1: String, a2: String) => if (a1 == a2) DiffResult.Identical(a1) else DiffResult.Different(a1, a2)

  implicit val intDiffer: Differ[Int] =
    (a1: Int, a2: Int) => if (a1 == a2) DiffResult.Identical(a1) else DiffResult.Different(a1, a2)

  implicit val booleanDiffer: Differ[Boolean] =
    (a1: Boolean, a2: Boolean) => if (a1 == a2) DiffResult.Identical(a1) else DiffResult.Different(a1, a2)

  implicit def mapDiffer[K, V](implicit differ: Differ[V]): Differ[Map[K, V]] = new Differ[Map[K, V]] {
    override def diff(oldMap: Map[K, V], newMap: Map[K, V]): DiffResult = {
      if (oldMap == newMap) return DiffResult.Identical(oldMap)

      val newKeys = oldMap.keySet
      val oldKeys = newMap.keySet

      val addedKeys = oldKeys -- newKeys
      val removedKeys = newKeys -- oldKeys
      val allKeys = newKeys union oldKeys

      val labeled: List[Labeled] =
        allKeys.toList.map { key =>
          if (addedKeys.contains(key)) Labeled.Added(key.toString, newMap(key))
          else if (removedKeys.contains(key)) Labeled.Removed(key.toString, oldMap(key))
          else Labeled.Diff(key.toString, differ.diff(oldMap(key), newMap(key)))
        }

      DiffResult.Nested("Map", labeled)
    }
  }

  implicit val ursDiffer: Differ[UserId] = (a1: UserId, a2: UserId) =>
    if (a1.value == a2.value) DiffResult.Identical(a1) else DiffResult.Different(a1, a2)


  implicit val insDiffer: Differ[Instant] = (a1: Instant, a2: Instant) =>
    if (a1.compareTo(a2) == 1) DiffResult.Identical(a1) else DiffResult.Different(a1, a2)

  import com.github.haghard.akkanative.domain.BOREvent

  implicit val evDiffer: Differ[BOREvent] = (a: BOREvent, b: BOREvent) => {
    println("***************")
    a match {
      case a: BOREvent.OwnershipChanged2 =>
        b match {
          case b: BOREvent.OwnershipChanged3 =>

            //v2 -> v3
            /*val v2Tov3Schema: Schema[BOREvent.OwnershipChanged3] =
              BOREvent.OwnershipChanged2.schema.transformOrFail(
                { v2: BOREvent.OwnershipChanged2 => Right(BOREvent.OwnershipChanged3(v2.id, v2.newOwner, None, UserId(-1), v2.label, v2.userId, v2.when)) },
                { v3: BOREvent.OwnershipChanged3 =>  Right(BOREvent.OwnershipChanged2(v3.id, v3.newOwner, v3.label, v3.userId, v3.when))}
              )
            v2Tov3Schema.migrate(BOREvent.OwnershipChanged2.schema).getOrElse(throw new Exception("Boom !")).apply(???)
            */

            //v3->v2
            val v3Tov2Schema: Schema[BOREvent.OwnershipChanged2] =
              BOREvent.OwnershipChanged3.schema.transformOrFail(
                { v3: BOREvent.OwnershipChanged3 => Right(BOREvent.OwnershipChanged2(v3.id, v3.newOwner, v3.label, v3.userId, v3.when)) },
                { v2: BOREvent.OwnershipChanged2 => Right(BOREvent.OwnershipChanged3(v2.id, v2.newOwner, "John Doe", UserId(-1), v2.label, v2.userId, v2.when)) }
              )

            v3Tov2Schema.migrate(BOREvent.OwnershipChanged3.schema).getOrElse(throw new Exception("Boom !")).apply(a)

            //automatic doesn't work
            //BOREvent.OwnershipChanged2.schema.migrate(BOREvent.OwnershipChanged3.schema).getOrElse(???).apply(a)
            //BOREvent.OwnershipChanged2.schema.migrate(BOREvent.OwnershipChanged3.schema).map { _.apply(a) }

            val schemaA = Map("id" -> "Long", "newOwner" -> "UserId", "label" -> "String", "userId" -> "UserId", "when" -> "Instant")
            val schemaB = Map("id" -> "Long", "newOwner" -> "UserId", "prevOwner" -> "UserId", "label" -> "String", "userId" -> "UserId", "when" -> "Instant")
            Differ.diff(schemaA, schemaB) //.red(",,")

          //DiffResult.Different(a, b)
          case _ =>
            ???
        }
      case _ =>
        ???
    }
  }

}


/*sealed trait Migrator[S, D] {
  def apply(v: S): D
}

object Migrator {

  implicit val v2Tov3: Migrator[BOREvent.OwnershipChanged2, BOREvent.OwnershipChanged3] =
    new Migrator[BOREvent.OwnershipChanged2, BOREvent.OwnershipChanged3] {
      override def apply(v: BOREvent.OwnershipChanged2): BOREvent.OwnershipChanged3 =
        null.asInstanceOf[BOREvent.OwnershipChanged3]
    }

  implicit val v3Tov2: Migrator[BOREvent.OwnershipChanged3, BOREvent.OwnershipChanged2] = new Migrator[BOREvent.OwnershipChanged3, BOREvent.OwnershipChanged2] {
    override def apply(v: BOREvent.OwnershipChanged3): BOREvent.OwnershipChanged2 =
      null.asInstanceOf[BOREvent.OwnershipChanged2]
  }

}
*/

@implicitNotFound("Patch from ${From} to ${To} not found")
sealed trait Patch[From, To] extends enumeratum.EnumEntry {
  def desc: String
}

object Patch extends enumeratum.Enum[ETag[_]] {
  implicit object OwnershipChanged1to3 extends Patch[BOREvent.OwnershipChanged, BOREvent.OwnershipChanged3] {
    val desc = "OwnershipChanged1~>3"
  }
  implicit object OwnershipChanged2to3 extends Patch[BOREvent.OwnershipChanged2, BOREvent.OwnershipChanged3] {
    val desc = "OwnershipChanged2~>3"
  }
  implicit object OwnershipChanged3to2 extends Patch[BOREvent.OwnershipChanged3, BOREvent.OwnershipChanged2] {
    val desc = "OwnershipChanged3~>2"
  }

  override def values: IndexedSeq[ETag[_]] = findValues

  def apply[From, To](implicit P: Patch[From, To]): Patch[From, To] = P
}

object Events {

  import com.github.haghard.akkanative.domain.BOREvent

  import DeriveDiffer.gen


  def main(args: Array[String]): Unit = {
    val a: BOREvent = BOREvent.OwnershipChanged2(0, UserId(11), "hjkhj", UserId(1), Instant.now())
    val b: BOREvent = BOREvent.OwnershipChanged3(0, UserId(11), "John Doe", UserId(22), "hjkhj", UserId(1), Instant.now())

    val e2  = BOREvent.OwnershipChanged2(0, UserId(11), "hjkhj", UserId(1), Instant.now())
    e2.patchTo[BOREvent.OwnershipChanged3]
    //e2.to[BOREvent.OwnershipChanged]

    println(Differ.diff(a, b).render)

  }
}

/*

final case class Coord(x: Int, y: Int, z: Int)
final case class Person(name: String, age: Int, job: Job, coord: Coord)

sealed trait Job extends Product with Serializable

object Job {
  final case class Chef(numberOfBananas: Int) extends Job
  final case class Waiter(numberOfDishes: Int) extends Job
  final case class Programmer(favoriteLanguage: String, numberOfBugs: Int) extends Job
}

//runMain diffing.Person
object Person {

  import DeriveDiffer.gen

  def main(args: Array[String]): Unit = {

    val a =
      Map[String, Map[String, AnyVal]](
        "first" -> Map("one" -> 1, "two" -> 2, "three" -> 3, "four" -> 4),
        "b" -> Map("fl" -> 5.7),
        "fifth" -> Map("cap" -> true)
      )

    val b =
      Map[String, Map[String, AnyVal]](
        "first" -> Map("one" -> 1, "two" -> 2, "four" -> 4),
        "second" -> Map("hello" -> 1),
      )

    //println(Differ.diff(a, b).render)

    println(
      Differ.diff(
          Person("John", 30, Job.Programmer("Scala", 28), Coord(1, 2, 3)),
          //Person("Adam", 35, Job.Programmer("Scala", 3), Coord(4, 2, 6))
          Person("Adam", 35, Job.Waiter(3), Coord(4, 2, 6))
        )
        .render
    )
  }
}
*/
