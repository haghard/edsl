package com.github.haghard.akkanative.domain.diff

import com.github.haghard.akkanative.domain.{BOREvent, Changed, Location, UserId}

import java.time.Instant

object ZSchema {

  def main(args: Array[String]): Unit = {
    import zio.schema.{DeriveSchema, Schema}
    import zio.schema.syntax._

    implicit val schema: Schema[BOREvent] = BOREvent.schema

    import zio._
    import zio.schema.Schema._
    import zio.schema._
    //import zio.schema.optics.ZioOpticsBuilder

    //schema.diff()

    println(schema)

    /*
    final case class Changed(id: Long,
      newOwner: UserId, prevOwner: UserId, contactPoint: Location,
      label: String, userId: UserId, when: Instant)
     */

    //https://github.com/zio/zio-schema/blob/26bb289a166d23d346abe09939eeb7fa31397ea6/zio-schema-examples/shared/src/main/scala/dev/zio/schema/example/example1/Example1.scala
    //https://github.com/zio/zio-schema/blob/26bb289a166d23d346abe09939eeb7fa31397ea6/zio-schema-examples/shared/src/main/scala/dev/zio/schema/example/example2/Example2.scala
    //etc ..

    implicit val changedSchema: Schema.CaseClass7[Long, UserId, UserId, Location, String, UserId, Instant, Changed] =
      Schema.CaseClass7[Long, UserId, UserId, Location, String, UserId, Instant, Changed](
        TypeId.parse("com.github.haghard.akkanative.domain.Changed"),
        field01 = Field("id", Schema.primitive[Long], get0 = _.id, set0 = (p, v) => p.copy(id = v)),
        field02 = ???, //Field("age", Schema.primitive[Int], get0 = _.age, set0 = (p, v) => p.copy(age = v)),
        field03 = ???, // Field("name", Schema.primitive[String], get0 = _.name, set0 = (p, v) => p.copy(name = v)),
        field04 = ???, //Field("age", Schema.primitive[Int], get0 = _.age, set0 = (p, v) => p.copy(age = v)),
        field05 = ???, // Field("name", Schema.primitive[String], get0 = _.name, set0 = (p, v) => p.copy(name = v)),
        field06 = ???, //Field("age", Schema.primitive[Int], get0 = _.age, set0 = (p, v) => p.copy(age = v)),
        field07 = ???, //Field("age", Schema.primitive[Int], get0 = _.age, set0 = (p, v) => p.copy(age = v)),
        construct0 = Changed(_, _, _, _, _, _, _)
      )

    //Encoder.deriveEncoder[BOREvent] //.encode(p)

    sealed trait PaymentMethod //Wire ACH
    object PaymentMethod {
      final case class CreditCard(number: String, expirationMonth: Int, expirationYear: Int) extends PaymentMethod

      object CreditCard {
        val number: Field[CreditCard, String] =
          Schema.Field[CreditCard, String](
            "number",
            Schema.primitive[String],
            get0 = _.number,
            set0 = (p, v) => p.copy(number = v)
          )

        val expirationMonth: Field[CreditCard, Int] =
          Schema.Field[CreditCard, Int](
            "expirationMonth",
            Schema.primitive[Int],
            get0 = _.expirationMonth,
            set0 = (p, v) => p.copy(expirationMonth = v)
          )

        val expirationYear: Field[CreditCard, Int] =
          Schema.Field[CreditCard, Int](
            "expirationYear",
            Schema.primitive[Int],
            get0 = _.expirationYear,
            set0 = (p, v) => p.copy(expirationYear = v)
          )
        implicit val schema: Schema[CreditCard] = Schema.CaseClass3[String, Int, Int, CreditCard](
          TypeId.parse("dev.zio.schema.example.example2.Domain.PaymentMethod.CreditCard"),
          field01 = number,
          field02 = expirationMonth,
          field03 = expirationYear,
          construct0 =
            (number, expirationMonth, expirationYear) => PaymentMethod.CreditCard(number, expirationMonth, expirationYear)
        )
      }

      final case class WireTransfer(accountNumber: String, bankCode: String) extends PaymentMethod

      object WireTransfer {

        val accountNumber: Field[WireTransfer, String] =
          Schema.Field[WireTransfer, String](
            "accountNumber",
            Schema.primitive[String],
            get0 = _.accountNumber,
            set0 = (p, v) => p.copy(accountNumber = v)
          )

        val bankCode: Field[WireTransfer, String] =
          Schema.Field[WireTransfer, String](
            "bankCode",
            Schema.primitive[String],
            get0 = _.bankCode,
            set0 = (p, v) => p.copy(bankCode = v)
          )

        implicit val schema: Schema[WireTransfer] = Schema.CaseClass2[String, String, WireTransfer](
          TypeId.parse("dev.zio.schema.example.example2.Domain.PaymentMethod.WireTransfer"),
          field01 = accountNumber,
          field02 = bankCode,
          construct0 = (number, bankCode) => PaymentMethod.WireTransfer(number, bankCode)
        )
      }

    }

    import PaymentMethod._
    val schemaPaymentMethod: Schema[PaymentMethod] = Schema.Enum2[CreditCard, WireTransfer, PaymentMethod](
      id = TypeId.parse("dev.zio.schema.example.example2.Domain.PaymentMethod"),
      case1 = Case[PaymentMethod, PaymentMethod.CreditCard](
        id = "CreditCard",
        schema = PaymentMethod.CreditCard.schema,
        unsafeDeconstruct = pm => pm.asInstanceOf[PaymentMethod.CreditCard],
        construct = pc => pc.asInstanceOf[PaymentMethod],
        isCase = _.isInstanceOf[PaymentMethod.CreditCard],
        annotations = Chunk.empty
      ),
      case2 = Case[PaymentMethod, WireTransfer](
        id = "WireTransfer",
        schema = WireTransfer.schema,
        unsafeDeconstruct = pm => pm.asInstanceOf[PaymentMethod.WireTransfer],
        construct = pc => pc.asInstanceOf[PaymentMethod],
        isCase = _.isInstanceOf[PaymentMethod.WireTransfer],
        annotations = Chunk.empty
      ),
      annotations = Chunk.empty
    )
  }
}
