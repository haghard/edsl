package com.github.haghard.akkanative.domain.serialization

import akka.actor.ExtendedActorSystem
import com.github.haghard.akkanative.domain.BOREvent.*

import java.time.Instant
import akka.serialization.SerializerWithStringManifest
import com.github.haghard.akkanative.domain.patch.Migration
import com.github.haghard.akkanative.domain.{BOREvent, UserId}

import scala.annotation.implicitNotFound

@implicitNotFound("An implicit value of ETag[${T}] isn't found! Consider adding it to the companion object.")
sealed trait ETag[+T] extends enumeratum.EnumEntry {
  self =>
  def manifest(): String = self.getClass().getName()
}

object ETag extends enumeratum.Enum[ETag[_]] {

  implicit case object Created extends ETag[BOREvent.Created]

  implicit case object Deleted extends ETag[BOREvent.Deleted]

  implicit case object Updated extends ETag[BOREvent.Updated]

  implicit case object OwnershipChanged extends ETag[BOREvent.OwnershipChanged]

  implicit case object OwnershipChanged2 extends ETag[BOREvent.OwnershipChanged2]

  implicit case object OwnershipChanged3 extends ETag[BOREvent.OwnershipChanged3]

  override val values: IndexedSeq[ETag[_]] = findValues

  def apply[T <: BOREvent : ETag]: ETag[T] = implicitly[ETag[T]]

  /*
    EvTag[BookOfRecordEvent.Created].manifest()
    val res4: String = com.github.vmencik.akkanative.EvTag$Created$

    EvTag.fromStr(res4)
    res5: Either[String,com.github.vmencik.akkanative.EvTag[com.github.vmencik.akkanative.BookOfRecordEvent]] = Right(Created)
   */
  def fromStr(
    manifest: String
  ): Either[String, ETag[BOREvent]] =
    values.find(_.manifest() == manifest) match {
      case Some(tag) => Right(tag.asInstanceOf[ETag[BOREvent]])
      case None => Left(manifest)
    }
}

/**
 *
 * IDEA: Brings that static compile guarantee to the Scala's type level
 *
 * Let me take you on this journey.
 *
 * We wrote it in a way that is
 * a type safe
 *
 * If we can be smarter about some decisions we can achieve our goals.
 *
 * As we all know FQCN is unique and the Scala compiler can check it for us during compile time.
 * How can we bring that guarantee to the Scala type level ?
 *
 * It brings static compile guarantee to the scala type level.
 * GADTs
 *
 * https://github.com/virtuslab/akka-serialization-helper
 *
 */

object BookOfRecordEventSerializer {

  def _2 = new Migration[OwnershipChanged, OwnershipChanged2] {
    val forward = (v1: OwnershipChanged) => BOREvent.OwnershipChanged2(v1.id, v1.userId, "kljkl", v1.userId, v1.when)
  }

  def _3 = new Migration[OwnershipChanged2, OwnershipChanged3] {
    val forward = (v1: OwnershipChanged2) => BOREvent.OwnershipChanged3(v1.id, v1.userId, "John Doe", v1.userId, "kljkl", v1.userId, v1.when)
  }

  //https://softwaremill.com/5-scala-libraries-that-will-make-your-life-easier/
  //https://chimney.readthedocs.io/en/stable/index.html
  /*def _ff3 = new Migration[OwnershipChanged, OwnershipChanged3] {
    val forward = { (v1: OwnershipChanged) =>
      import io.scalaland.chimney.dsl._
      //import io.scalaland.chimney.dsl.TransformerOps
      v1.into[OwnershipChanged3]
        .withFieldComputed(_.fullName, ev1 => Some(s"${ev1.firstName} ${ev1.lastName}"))
        .withFieldComputed(_.prevOwner, _ => UserId(-1))
        .withFieldComputed(_.label, ev1 => ev1.lastName)
        .transform
        //.withFieldRenamed(_.age, _.howOld)
    }
  }*/

  def _ff3 = new Migration[OwnershipChanged, OwnershipChanged3] {
    val forward = { (v1: OwnershipChanged) =>
      OwnershipChanged3(v1.id, v1.newOwner, s"${v1.firstName} ${v1.lastName}", UserId(-1), v1.lastName, v1.userId, v1.when)
    }
  }
}

final class BookOfRecordEventSerializer(
  actorSystem: ExtendedActorSystem
) extends SerializerWithStringManifest with EventSerializer[BOREvent] {

  import BookOfRecordEventSerializer._
  import ETag._

  override val identifier = 9993
  private val serializerName = getClass().getName()

  override def tag(event: BOREvent): ETag[BOREvent] = {
    event match {
      case _: BOREvent.Created =>
        ETag[BOREvent.Created]
      case _: BOREvent.Deleted =>
        ETag[BOREvent.Deleted]
      case _: BOREvent.Updated =>
        ETag[BOREvent.Updated]
      case _: BOREvent.OwnershipChanged =>
        ETag[BOREvent.OwnershipChanged]
      case _: BOREvent.OwnershipChanged2 =>
        ETag[BOREvent.OwnershipChanged2]
      case _: BOREvent.OwnershipChanged3 =>
        ETag[BOREvent.OwnershipChanged3]
      //case _: BOREvent.Updated2 => ETag[BOREvent.Updated2]
    }
  }

  override def manifest(event: AnyRef): String =
    event match {
      case bor: BOREvent =>
        tag(bor).manifest()
      case _ =>
        notSerializable(s"Unexpected manifest for $event. Check manifest in $serializerName")
    }

  override def toBinary(ev: AnyRef): Array[Byte] =
    ev match {
      case bor: BOREvent =>
        //if this compiles, it implies that we have defined eventTags for all terms of BOREvent
        serialize(bor)(tag(bor))
      case _ =>
        notSerializable(s"Unexpected manifest for $ev. Check manifest in $serializerName")
    }

  //backaward ???
  //A set of events that current Entity works with (OwnershipChanged)

  //manifest should be one of tag(bor).manifest()
  override def fromBinary(bytes: Array[Byte], manifest: String): AnyRef = {
    ETag.fromStr(manifest)
      //.map(tag => deserialize(bytes)(tag))
      .map { tag =>
        val evFromJournal: BOREvent = deserialize(bytes)(tag)
        //event adapter
        migrate(evFromJournal) {
          case e: BOREvent.OwnershipChanged =>

            //e.patchTo[BOREvent.OwnershipChanged2].patchTo[BOREvent.OwnershipChanged3]
            e.patchTo[BOREvent.OwnershipChanged3]

            //applyPatch(e, _2 ~> _3)
            //applyMigration(e, _ff3)
          case e: BOREvent.OwnershipChanged2 =>
            e.patchTo[BOREvent.OwnershipChanged3]
            //applyMigration(e, _3)
        }
      }
      .getOrElse(notSerializable(s"Unexpected $manifest. Check manifest in $serializerName"))
  }

  //try
  /*
    https://github.com/tpolecat/typename
    "org.tpolecat" %% "typename" % "1.1.0",
  */
  override def serialize[T](event: T)(implicit tag: ETag[T]): Array[Byte] =
    tag match {
      case ETag.Created =>
        //statically checked. Well typed
        //event
        //event //event =:= Created
        Array.empty
      case ETag.Deleted =>
        Array.empty
      case ETag.Updated =>
        Array.empty
      case ETag.OwnershipChanged =>
        Array.empty
      //case ETag.Updated2 => Array.empty
      case ETag.OwnershipChanged2 =>
        Array.empty
      case ETag.OwnershipChanged3 =>
        Array.empty
    }

  override def deserialize[T](bts: Array[Byte])(implicit tag: ETag[T]): T =
    tag match {
      case ETag.Created =>
        //bts
        BOREvent.Created(0, UserId(1), Instant.now())
      //BookOfRecordEvent.Updated(0, Instant.now())
      case ETag.Deleted =>
        //bts
        BOREvent.Deleted(0, UserId(1), Instant.now())
      case ETag.Updated =>
        ???
        //BookOfRecordEvent.Deleted(0, Instant.now())
        BOREvent.Updated(0, UserId(1), Instant.now())
      case ETag.OwnershipChanged =>
        BOREvent.OwnershipChanged(0, "John", "Doe", UserId(11), UserId(1), Instant.now())
      //case ETag.Updated2 => BOREvent.Updated2(0, UserId(1), Instant.now())
      case ETag.OwnershipChanged2 =>
        //
        BOREvent.OwnershipChanged2(0, UserId(11), "hjkhj", UserId(1), Instant.now())
      case ETag.OwnershipChanged3 =>
        //
        BOREvent.OwnershipChanged3(0, UserId(11), "John Doe", UserId(22), "hjkhj", UserId(1), Instant.now())
    }
}