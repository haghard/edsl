package com.github.haghard.akkanative.domain.diff


import com.github.haghard.akkanative.domain.{ Changed, Location, UserId}

import language.experimental.macros
import magnolia1.*

import java.time.Instant
import scala.language.experimental.macros

//https://github.com/softwaremill/magnolia/blob/scala2/examples/src/main/scala/magnolia1/examples/show.scala

/** shows one type as another, often as a string
 *
 * Note that this is a more general form of `Show` than is usual, as it permits the return type to be something other than a string.
 */
trait Show[Out, T] { def show(value: T): Out }
//trait Show[Map[String, Any], T] { def show(value: T): Out }

trait GenericShow[Out] {

  /** the type constructor for new [[Show]] instances
   *
   * The first parameter is fixed as `String`, and the second parameter varies generically.
   */
  type Typeclass[T] = Show[Out, T]

  def joinElems(typeName: String, strings: Seq[String]): Out
  def prefix(s: String, out: Out): Out

  /** creates a new [[Show]] instance by labelling and joining (with `mkString`) the result of showing each parameter, and prefixing it with
   * the class name
   */
  def join[T](ctx: CaseClass[Typeclass, T]): Show[Out, T] = { value =>
    if (ctx.isValueClass) {
      val param = ctx.parameters.head
      param.typeclass.show(param.dereference(value))
    } else {
      val paramStrings = ctx.parameters.map { param =>
        val attribStr =
          if (param.annotations.isEmpty && param.inheritedAnnotations.isEmpty) ""
          else {
            (param.annotations ++ param.inheritedAnnotations).distinct
              .filterNot(_.isInstanceOf[scala.annotation.implicitNotFound])
              .mkString("{", ",", "}")
          }
        val tpeAttribStr =
          if (param.typeAnnotations.isEmpty) ""
          else {
            param.typeAnnotations.mkString("{", ",", "}")
          }
        s"${param.label}$attribStr$tpeAttribStr=${param.typeclass.show(param.dereference(value))}"
      }

      val anns = (ctx.annotations ++ ctx.inheritedAnnotations).distinct
        .filterNot(_.isInstanceOf[scala.SerialVersionUID])
        .filterNot(_.isInstanceOf[scala.annotation.implicitNotFound])
      val annotationStr = if (anns.isEmpty) "" else anns.mkString("{", ",", "}")

      val tpeAnns = ctx.typeAnnotations.filterNot(_.isInstanceOf[scala.SerialVersionUID])
      val typeAnnotationStr = if (tpeAnns.isEmpty) "" else tpeAnns.mkString("{", ",", "}")

      def typeArgsString(typeName: TypeName): String =
        if (typeName.typeArguments.isEmpty) ""
        else typeName.typeArguments.map(arg => s"${arg.short}${typeArgsString(arg)}").mkString("[", ",", "]")

      joinElems(ctx.typeName.short + typeArgsString(ctx.typeName) + annotationStr + typeAnnotationStr, paramStrings)
    }
  }

  /** choose which typeclass to use based on the subtype of the sealed trait and prefix with the annotations as discovered on the subtype.
   */
  def split[T](ctx: SealedTrait[Typeclass, T]): Show[Out, T] = (value: T) =>
    ctx.split(value) { sub =>
      val anns = (sub.annotations ++ sub.inheritedAnnotations).distinct
        .filterNot(_.isInstanceOf[scala.SerialVersionUID])
        .filterNot(_.isInstanceOf[scala.annotation.implicitNotFound])
      val annotationStr = {
        //"inner"
        if (anns.isEmpty) "" else anns.mkString("{", ",", "}")
      }

      prefix(annotationStr, sub.typeclass.show(sub.cast(value)))
    }

  /** bind the Magnolia macro to this derivation object */
  implicit def gen[T]: Show[Out, T] = macro Magnolia.gen[T]
}

/** companion object to [[Show]] */
object Show extends GenericShow[String] {

  def prefix(s: String, out: String): String = {
    //println(s"prefix($s, $out)")
    s + out
  }
  def joinElems(typeName: String, params: Seq[String]): String = {

    /*val map =
      params.foldLeft(Map.empty[String, String]) { (acc, c) =>
        val seqs = c.split("=")
        acc + (seqs(0) -> seqs(1))
      }.toString()

    println(s" $typeName -> ${map} ")
    */

    println(s" $typeName -> ${params.mkString(",")} ")


    params.mkString(s"$typeName(", ",", ")")
  }

  implicit val string: Show[String, String] = {_ => "String"}
  implicit val int: Show[String, Int] = {_ => "Int"}
  implicit val long: Show[String, Long] = {_ => "Long"}
  implicit val boolean: Show[String, Boolean] = {_ => "Boolean"}
  implicit val user: Show[String, UserId] = {_ => "UserId"}
  implicit val inst: Show[String, Instant] = { _ => "Instant"}
  implicit val email: Show[String, Location.Email] = { _ => "Email"}

  /** show typeclass for sequences */
  implicit def seq[A](implicit S: Show[String, A]): Show[String, Seq[A]] =
    _.iterator.map(S.show).mkString("[", ",", "]")
  
}

/*object Show extends GenericShow[Map[String, Any]] {

  def prefix(s: String, out: String): Map[String, Any] = {
    s + out
  }

  def joinElems(typeName: String, params: Seq[String]): Map[String, Any] = {
    val map =
      params.foldLeft(Map.empty[String, String]) { (acc, c) =>
        val seqs = c.split("=")
        acc + (seqs(0) -> seqs(1))
      }

    Map(typeName -> map)
  }

  implicit val string: Show[String, String] = { _ => "String" }
  implicit val int: Show[String, Int] = { _ => "Int" }
  implicit val long: Show[String, Long] = { _ => "Long" }
  implicit val boolean: Show[String, Boolean] = { _ => "Boolean" }
  implicit val user: Show[String, UserId] = { _ => "UserId" }
  implicit val inst: Show[String, Instant] = { _ => "Instant" }
  implicit val email: Show[String, Location.Email] = { _ => "Email" }

  /** show typeclass for sequences */

  implicit def seq[A](implicit A: Show[String, A]): Show[String, Seq[A]] =
    _.iterator.map(A.show).mkString("[", ",", "]")

}*/

object TName {

  import com.github.haghard.akkanative.domain.BOREvent

  def main(args: Array[String]): Unit = {
    //import Show.gen
    implicit val S: Show[String, Changed] = Show.gen[Changed]

    //val a = BOREvent.OwnershipChanged2(0, UserId(11), "hjkhj", UserId(1), Instant.now())

    val a = Changed(
      0, UserId(11), UserId(22),
      Location.Email("bla"),
      "hjkhj", UserId(1), Instant.now()
    )

    val b = Changed(
      0, UserId(11), UserId(22),
      Location.Address("bla", 1),
      "hjkhj", UserId(1), Instant.now()
    )

    println(S.show(a))
    println(S.show(b))

    //println(S.show(a))
    
    //println(Show.gen[BOREvent].show(a))
    //println(Show.gen[Changed].show(b))
    //println(Show.gen[Changed].show(a))

    //Changed(id=Long,newOwner=UserId,prevOwner=UserId,ad=Address(str=String,id=Long),label=String,userId=UserId,when=Instant)

    //TypeNameInfo.gen[BOREvent.OwnershipChanged2].name

    //println(Differ.diff(a, b).render)

    //println(TypeNameInfo.gen[BOREvent].name)
    //println(TypeNameInfo.gen[BOREvent].name)

  }
}