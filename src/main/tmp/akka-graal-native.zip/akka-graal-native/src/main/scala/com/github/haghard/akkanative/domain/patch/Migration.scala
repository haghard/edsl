package com.github.haghard.akkanative.domain
package patch

trait Migration[-From, +To] {
  def forward: From => To
  //def revert: To=> From
}

object Migration {

  //def apply[From, To](implicit P: Patch[From, To]) = P

  final case class Both[A, B, C](a: Migration[A, B], b: Migration[B, C]) extends Migration[A, C] {
    def forward: A => C =
      (in: A) =>
        b.forward(a.forward(in))
  }

  implicit class MigrationOps[A, B](val self: Migration[A, B]) extends AnyVal {
    def ~>[C](next: Migration[B, C]): Migration[A, C] = Both(self, next)
  }
}
