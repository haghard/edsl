package com.github.haghard.akkanative.domain.diff

import com.github.haghard.akkanative.domain.UserId

import language.experimental.macros
import magnolia1.*

import java.time.Instant
import scala.language.experimental.macros

trait Show2[T] {
  def show(value: T): String
}

object ShowDerivation {
  type Typeclass[T] = Show2[T]

  def join[T](ctx: CaseClass[Show2, T]): Show2[T] = new Show2[T] {
    def show(value: T): String = ctx.parameters.map { p =>
      s"${p.label}=${p.typeclass.show(p.dereference(value))}"
    }.mkString("{", ",", "}")
  }

  def split[T](ctx: SealedTrait[Show2, T]): Show2[T] =
    new Show2[T] {
      def show(value: T): String = ctx.split(value) { sub =>
        sub.typeclass.show(sub.cast(value))
      }
    }

  implicit def gen[T]: Show2[T] = macro Magnolia.gen[T]
}

object ShowApp extends App {

  implicit val string: Show2[String] = { _ => "String" }
  implicit val int: Show2[Int] = { _ => "Int" }
  implicit val long: Show2[Long] = { _ => "Long" }
  implicit val boolean: Show2[Boolean] = { _ => "Boolean" }
  implicit val user: Show2[UserId] = { _ => "UserId" }
  implicit val inst: Show2[Instant] = { _ => "Instant" }

}
