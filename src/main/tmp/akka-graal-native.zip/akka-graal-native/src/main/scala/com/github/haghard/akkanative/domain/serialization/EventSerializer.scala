package com.github.haghard.akkanative.domain.serialization

import com.github.haghard.akkanative.domain.patch.Migration

import java.io.NotSerializableException

trait EventSerializer[Event] {

  def tag(event: Event): ETag[Event]

  def deserialize[T <: Event](bts: Array[Byte])(implicit ev: ETag[T]): T

  def serialize[T <: Event](event: T)(implicit ev: ETag[T]): Array[Byte]

  def notSerializable(msg: String) = throw new NotSerializableException(msg)

  //adapt
  def migrate(event: Event)(f: PartialFunction[Event, Event]): Event =
    f.lift(event).getOrElse(event)

  def applyMigration[From, To](event: From, patch: Migration[From, To]): To =
    patch.forward(event)
}