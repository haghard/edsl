package net.demo

object Patches extends App {

  // final

  /*
  final abstract class V0
  final abstract class V1
  final abstract class V2
  sealed trait Patch0[V]

  object Patch0 {

    final case class V0toV1() extends Patch0[V0]
    final case class V1toV2() extends Patch0[V1]
    final case class V2toV3() extends Patch0[V2]

    /*implicit class PatchOps[A, B](val self: Patch[A, B]) extends AnyVal {
      def ~>[C](next: Patch[B, C]): Patch[A, C] = Both(self, next)
    }*/

    def _0(): Patch0[V0] = V0toV1()
    def _1(): Patch0[V1] = V1toV2()
    def _2(): Patch0[V2] = V2toV3()
  }*/

  sealed trait State
  final case class StateV1(id: Long, str: String)         extends State
  final case class StateV2(id: Long)                      extends State
  final case class StateV3(id: Long)                      extends State
  final case class StateV4(id: Long, d: Double, age: Int) extends State

  // Patch language for manipulating data types such as products, Sums, fixed collections (Map, List, Set), primitives
  // Patch language - this is how we allow users to drill down into different parts of your data structure and make targeted changes.

  /** [[Patch]] takes the role of events from Event sourcing. It contains the information of events but in a DSL that is
    * targeted to make a structural changes to the [[State]]. Describes how we allow users to dive into different parts
    * of the state and make targeted changes.
    */
  sealed trait Patch[-From, +To] {
    def patch: From => To
  }

  object Patch {
    final case class Both[A, B, C](a: Patch[A, B], b: Patch[B, C]) extends Patch[A, C] {
      def patch: A => C = (in: A) => b.patch(a.patch(in))
    }

    /*final case class V1toV2(promotion: Promotion[StateV1, StateV2] = new Promotion[StateV1, StateV2] {
      def apply(from: StateV1): StateV2 = StateV2(from.id + 1)
    }) extends Patch[StateV1, StateV2]*/

    /*final case class V2toV3(promotion: Promotion[StateV2, StateV3] = new Promotion[StateV2, StateV3] {
      def apply(from: StateV2): StateV3 = StateV3(from.id + 1)
    }) extends Patch[StateV2, StateV3]
     */

    implicit class PatchOps[A, B](val self: Patch[A, B]) extends AnyVal {
      def ~>[C](next: Patch[B, C]): Patch[A, C] = Both(self, next)
    }

    // A set of migrations that we want to apply in the context of patch

    def _2 = new Patch[StateV1, StateV2] {
      val patch = (from: StateV1) => StateV2(from.id)
    }

    def _3 = new Patch[StateV2, StateV3] {
      val patch = (from: StateV2) => StateV3(from.id)
    }

    def _4 = new Patch[StateV3, StateV4] {
      val patch = (from: StateV3) => StateV4(from.id, 99.1, 10)
    }

    // fast_forward
    def ff_4 = new Patch[StateV2, StateV4] {
      val patch = (from: StateV2) => StateV4(from.id, 19.1, 10)
    }
  }

  /*def eval[From, To](state: F, patch: Patch[F, T]): T =
      patch match {
        case p: Patch[_, _]            => p.promotion(state)
        case both: Patch.Both[_, _, _] => both.promotion(state)
      }
    eval[From, To](state, patch)
   */

  // (implicit ev: To =:= StateV4)
  def applyPatch[From, To](state: From, patch: Patch[From, To]): To =
    patch match {
      case p: Patch[_, _]            => p.patch(state)
      case both: Patch.Both[_, _, _] => both.patch(state)
    }

  import Patch._

  // applyPatch(StateV1(1, "asd"), _2()) //
  applyPatch(StateV1(1L, "desc"), _2 ~> _3 ~> _4)
  applyPatch(StateV1(1L, "desc"), _2 ~> ff_4)
  applyPatch(StateV3(1L), _4)

  // applyPatch(StateV1(1L, "desc"), _4)

}
