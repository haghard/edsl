package net.demo

import java.util.concurrent.ThreadLocalRandom

object Replication extends App {

  type KeyId = String

  final case class Status(digests: Set[KeyId], chunk: Int, totChunks: Int)

  val maxDeltaElements             = 8
  val dataEntries: Map[KeyId, Int] = (0 to 100).map(i => (i.toString, 0)).toMap

  // for splitting up gossip in chunks
  var statusCount     = 0L
  var statusTotChunks = 0

  val totChunks = dataEntries.size / maxDeltaElements

  for (_ <- 1 to math.min(totChunks, 5)) {
    if (totChunks == statusTotChunks) {
      statusCount += 1
    } else {
      statusCount = ThreadLocalRandom.current.nextInt(0, totChunks)
      statusTotChunks = totChunks
    }

    val chunk = (statusCount % totChunks).toInt

    val status = Status(
      // dataEntries.collect { case (key, v) if math.abs(key.hashCode % totChunks) == chunk => (key, v) },
      dataEntries.collect { case (key, _) if math.abs(key.hashCode % totChunks) == chunk => key }.toSet,
      chunk,
      totChunks
    )

    println(s"$chunk,  $status")

  }
}
