package net.demo

//import zio.=!=

object FlightApp extends App {

  sealed trait Airport

  // abstract - you need a sub type in order to instantiate it
  // final - you can't subtype
  final abstract class NYK extends Airport
  final abstract class LAL extends Airport
  final abstract class DEN extends Airport

  sealed trait Itinerary[Src <: Airport, Dest <: Airport]

  object Itinerary {
    final case class Flight[A <: Airport, B <: Airport](departureTs: Long, arrivalTs: Long) extends Itinerary[A, B]
    final case class Both[A <: Airport, B <: Airport, C <: Airport](a: Itinerary[A, B], b: Itinerary[B, C])
        extends Itinerary[A, C]

    implicit class ItineraryOps[A <: Airport, B <: Airport](val self: Itinerary[A, B]) extends AnyVal {
      def ~>[C <: Airport](that: Itinerary[B, C]): Itinerary[A, C] =
        Itinerary.Both(self, that)

      def <~[C <: Airport](that: Itinerary[B, C])(implicit ev: A IsEqualTo C): Itinerary[A, C] =
        Itinerary.Both(self, that)
      // or this
      // def <~(that: Itinerary[B, A]): Itinerary[A, B] = Itinerary.Both(self, that)
    }

    def flight[From <: Airport, To <: Airport](
      departureTs: Long,
      arrivalTs: Long
    )(implicit ev: From ≠ To) =
      Flight[From, To](departureTs, arrivalTs) // If From ≠ To, the ev is generated. Otherwise,
  }

  import Itinerary._

  flight[NYK, DEN](1, 2) ~> flight[DEN, LAL](3, 5)

  flight[NYK, DEN](1, 2) <~ flight[DEN, NYK](3, 5)

  // flight[NYK, DEN](1, 2) <~ flight[DEN, LAL](3, 5)
  // flight[NYK, NYK](1, 2) Comp error
}
