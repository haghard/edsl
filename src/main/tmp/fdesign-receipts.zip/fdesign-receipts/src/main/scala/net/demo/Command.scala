package net.demo

//runMain net.demo.Command
object Command extends App {

  final abstract class Idle
  final abstract class Moving

  sealed trait Command[From, To]

  object Command {
    private final case object Start extends Command[Idle, Moving]

    private final case object Stop extends Command[Moving, Idle]

    private final case class Turn(direction: String, degrees: Int) extends Command[Moving, Moving]

    private final case class Move(numOfSteps: Int) extends Command[Moving, Moving]

    private final case class Both[A, B, C](a: Command[A, B], b: Command[B, C]) extends Command[A, C]

    implicit class CommandOps[A, B](val self: Command[A, B]) extends AnyVal {
      def ++[C](next: Command[B, C]): Command[A, C] = Both(self, next)
    }

    def start(): Command[Idle, Moving]                                 = Start
    def stop(): Command[Moving, Idle]                                  = Stop
    def turn(direction: String, degrees: Int): Command[Moving, Moving] = Turn(direction, degrees)
    def move(numOfSteps: Int): Command[Moving, Moving]                 = Move(numOfSteps)

    // only for commands that start with `Moving`
    def fromMoving[T](cmd: Command[T, _])(implicit ev: T <:< Moving): String =
      cmd match {
        case Stop                     => "Stop"
        case _: Both[_, _, _]         => "Both"
        case Turn(direction, degrees) => s"Turn($direction, $degrees)"
        case Move(numOfSteps)         => s"Move($numOfSteps)"
      }

    def fromIdle[T](cmd: Command[T, _])(implicit ev: T <:< Idle): String =
      cmd match {
        case Start            => "start"
        case _: Both[_, _, _] => "both"
      }

    def fromMoving2(cmd: Command[Moving, _]): String =
      cmd match {
        case Stop => "stop"
        case _: Both[t, _, _] =>
          implicitly[Moving =:= t]
          "chain"
      }

    def eval[Src, Des](cmd: Command[Src, Des]): Unit =
      cmd match {
        case Command.Start =>
          println("Start,")
        case Command.Stop =>
          println("Stop")
        case Command.Turn(direction, degrees) =>
          println(s"Turn($direction, $degrees),")
        case Command.Move(numOfSteps) =>
          println(s"Move($numOfSteps),")
        case Command.Both(a, b) =>
          eval(a)
          eval(b)
      }
  }

  import Command._

  eval(start() ++ turn("left", 30) ++ move(1) ++ turn("right", 10) ++ stop())

  fromMoving(stop())

  fromMoving(turn("left", 30) ++ turn("right", 30))

  // fromMoving2(start())
  // fromMoving(start())

  fromMoving(turn("left", 30))

  fromMoving(move(10))

}
