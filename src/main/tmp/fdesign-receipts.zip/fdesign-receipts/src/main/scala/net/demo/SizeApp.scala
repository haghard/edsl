package net.demo

import java.time.Duration

//net.demo.SizeApp
//https://gist.github.com/kitlangton/1d5691e6e273ffb143046debe6af596a
object SizeApp {

  trait Size[A] {
    def size: Int
  }

  object Size extends SizeLowPriority {
    implicit def tupleSize[A, B](implicit first: Size[A], second: Size[B]): Size[(A, B)] =
      new Size[(A, B)] {
        def size: Int = first.size + second.size
      }
  }

  trait SizeLowPriority {
    implicit def anySize[A] = new Size[A] {
      def size = 1
    }
  }

  import Size._
  def size[In](in: In)(implicit size: Size[In]): Unit = println(s"$in -> ${size.size}")

  /*val a        = 12
  val b        = "Hello"
  val ab       = (a, b)
  val c        = true
  val abab     = (ab, ab)
  val abababab = (abab, abab)

  size(a)
  size(b)
  size(ab)
  size(abab)
  size(abababab)*/

  // PathDependent Types
  /*trait Box { self =>
    type A

    def value: A

    def printContents(): Unit =
      println(value)

    def tupleBox(that: Box): Box.WithContents[(self.A, that.A)] =
      new Box {
        type A = (self.A, that.A)
        val value = (self.value, that.value)
      }
  }

  object Box {

    type WithContents[B] = Box { type A = B }

    def apply[B](a: B): Box.WithContents[B] =
      new Box {
        type A = B
        val value = a
      }
  }

  val box  = Box(1)
  val box2 = Box("a")

  val x = box.value + box.value

  val boxes = List(box, box2)

  val tupleBox  = box.tupleBox(box2)  //.printContents()
  val tupleBox2 = tupleBox
  val tupleBox3 = tupleBox2
  val a         = tupleBox3.value

  tupleBox.printContents()
   */

  sealed trait Decision
  case object Done                           extends Decision
  final case class Continue(delay: Duration) extends Decision

  trait DomainError
  trait InvalidPassword extends DomainError
  trait CouldNotDecrypt extends DomainError

  trait Union[-In] {
    type Out
    def apply(in: In): Out
  }

  object Union extends UnionLowPriority1 {
    type WithOut[In, Out0] = Union[In] { type Out = Out0 }

    implicit def UnionEitherBoth[A]: Union.WithOut[Either[Either[A, A], Either[A, A]], A] =
      new Union[Either[Either[A, A], Either[A, A]]] {
        type Out = A

        def apply(in: Either[Either[A, A], Either[A, A]]): A =
          in.fold(_.merge, _.merge)
      }
  }

  trait UnionLowPriority1 extends UnionLowPriority2 {

    implicit def UnionEitherRight[A]: Union.WithOut[Either[A, Either[A, A]], A] =
      new Union[Either[A, Either[A, A]]] {
        type Out = A

        def apply(in: Either[A, Either[A, A]]): A =
          in.fold(identity, _.merge)
      }

    implicit def UnionEitherLeft[A]: Union.WithOut[Either[Either[A, A], A], A] =
      new Union[Either[Either[A, A], A]] {
        type Out = A

        def apply(in: Either[Either[A, A], A]): A =
          in.fold(_.merge, identity)
      }
  }

  trait UnionLowPriority2 {

    implicit def UnionEither[A]: Union.WithOut[Either[A, A], A] =
      new Union[Either[A, A]] {
        type Out = A

        def apply(in: Either[A, A]): A =
          in.merge
      }
  }

  def unify[In](in: In)(implicit union: Union[In]): union.Out =
    union(in)

  val either1: Either[InvalidPassword, CouldNotDecrypt]                                                   = ???
  val either2: Either[InvalidPassword, Either[CouldNotDecrypt, InvalidPassword]]                          = ???
  val either3: Either[Either[CouldNotDecrypt, InvalidPassword], InvalidPassword]                          = ???
  val either4: Either[Either[CouldNotDecrypt, InvalidPassword], Either[CouldNotDecrypt, InvalidPassword]] = ???

  val result1 = unify(either1)
  val result2 = unify(either2)
  val result3 = unify(either3)
  val result4 = unify(either4)

}
