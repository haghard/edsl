package net.demo

//https://youtu.be/48fpPffgnMo?list=LL
//https://stackoverflow.com/questions/12135293/type-constraint-for-type-inequality-in-scala
//Type constraint for type inequality in scala [duplicate]
abstract class <:!<[A, B] extends Serializable
object <:!< {
  implicit def nsub[A, B]: A <:!< B = new <:!<[A, B] {}

  @scala.annotation.implicitAmbiguous("Cannot add ${B} to ${A} !")
  implicit def nsubAmbig1[A, B >: A]: A <:!< B = sys.error("Unexpected call")
  implicit def nsubAmbig2[A, B >: A]: A <:!< B = sys.error("Unexpected call")
}
