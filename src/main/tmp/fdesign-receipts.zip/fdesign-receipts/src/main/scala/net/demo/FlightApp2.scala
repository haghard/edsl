package net.demo

import zio.=!=

object FlightApp2 extends App {

  sealed trait Airport
  object Airport {
    abstract class AsbAirport(val id: Int) extends Airport
    final case class CHI()                 extends AsbAirport(1)
    final case class ATL()                 extends AsbAirport(2)
    final case class FLO()                 extends AsbAirport(3)

    def fromString(line: String): Option[Airport] =
      line.trim match {
        case "1" => Some(CHI())
        case "2" => Some(ATL())
        case "3" => Some(FLO())
        case _   => None
      }
  }

  /*
  OR
    sealed trait Airport
    final case class CHI() extends Airport
    final case class ATL() extends Airport
    final case class FLO() extends Airport
   */

  sealed trait Itinerary[Origin <: Airport, Dest <: Airport]

  object Itinerary {
    final case class Flight[A <: Airport, B <: Airport](
      from: A,
      departureTs: Long,
      to: B,
      arrivalTs: Long
    ) extends Itinerary[A, B]

    final case class Both[A <: Airport, B <: Airport, C <: Airport](
      leftLeg: Itinerary[A, B],
      rightLeg: Itinerary[B, C]
    ) extends Itinerary[A, C]

    implicit class ItineraryOps[A <: Airport, B <: Airport](private val self: Itinerary[A, B]) extends AnyVal {
      def ~>[C <: Airport](that: Itinerary[B, C]): Itinerary[A, C] =
        Itinerary.Both(self, that)
    }

    def flight[From <: Airport, To <: Airport](
      from: From,
      departureTs: Long,
      to: To,
      arrivalTs: Long
    )(implicit ev: From ≠ /*=!=*/ To) =
      Flight[From, To](from, departureTs, to, arrivalTs)
  }

  import Airport._
  import Itinerary._

  flight(CHI(), 1, ATL(), 2) ~> flight(ATL(), 3, FLO(), 5)

  // flight(CHI(), 1, CHI(), 2) //Departure:net.demo.FlightApp2.Airport.CHI should not be eq to Arrival:net.demo.FlightApp2.Airport.CHI !

  // flight(CHI(), 1, ATL(), 2) ~> flight(CHI(), 3, FLO(), 5)
  // flight(CHI(), 1, CHI(), 2)

  // ???
  // Migration[V1, V2], Migration[V1, V3]
  // migration(V1)

}
