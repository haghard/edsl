package net.demo

//ZIO API Design Techniques: https://youtu.be/48fpPffgnMo?list=LL
//https://stackoverflow.com/questions/12135293/type-constraint-for-type-inequality-in-scala
//Type constraint for type inequality in scala [duplicate]
abstract class ≠[A, B] extends Serializable //=!!=

object ≠ {
  implicit def nsub[A, B]: A ≠ B = new ≠[A, B] {}

  @scala.annotation.implicitAmbiguous("${A} should not be eq to ${B}")
  implicit def nsubAmbig1[A, B >: A]: A ≠ B = sys.error("Unexpected call")

  implicit def nsubAmbig2[A, B >: A]: A ≠ B = sys.error("Unexpected call")
}
