/*
package net.demo

//https://github.com/antagonist112358/presentations/tree/master/Scala-FP

object GADTs2 extends App {

  sealed trait Expr[+R]

  final case class Val[R](v: R) extends Expr[R]

  final case class Add[R](lhs: Expr[R], rhs: Expr[R]) extends Expr[R]

  final case class Sub[R](lhs: Expr[R], rhs: Expr[R]) extends Expr[R]

  final case class Div[R](lhs: Expr[R], rhs: Expr[R]) extends Expr[R]

  final case class Mul[R](lhs: Expr[R], rhs: Expr[R]) extends Expr[R]

  sealed class ExprCalculator[A](implicit ord: Ordering[A]) {
    type NumExpr = Expr[A]

    private case class TailCont(f: A => A) extends (A => A) {
      def apply(v1: A): A = f(v1)
    }

    //private object Point extends TailCont(x => x)
    private object Point extends TailCont(identity)

    // (1 + 5) + (6 + 3)
    // OpAdd( OpAdd(Val(1), Val(2)), OpAdd(Val(6), Val(3)) )
    private def interpretRec(
      expr: NumExpr,
      cont: A => A
    ): A =
      expr match {
        case Val(v) => cont(v)
        // Specializations
        case Add(Val(l), Val(r)) => cont(l + r)
        case Sub(Val(l), Val(r)) => cont(l - r)
        case Mul(Val(l), Val(r)) => cont(l * r)
        case Div(Val(l), Val(r)) => cont(l / r)
        case Mod(Val(l), Val(r)) => cont(l % r)
        // Non-specialized cases
        case Add(l, r) => interpretRec(l, TailCont(v => cont(v + interpretRec(r, Point))))
        case Sub(l, r) => interpretRec(l, TailCont(v => cont(v - interpretRec(r, Point))))
        case Div(l, r) => interpretRec(l, TailCont(v => cont(v / interpretRec(r, Point))))
        case Mul(l, r) => interpretRec(l, TailCont(v => cont(v * interpretRec(r, Point))))
        case Mod(l, r) => interpretRec(l, TailCont(v => cont(v % interpretRec(r, Point))))
      }

    def interpret(expr: NumExpr): A =
      interpretRec(expr, Point)
  }
}
 */
