package net.demo

import zio.=!=
import scala.annotation.implicitNotFound
import scala.reflect.ClassTag

//net.demo.EventsApp
object EventsApp extends App {

  sealed trait UnionTypes[T]
  object UnionTypes {
    implicit case object Ints    extends UnionTypes[Int]
    implicit case object Strings extends UnionTypes[String]
    implicit case object Bools   extends UnionTypes[Boolean]

    // scalac knows that T =:= Int here
    def oneOf[T](v: T)(implicit u: UnionTypes[T]): T =
      u match {
        case UnionTypes.Ints    => v
        case UnionTypes.Strings => v
        case UnionTypes.Bools   => v
      }

    def oneOf1[T](v: T)(implicit ev: Int with Boolean with String <:< T) =
      v match {
        case i: Int      => i
        case b: Boolean  => b
        case str: String => str
      }

    // union types
    implicitly[Int with String with Boolean <:< Int]
    implicitly[Int with String with Boolean <:< String]
    implicitly[Int with String with Boolean <:< Boolean]
  }

  // https://youtu.be/48fpPffgnMo?t=2610
  // zio.IsSubtypeOfOutput
  sealed trait EventA
  object EventA {
    final case class A(id: Long) extends EventA
    final case class B(id: Long) extends EventA
  }

  @implicitNotFound("\nThis operator requires ${In} to be a subtype of ${Out}.")
  trait IsSubtypeOf[-In, +Out] {
    def narrow(in: In): Out // narrow a subtype to supertype
  }

  object IsSubtypeOf {
    implicit def mk[A]: IsSubtypeOf[A, A] = (in: A) => in
  }

  object EventOps {
    implicit class Event(private val self: EventA) extends AnyVal {

      def narrow[T](implicit ev: EventA IsSubtypeOf T): T =
        ev.narrow(self)

      def widen[T <: EventA: ClassTag]: T =
        self match {
          case e: T => e
          case _ =>
            throw new IllegalArgumentException(
              s"Could not widen ${self.getClass.getName} to ${implicitly[ClassTag[T]].runtimeClass.getName}"
            )
        }
    }
  }

  import EventOps._
  import IsSubtypeOf._

  val a: EventA = EventA.A(1L) // .widen[EventA]

  EventA.A(1L).narrow[EventA]

  // a.narrow[Int]

  EventA.A(1L)

  a.widen[EventA.A] // works

  // Could not widen net.demo.EventsApp$EventA$A to net.demo.EventsApp$EventA$B
  a.widen[EventA.B] // blows up in runtime because

  sealed trait Reply { self =>
    def toOption: Option[Long] =
      self match {
        case Reply.Success(id) => Some(id)
        case Reply.Failure(_)  => None
      }
    def toEither: Either[String, Long] =
      self match {
        case Reply.Success(id)  => Right(id)
        case Reply.Failure(err) => Left(err)
      }
  }

  object Reply {
    final case class Success(id: Long)    extends Reply
    final case class Failure(err: String) extends Reply

    /*implicit class Ops(private val self: Reply) extends AnyVal {
      def toOption: Option[Long] =
        self match {
          case Success(id) => Some(id)
          case Failure(_) => None
        }
      def toEither: Either[String, Long] =
        self match {
          case Success(id) => Right(id)
          case Failure(err) => Left(err)
        }
    }*/
  }

  Reply.Success(999).toOption

  /*final case class Box[A](self: A) {
    def get[B](implicit ev: A IsSubtypeOf Option[B]): B =
      ev.narrow(self).get
  }*/

  @implicitNotFound("${A} is not a subtype of ${B}")
  trait Is[-A, +B] extends (A => B)
  object Is {
    implicit def refl[A]: Is[A, A] = (v1: A) => v1
  }
  final case class Bool[+A](private val value: A) {
    def negate(implicit ev: A Is Boolean): Bool[Boolean] = Bool(!ev(value))
  }

  Bool(true).negate
  // Bool(1).negate comp error

  // OR
  final case class Box[+A](private val value: A)
  object Box {
    implicit class BoxOps[+T](private val self: Box[Some[T]]) extends AnyVal {
      def get: T = self.value.get
    }
  }

  implicitly[Int <:< Int]
  implicitly[Some[Int] <:< Option[Int]] // Some[Int] is a subtype of Option[Int]
  implicitly[None.type <:< Option[Int]]

  val a1                   = Box(Some(1)).get
  val b1: Box[Option[Int]] = Box(None)

  // Box(1).get

  // Literal types: Type inhabited by a single constant value known at compile-time

  // type Tag <: Int with Singleton

  // This is a slightly better version

  // Literal-based singletons + path-dependent types
  @scala.annotation.implicitNotFound("\n ${T} is not a member of [0,1,2]")
  sealed trait IntSet[T <: Int with Singleton] { self =>
    def id: Int

    def ++[E <: Int with Singleton](other: IntSet[E]): Int =
      self.id + other.id

    def ++(other: Int): Int =
      self.id + other
  }

  object IntSet {
    implicit val ContainerIntoTrip: IntSet[0] = new IntSet[0] {
      override val id = 0
    }
    implicit val ContainerIntoContainer: IntSet[1] = new IntSet[1] {
      override val id = 1
    }
    implicit val PackageIntoContainer: IntSet[2] = new IntSet[2] {
      override val id = 2
    }

    def zero: IntSet[0] = ContainerIntoTrip

    // def zero[T <: 0](v: T):IntSet[0] = ContainerIntoTrip
    def one: IntSet[1] = ContainerIntoContainer
    def two: IntSet[2] = PackageIntoContainer

    // def apply[T <: Int with Singleton](v: T)(implicit numericSet: IntSet[v.type]): IntSet[v.type] = numericSet

    def mk[T <: Int with Singleton: IntSet](implicit ins: IntSet[T]): IntSet[T] = ins

    // def apply(v: Int)(implicit numericSet: IntSet[v.type]): IntSet[v.type] = numericSet

    def deserialize(v: Int): Option[IntSet[_]] =
      v match {
        case 0 => Some(IntSet.ContainerIntoTrip)
        case 1 => Some(IntSet.ContainerIntoContainer)
        case 2 => Some(IntSet.PackageIntoContainer)
        case 3 => None
      }
    // def mk[T <: Int with Singleton: IntSet]: IntSet[T] = implicitly[IntSet[T]]
    // def mk[T <: Int with Singleton: /*ValueOf:*/ IntSet]: IntSet[T] = implicitly[IntSet[T]]
  }

  IntSet.ContainerIntoTrip ++ IntSet.ContainerIntoContainer
  IntSet.ContainerIntoTrip ++ 5

  IntSet.mk[1] ++ 6
  IntSet.mk[2]

  IntSet.zero ++ IntSet.two

  IntSet.deserialize(10).fold[Option[IntSet[_]]](None)(Some(_))

  // IntSet.mk[3]

  val zero: IntSet[0] = IntSet.ContainerIntoTrip
  zero ++ IntSet.mk[1]

  val one = IntSet.mk[1]
  val two = IntSet.mk[2]
  one ++ two

  trait Contra[-A]

  def size[T](t: T)(implicit ev: Contra[Int] with Contra[String] <:< Contra[T]) =
    t match {
      case i: Int    => i
      case s: String => s.length
    }

  implicitly[Contra[Int] with Contra[String] <:< Contra[String]]
  implicitly[Contra[String] with Contra[String] <:< Contra[String]]

  // https://medium.com/virtuslab/mechanics-of-unboxed-union-types-in-scala-647d66d34e55
  // unboxed, statically type-safe encoding of union types
  /*

  type ¬[A]      = A => Nothing
  type ¬¬[A]     = ¬[¬[A]]
  type ∨[T, U]   = ¬[¬[T] with ¬[U]]
  type |∨|[T, U] = { type λ[X] = ¬¬[X] <:< (T ∨ U) }

  def match1[T: |∨|[Int, String]#λ](value: T) =
    value match {
      case i: Int    => i
      case s: String => s.length
    }

  def match0[T: (Int |∨| String)#λ](value: T) =
    value match {
      case i: Int    => i
      case s: String => s.length
    }
   */

  // "dev.zio"   %% "izumi-reflect" % "2.3.0",
  import izumi.reflect.Tag
  final case class Column[+T] private (private val map: Map[Tag[_], Any]) // Tag[_]
  object Column {
    implicit class HSetOps[C <: Column[_]](self: C) {
      // |+|
      def ++[A <: Column[_]](that: A)(implicit ev: C <:!< A): C with A =
        // println(self.map.keySet.size + " / " + that.map.keySet.size)
        new Column(self.map + that.map.head).asInstanceOf[C with A]
      // Col(self.map ++ that.map).asInstanceOf[C with A]

      def get[A: Tag](implicit ev: C <:< Column[A]): A =
        self.map(implicitly[Tag[A]]).asInstanceOf[A]
    }
    def apply[A: Tag](a: A): Column[A] =
      new Column(Map(implicitly[Tag[A]] -> a))
  }

  final case class CReply[T <: Column[_]](columns: T)

  import Column._
  val columns =
    Column(1) ++ Column("a") ++ Column(true) ++ Column(1.toByte) ++ Column(List(1, 2)) ++ Column(
      List("1", "2")
    ) // ++ Col(false)

  columns.get[Int]
  columns.get[Boolean]

  columns.get[List[Int]]
  columns.get[List[String]]

  // mmap.get[Nothing]

  CReply(columns).columns.get[Int]

  // Col[Int] with Col[String] with Col[Boolean] is a subtype of Col[Boolean]]
  implicitly[Column[Int] with Column[String] with Column[Boolean] <:< Column[Boolean]]
  implicitly[Column[Int] with Column[String] with Column[Boolean] <:< Column[String]]
  implicitly[Column[Int] with Column[String] with Column[Boolean] <:< Column[Int]]

  // Type constraint for type inequality in scala [duplicate]
  def m[A, B](a: A, b: B)(implicit ev: A =!= B)   = ()
  def m1[A, B](a: A, b: B)(implicit ev: A <:!< B) = ()

  def method[T <: Column[_]](reply: CReply[T]): CReply[T] = reply

  method(CReply(columns))

  // m(1, 2)
  // m1(1, 2)

  // def literal1[T <: Singleton: ValueOf](in: T): T = implicitly[ValueOf[T]].value
  def literal2[T <: Singleton: ValueOf]: T = implicitly[ValueOf[T]].value

  def literal(in: Any): in.type = {
    def mk[T: ValueOf]: T = implicitly[ValueOf[T]].value
    mk[in.type]
  }

  def literal1(in: Int): in.type = {
    def mk[T: ValueOf]: T = implicitly[ValueOf[T]].value
    mk[in.type]
  }

  val a0: 1    = literal(1)
  val b: 9.5   = literal(9.5)
  val c: "aaa" = literal("aaa")
  final val d  = c

  val a22 = literal2[22]

}
