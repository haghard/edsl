package net.demo

import scala.annotation.implicitNotFound

@implicitNotFound("\nRequirements failure: ${In} is not equal to ${Out}. Replace ${Out} with ${In}")
sealed trait IsEqualTo[-In, +Out] extends (In => Out) //IsNotEqualTo

object IsEqualTo {
  implicit def mk[A]: IsEqualTo[A, A] =
    new IsEqualTo[A, A] {
      override def apply(v1: A): A = v1
    }
}
