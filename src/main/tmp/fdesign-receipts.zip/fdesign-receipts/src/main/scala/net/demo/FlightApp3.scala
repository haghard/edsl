package net.demo

//import zio.=!=

object FlightApp3 extends App {

  /*
    abstract - Prevent creating instances of the sum types; anonymous instances can still be created. See the parse method creating instances.
    sealed - Prevent extending the types elsewhere but this file
    case class - So that we can still pattern match sum types
   */
  sealed trait Name
  object Name {
    sealed abstract case class OnlyFirstName(value: String)                          extends Name
    sealed abstract case class FirstAndLastName(first: String, last: String)         extends Name
    sealed abstract case class FullName(first: String, middle: String, last: String) extends Name
    def parse(raw: String): Option[Name] =
      if (???) Some(new OnlyFirstName(???) {})
      else if (???) Some(new FirstAndLastName(???, ???) {})
      else if (???) Some(new FullName(???, ???, ???) {})
      else None
  }

  sealed trait Airport
  final abstract class NYK extends Airport
  final abstract class LAL extends Airport
  final abstract class DEN extends Airport

  sealed trait Itinerary[A <: Airport]

  object Itinerary {

    final case class Departure[A <: Airport](departureTs: Long) extends Itinerary[A]
    final case class Arrival[A <: Airport](arrTs: Long)         extends Itinerary[A]

    final case class Both[A <: Airport, B <: Airport](
      leftLeg: Itinerary[A],
      rightLeg: Itinerary[B]
    ) extends Itinerary[A]

    implicit class Ops[A <: Airport](private val self: Itinerary[A]) extends AnyVal {
      def ~>[B <: Airport](that: Itinerary[B])(implicit ev: A ≠ B /*=!=*/ ): Itinerary[A] =
        Both[A, B](self, that)
    }

    def departure[A <: Airport](ts: Long) = Itinerary.Departure[A](ts)
    def arrival[A <: Airport](ts: Long)   = Itinerary.Arrival[A](ts)

    /*final case class Flight[A <: Airport, B <: Airport](
                                                         from: A, departureTs: Long,
                                                         to: B, arrivalTs: Long
                                                       ) extends Itinerary[A, B]

    final case class Both[A <: Airport, B <: Airport, C <: Airport](
       leftLeg: Itinerary[A, B], rightLeg: Itinerary[B, C]
     ) extends Itinerary[A, C]
     */
    /*implicit class ItineraryOps[A <: Airport, B <: Airport](private val self: Itinerary[A, B]) extends AnyVal {

      def ~>[C <: Airport](that: Itinerary[B, C]): Itinerary[A, C] =
        Itinerary.Both(self, that)
    }*/
  }

  import Itinerary._

  departure[NYK](1) ~> arrival[LAL](3)

  // departure[NYK](1) ~> arrival[NYK](3) //NYK should not be eq NYK !

  // TODO:
  // Flight[CHI with ATL with FLO] //&

  // https://antonkw.github.io/scala/selection-functions/

  // Selection function
  /*
  type J[R, A] = (A => R) => A

  def maxWith[Entity, Property](
    entities: List[Entity],
    order: Ordering[Property]
  ): J[Property, Entity] =
    (evaluate: Entity => Property) => entities.maxBy(evaluate)(order)

  type HP = Int
  final case class BMW(model: String, power: HP, msrp: Long)

  val bmws = List(BMW("230i", 255, 38395), BMW("330e", 288, 46295), BMW("M550i", 523, 60945))

  def bmwSelection[Property](implicit order: Ordering[Property]): J[Property, BMW] =
    maxWith[BMW, Property](bmws, order)

  val bmwSelectionByHp: J[HP, BMW] = bmwSelection[HP]

  val powerfulBmw: BMW = bmwSelectionByHp(_.power)

  /*
  Quantifier functionsPermalink
  There are also quantifier functions that provide not a selected object but a property that “causes” a choice.
   */
  type K[R, A] = (A => R) => R

  def overline[R, A]: J[R, A] => K[R, A] =
    (select: J[R, A]) =>
      (eval: A => R) => {
        val selected: A  = select(eval)
        val evaluated: R = eval.apply(selected)
        evaluated
      }

  val maxPowerOfBmw = overline(bmwSelectionByHp)(_.power)

  val bmwPredicateSelection = bmwSelection[Boolean]
  val matched               = bmwPredicateSelection(_.model == "M550i")

  def pair[R, A, B]: J[R, A] => J[R, B] => J[R, (A, B)] =
    (selectA: J[R, A]) =>
      (selectB: J[R, B]) =>
        (evaluateAB: ((A, B)) => R) => {
          def pickUpB(candidateA: A): B => R =
            (candidateB: B) => evaluateAB((candidateA, candidateB))

          val a: A =
            selectA(candidateA =>
              evaluateAB(
                candidateA -> selectB(pickUpB(candidateA))
              )
            )

          val b: B =
            selectB(candidateB => evaluateAB(a, candidateB))

          (a, b)
        }

  type Password = (Int, Char)

  val passwordCriteria: Password => Boolean = { case (a, b) =>
    a == 7 && b == 'p'
  }

  def bruteforceInt[T](implicit order: Ordering[T]): J[T, Int] =
    maxWith((1 to 9).toList, order)

  def bruteforceChar[T](implicit order: Ordering[T]): J[T, Char] =
    maxWith(('a' to 'z').toList, order)

  val password = pair[Boolean, Int, Char]
    .apply(bruteforceInt)(bruteforceChar)(passwordCriteria)

  println(s"Secret: $password") // Secret: (7,p)

  def product[R, A]: List[J[R, A]] => J[R, List[A]] =
    (functions: List[J[R, A]]) =>
      (listEval: List[A] => R) =>
        functions match {
          case evalFun :: restEvalFunctions =>
            val a: A =
              evalFun((candidate: A) =>
                listEval(
                  candidate ::
                    product
                      .apply(restEvalFunctions)
                      .apply(restCandidates => listEval(candidate :: restCandidates))
                )
              )

            val as: List[A] =
              product(restEvalFunctions)(rest => listEval(a :: rest))

            a :: as

          case Nil => Nil
        }

  def greedyProduct[R, A]: List[J[R, A]] => J[R, List[A]] =
    (selections: List[J[R, A]]) => { (evalList: List[A] => R) =>
      selections match {
        case eval :: es =>
          val candidate: A  = eval((candidate: A) => evalList(candidate :: List()))
          val rest: List[A] = greedyProduct(es)(arg => evalList(candidate :: arg))

          candidate :: rest

        case Nil => Nil
      }
    }

  val stringEquality: String => (List[Char] => Int) =
    target =>
      guessed =>
        target
          .zip(guessed.mkString)
          .count { case (c1, c2) => c1 == c2 }

  val result = // List(p, a, s, s, w, o, r, d)
    greedyProduct(List.fill(8)(bruteforceChar[Int]))(stringEquality("password"))

  // Selection monad
  final case class Selection[R, A](e: J[R, A])

  def flip[A, B, C](f: A => B => C)(x: B)(y: A) =
    f(y)(x)

  type USD = Long

  final case class EvCar(name: String, price: USD)

  val evCars: List[EvCar] = ???

  implicit def makeMonad[R] = new Monad[Selection[R, *]] {
    override def flatMap[A, B](fa: Selection[R, A])(f: A => Selection[R, B]): Selection[R, B] =
      Selection((p: B => R) => f(fa.e(a => p(flip(f.andThen(_.e))(p)(a)))).e(p))

    override def map[A, B](fa: Selection[R, A])(f: A => B): Selection[R, B] =
      Selection((p: B => R) => f(fa.e(a => p(f(a)))))

    override def pure[A](x: A): Selection[R, A] = Selection(_ => x)

    override def tailRecM[A, B](a: A)(f: A => Selection[R, Either[A, B]]): Selection[R, B] = ???
  }


  val usdSelectionMonad: Monad[λ[a => Selection[USD, a]]] = makeMonad[USD]

  def evSelectionWithLimit(limit: USD) =
    Selection[USD, EvCar]((eval: EvCar => USD) =>
      evCars.filter(_.price < limit).maxBy(eval)
    )

  val evCarSelection: Selection[USD, EvCar] = usdSelectionMonad.flatMap(bmwSelectionByPrice)((bmw: BMW) =>
    evSelectionWithLimit(100000 - bmw.msrp)
  )
   */

}
