package net.demo

//import java.nio.charset.StandardCharsets
//import java.security.MessageDigest
import java.util.{Base64, UUID}
import scala.collection.mutable
import scala.reflect.ClassTag
import scala.util.Try
import HashRingBuffer.Hash

object HashRingBuffer {

  type Hash = Array[Byte]

  def nextPowerOfTwo(value: Int): Int =
    1 << (32 - Integer.numberOfLeadingZeros(value - 1))

  /*def sha256(correlationId: String, source: UUID, destination: UUID): Hash =
      MessageDigest
        .getInstance("SHA3-256")
        .digest(s"$correlationId/${source.toString}/${destination.toString}".getBytes(StandardCharsets.UTF_8))*/

  def base64Encode(bs: Hash): String =
    new String(Base64.getUrlEncoder.withoutPadding.encode(bs))

  def base64Decode(str: String): Option[Array[Byte]] =
    Try(Base64.getUrlDecoder.decode(str)).toOption

  /*
  private val capacity = "capacity"
  private val entries = "entries"

  implicit def format[T: ClassTag](implicit
                                   F: Format[T] //F for values
                                  ): Format[HashRingBuffer[T]] = {
    def error = throw new Exception(s"${classOf[HashRingBuffer[_]].getSimpleName} play-json format error")

    Format[HashRingBuffer[T]](
      Reads[HashRingBuffer[T]] { ringBufJson: JsValue =>
        ringBufJson match {
          case JsObject(kvs) =>
            var rb = HashRingBuffer[T](kvs(HashRingBuffer.capacity).as[Int])
            kvs(HashRingBuffer.entries) match {
              case JsArray(item) =>
                item.foreach {
                  case JsArray(item) if item.size == 2 =>
                    (item(0), item(1)) match {
                      case (JsString(v), jsValue) =>
                        rb = rb.:+(
                          base64Decode(v).getOrElse(error),
                          F.reads(jsValue).getOrElse(error)
                        )
                      case _ => error
                    }
                  case _ => error
                }
              case _ => error
            }
            JsSuccess(rb)
          case _ =>
            error
        }
      },
      Writes(_.toJson)
    )
  }*/

  def apply[T: ClassTag]() = new HashRingBuffer[T](1 << 6)

  def apply[T: ClassTag](capacity: Int) = new HashRingBuffer[T](capacity)
}

/** A ring buffer or circular buffer is a pre-allocated finite chunk of memory that is accessed in a circular fashion to
  * give the illusion of an infinite one. The N + 1 element of a ring buffer of size N is the first element again.
  *
  * This implementation has a hashtable-like functionality build-in for cases when not only we need to be able to answer
  * "Have I seen (correlationId, source, destination) tuple?" kind of questions, but also it allows you to get the
  * associated with the tuple value back.
  */
final case class HashRingBuffer[T: ClassTag] private (
  private val capacity: Int,
  private val hashes: Array[Hash],
  private val values: Array[T],
  private val head: Long,
  private val tail: Long
) { self =>

  private def this(capacity: Int) =
    this(
      HashRingBuffer.nextPowerOfTwo(capacity),
      Array.ofDim[Hash](HashRingBuffer.nextPowerOfTwo(capacity)),
      Array.ofDim[T](HashRingBuffer.nextPowerOfTwo(capacity)),
      0L,
      0L
    )

  def add(hash: Hash, value: T): HashRingBuffer[T] =
    :+(hash, value)

  def :+(hash: Hash, value: T): HashRingBuffer[T] = {
    val ind = (tail % capacity).toInt
    hashes(ind) = hash
    values(ind) = value

    val wrapPoint = tail - capacity
    if (head <= wrapPoint) self.copy(head = head + 1L, tail = tail + 1L)
    else self.copy(tail = tail + 1L)
  }

  def find(hash: Hash): Option[T] = {
    var result: Option[T] = None
    if (tail > head) {
      var i = tail

      // walk backwards
      do {
        val ind             = (i % capacity).toInt
        val candidate: Hash = hashes(ind)
        if (java.util.Arrays.equals(hash, candidate))
          result = Some(values(ind))

        i -= 1
      } while (result.isEmpty && i >= head)
    }
    result
  }

  def size(): Int = (tail - head).toInt

  /*private def toJson(implicit F: Format[T]): JsObject = {
    def toJsArray: JsArray = {
      val builder = mutable.ArrayBuilder.make[JsArray]()
      if (tail > head) {
        var i = head
        do {
          val ind = (i % capacity).toInt
          builder += JsArray(Seq(JsString(base64Encode(hashes(ind))), F.writes(values(ind))))
          i += 1
        } while (i < tail)
      }
      JsArray(builder.result())
    }

    JsObject(Map(HashRingBuffer.capacity -> JsNumber(capacity), HashRingBuffer.entries -> toJsArray))
  }*/

  override def toString = {
    val sb = new mutable.StringBuilder()
    if (tail > head) {
      var i = head
      do {
        val ind = (i % capacity).toInt
        sb
          .append(HashRingBuffer.base64Encode(hashes(ind)))
          .append(":")
          .append(values(ind))
          .append(",")

        i += 1
      } while (i < tail)

      s"RingBuffer($capacity, [${sb.toString()}])"
    } else "RingBuffer([])"
  }
}
