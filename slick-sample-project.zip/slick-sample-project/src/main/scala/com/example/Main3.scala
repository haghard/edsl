package com.example

import akka.actor.ActorSystem
import akka.stream.{ActorAttributes, ActorMaterializerSettings, Supervision}
import akka.stream.scaladsl.{Flow, Sink, Source}
import com.typesafe.config.ConfigFactory

import java.util.concurrent.ThreadLocalRandom
import scala.concurrent.duration.Duration
import scala.concurrent.{Await, Future}
import scala.util.control.NonFatal

//runMain com.example.Main3
object Main3 extends App {

  /*sealed trait Env
  object Env {
    case object Production extends Env
    case object B extends Env
  }

  implicit val c = scala.concurrent.ExecutionContext.Implicits.global

  val originalResponseF = Future {
    println("0.queryHelper.getBrokerageAccountsInBatch(req, detailedView)")
    Thread.sleep(1000)
    println("1.queryHelper.getBrokerageAccountsInBatch(req, detailedView)")
  }(c)

  //queryHelper.getBrokerageAccountsInBatch(req, detailedView)

  val env = Env.B
  val f =

    if (env == Env.Production)
      originalResponseF
    else {
      for {
        originalResponse <- originalResponseF
        _ <- Future {
          println("2 (req, detailedView)")
          Thread.sleep(1000)
          println("3 (req, detailedView)")
        }
      } yield {
        println("ELSE")
      }
    }

  Await.result(f, Duration.Inf)*/

  implicit val sys = ActorSystem("tmp", ConfigFactory.load("application.conf"))
  implicit val d = sys.dispatcher


  val src = Source.fromIterator(() => Iterator.range(0, 15))

  val supervisionStrategy = ActorAttributes.supervisionStrategy({
    /*
    case t: InvalidSentinelRequest =>
      //log.errorAlert(s"SentinelRequestException: Error encountered while batch processing initiated Withdrawals: ${t.getMessage}", t)
      Supervision.Resume
    case t: SentinelException =>
      //log.errorAlert(s"SentinelException: Error encountered while batch processing initiated Withdrawals: ${t.getMessage}", t)
      Supervision.Resume
   */

    case NonFatal(t) =>
      println(s"Error encountered while batch processing: ${t.getMessage}")
      Supervision.Resume
  })

  val M = akka.stream.Materializer.matFromSystem(sys)

  case class FB(i: Int) {
    def isReady(d: Double, i: Int): Boolean = {
      println(s"$d - $i")
      true
    }
  }

  println(M.settings.supervisionDecider)

  //ActorMaterializerSettings(sys)
  //val M = akka.stream.SystemMaterializer(sys).materializer

  /*val f =
    src
      .via(eligibilityFilter)
      .via(synchronizationFlow)
      .withAttributes(supervisionStrategy)
      .runWith(Sink.seq)(M)*/

  /*
  val b = true

  val fb = FB(1)

  val f1 =
    Source.fromIterator(() => Iterator.range(0, 150))
      .filter { i =>
        val b = ThreadLocalRandom.current().nextDouble()
        b > .5 & fb.isReady(b, i)
      }
      .withAttributes(supervisionStrategy)
      .runWith(Sink.seq)(M)

  val seq = Await.result(f1, Duration.Inf)
  //println(s"OUT: [${seq.mkString(",")}]")

  sys.terminate()

  def eligibilityFilter: Flow[Int, Int, akka.NotUsed] =
    Flow[Int]
      .mapAsync(1) { n =>
        Future {
          val r = n + 1
          if(ThreadLocalRandom.current().nextDouble() > .9) throw new Exception(s"Boom eligibilityFilter($r)")
          //println("eligibilityFilter: " + r)
          r
        }
      }
      .mapAsync(1) { n =>
        Future {
          Thread.sleep(100)
          if (ThreadLocalRandom.current().nextDouble() > .9) throw new Exception(s"Boom eligibilityFilter2($n)")
          n
        }
      }

  def synchronizationFlow: Flow[Int, String, akka.NotUsed] =
    Flow[Int].mapAsync(1) { n =>
      Future {
        val r = n.toString

        if(ThreadLocalRandom.current().nextDouble() > .9) throw new Exception(s"Boom synchronizationFlow($r)")
        //println("synchronizationFlow: " + r)
        r
      }
    }.mapAsync(1) { n =>
      Future {
        Thread.sleep(100)
        if (ThreadLocalRandom.current().nextDouble() > .9) throw new Exception(s"Boom synchronizationFlow2($n)")
        n
      }
    }
  */

  /*
  sealed abstract case class JpmConfig(companyId: String, queueEnabled: () => Boolean)
  object JpmConfig {
    def apply(companyId: String, queueEnabled: Boolean) = new JpmConfig(companyId, () => queueEnabled){}
    def lazyLoad(companyId: String, queueEnabled: () => Boolean) = new JpmConfig(companyId, queueEnabled){}
  }
  JpmConfig("a", true)
  JpmConfig.lazyLoad("a", { () =>
    ThreadLocalRandom.current().nextBoolean()
  })
  */

  val myDisp = sys.dispatchers.lookup("akka.actor.my-dispatcher")

  def calc(id: Int, sleep: Int): Future[Long] =
    Future {
      println(s"${Thread.currentThread().getName}: Start $id")
      Thread.sleep(sleep)
      println(s"${Thread.currentThread().getName}: Stop $id")
      System.currentTimeMillis()
    }(myDisp) //scala.concurrent.ExecutionContext.Implicits.global

  /*
    {"affinity-pool-executor":
      {"fair-work-distribution":
        {"threshold":128},"idle-cpu-level":5,"parallelism-factor":0.8,"parallelism-max":64,"parallelism-min":4,
        "queue-selector":"akka.dispatch.affinity.FairDistributionHashCache",
        "rejection-handler":"akka.dispatch.affinity.ThrowOnOverflowRejectionHandler","task-queue-size":512},

        "attempt-teamwork":"on","default-executor":{"fallback":"fork-join-executor"},"executor":"default-executor","fork-join-executor":{"parallelism-factor":1,"parallelism-max":64,"parallelism-min":8,"task-peeking-mode":"FIFO"},"mailbox-requirement":"","shutdown-timeout":"1s","thread-pool-executor":{"allow-core-timeout":"on","core-pool-size-factor":3,"core-pool-size-max":64,"core-pool-size-min":8,"fixed-pool-size":"off","keep-alive-time":"60s","max-pool-size-factor":3,"max-pool-size-max":64,"max-pool-size-min":8,"task-queue-size":-1,"task-queue-type":"linked"},"throughput":5,"throughput-deadline-time":"0ms","type":"Dispatcher"}

   */
  println(sys.settings.config.getConfig("akka.actor.my-dispatcher"))

  val f = calc(0, 2000).fallbackTo(calc(0, 2000))
  //val f = calc(0, 2000).recoverWith({ case _=> calc(0, 2000) })

  /*val f =
    for {
      _ <- Future.unit
      fa = calc(0, 2000)
      fb = calc(1, V.b12100)
      //res <- Future.sequence(Seq(fut(0, 3000), fut(1, 10)))
      a <- fa
      b <- fb
    } yield println(s"Exit: $a/$b")*/

  Await.result(f, Duration.Inf)
  sys.terminate()

}
