package com

import java.util.UUID
import java.sql.{Time, Timestamp}
import java.time.{Instant, LocalTime}
import java.util.concurrent.ThreadFactory
import java.util.concurrent.atomic.{AtomicInteger, AtomicLong}

import com.codahale.metrics.MetricRegistry
import com.example.Main.metrics
import slick.dbio.{DBIO, DBIOAction, Effect, NoStream, SynchronousDatabaseAction}
import slick.jdbc.{GetResult, JdbcBackend, PositionedParameters, PositionedResult, SetParameter}
import slick.jdbc.H2Profile.api._

import scala.concurrent.duration.Duration
import scala.concurrent.{ExecutionContext, Future}

package object example {

  case class Daemons(name: String) extends ThreadFactory {
    private def namePrefix = s"$name-thread"

    private val threadNumber       = new AtomicInteger(1)
    private val group: ThreadGroup = Thread.currentThread().getThreadGroup

    override def newThread(r: Runnable) = {
      val t = new Thread(group, r, s"$namePrefix-${threadNumber.getAndIncrement()}", 0L)
      t.setDaemon(true)
      t
    }
  }

  final case class Id(value: String) extends AnyVal {
    override def toString = value
  }

  object SetParameterFactory {

    def apply[T](implicit mapping: BaseColumnType[T]): SetParameter[T] = (v: T, pp: PositionedParameters) => {
      val pos = pp.pos + 1
      mapping.setValue(v, pp.ps, pos)
      pp.pos = pos
    }
  }
  //implicit val instantColumnType: BaseColumnType[Instant] = MappedColumnType.base[Instant, Timestamp](Timestamp.from, _.toInstant)

  implicit object GetRes extends GetResult[(Option[UUID], Instant)] {
    def apply(rs: PositionedResult) = {
      println(s"${Thread.currentThread().getName} READ ***  ")
      (rs.nextStringOption().map(UUID.fromString), rs.nextTimestamp().toInstant)
    }
  }

  object SameThreadExecutionContext extends scala.concurrent.ExecutionContextExecutor {
    def execute(runnable: Runnable): Unit = runnable.run()
    def reportFailure(cause: Throwable): Unit = throw cause
  }

  //java.time.Instant -> java.sql.Timestamp
  implicit val instantColumnType: BaseColumnType[Instant] =
    MappedColumnType.base[Instant, Timestamp](Timestamp.from, _.toInstant)

  implicit val instantSetParameter: SetParameter[Instant] =
    SetParameterFactory[Instant]

  /*implicit val Reader = GetResult { r =>
    //(Option[UUID], Instant)
      r.<<?
    //Coffee(r.<<, r.<<, r.<<, r.<<, r.<<)
  }*/

  implicit class RichFutures[T](val fa: Future[T]) extends AnyVal {
    private def timeout(t: Long): Future[Boolean] = {
      import java.util._
      val timer = new Timer(true)
      val p = scala.concurrent.Promise[Boolean]()
      timer.schedule(new TimerTask {
        override def run() = {
          p.success(false)
          timer.cancel()
        }
      }, t)
      p.future
    }

    def withTimeoutFail(implicit duration: Duration, ex: ExecutionContext): Future[T] = {
      Future.firstCompletedOf(Seq(fa, timeout(duration.toMillis))).map {
        case false     ⇒ throw new Exception("IO timeout")
        case result: T ⇒ result
      }
    }

    def withFallbackStrategy(fallBackAction: ⇒ Future[T])(implicit ex: ExecutionContext): Future[T] =
      fa recoverWith {
        case e: Throwable ⇒
          //println(e.getMessage)
          fallBackAction recoverWith { case _ ⇒ fa }
      }

    def withLatencyLogging(name: String)(implicit ex: ExecutionContext): Future[T] = {
      val startTime = System.currentTimeMillis
      fa.transform { _.map { r =>
        val latency = System.currentTimeMillis - startTime
        println(s"Future $name took $latency ms to process")
        r
      }
    }

      /*inner map { r ⇒
        val latency = System.currentTimeMillis - startTime
        println(s"Future $name took $latency ms to process")
        r
      }*/
    }
  }

  //ExecutionContext.Implicits.global

  class MeasuredDatabase(metrics: com.codahale.metrics.MetricRegistry) {
    private val meter = metrics.meter("counters")
    private val hist  = metrics.histogram("timing")

    def mark(): Unit = meter.mark()

    def timeTillNow(start: Long): Unit = {
      hist.update(System.currentTimeMillis() - start)
    }

    def readCount: Long = meter.getCount

    def readSnapshot: com.codahale.metrics.Snapshot = hist.getSnapshot()
  }

  //impl.ExecutionContextImpl.fromExecutor(null: Executor)
  //implicit val ec = SameThreadExecutionContext

  implicit class Slick3DBSyntax[E <: Effect, R, S <: NoStream](val dbio: slick.dbio.DBIOAction[R, S, E]) extends AnyVal {

    def transactionallyMeasured(
      implicit metrics: MeasuredDatabase
    ): slick.dbio.DBIOAction[R, NoStream, E with slick.dbio.Effect.Transactional] = {
      /*DBIO.successful(System.nanoTime()).flatMap { startTs: Long =>
        dbio.transactionally.map { r: R =>
          val latency = System.currentTimeMillis - startTs
          println(s"Future took $latency ms to process")
          r
        }(ec)
      }*/

      /*DBIO.successful((System.nanoTime(), null.asInstanceOf[R])).flatMap { case (startTs: Long, r: R) =>
        //m.inc()
        dbio.transactionally.map { r: R => r }(ec)
      }*/

      //DBIO.successful(() => System.currentTimeMillis())

      /*
      DBIO.successful({
        println(s"****************** Before0: ${Thread.currentThread().getName} *******************")
        //metrics.inc()
        () => System.currentTimeMillis()
      }).flatMap { f =>
        val startTs = f()
        println(s"****************** Before1: ${Thread.currentThread().getName} *******************")
        dbio.transactionally.map { r =>
          val latency = System.currentTimeMillis - startTs
          println(s"************************* DBIO: Execution of prepared update took $latency µs")
          r
        }(SameThreadExecutionContext)
      }(SameThreadExecutionContext)
      */

      dbio.transactionally

      DBIO.successful({
        println(s"****************** Before: ${Thread.currentThread().getName} *******************")
        System.currentTimeMillis()
      }).zipWith(dbio.transactionally) { case (startTs, r) =>
        metrics.mark()
        metrics.timeTillNow(startTs)

        println(s"****************** After: ${Thread.currentThread().getName} *******************")
        val latency = System.currentTimeMillis - startTs
        println(s"************************* DBIO: Execution of prepared update took $latency µs")
        r
      }(SameThreadExecutionContext)
    }
  }
  
  /*
  def onlyOne[T](action: DBIO[Seq[T]]): DBIO[T] =
    action.flatMap { ms =>
      ms match {
        case m +: Nil => DBIO.successful(m)
        case ys       => DBIO.failed(new RuntimeException(s"Expected 1 result, not ${ys.length}"))
      }
    }(SameThreadExecutionContext)

  import scala.util.Try
  def exactlyOne[T](action: DBIO[Seq[T]]): DBIO[Try[T]] = onlyOne(action).asTry
  */
  //exec(exactlyOne(happy))
  // res26: Try[MessageTable#TableElementType] = Success(
  //   Message("HAL", "I'm sorry, Dave. I'm afraid I can't do that.", 10L)
  // )

  //exec(exactlyOne(boom))


}
