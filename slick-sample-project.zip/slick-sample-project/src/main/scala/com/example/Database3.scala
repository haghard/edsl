package com.example

import slick.jdbc.JdbcBackend.Database

final case class Database3(db: Database) {
  db.executor.executionContext
  //println("------0 DB executor: " + db.executor.executionContext.hashCode)
}

