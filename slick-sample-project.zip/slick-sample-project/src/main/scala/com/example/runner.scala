package com.example


//import java.util.concurrent.Executors
//import scala.concurrent.ExecutionContext
import cats.effect.{ExitCode, IO, IOApp}
import javax.management.{MBeanInfo, MBeanServer, ObjectName}
import slick.util.AsyncExecutor
//import cats.effect._
import cats.implicits._
import scala.concurrent.duration._

//runMain com.example.runner
object runner extends IOApp {

  //val parallelism                   = 4
  //Executors.newWorkStealingPool
  //implicit val ec                   = ExecutionContext.fromExecutor(Executors.newFixedThreadPool(parallelism, Daemons("background")))

  //implicit val cs: ContextShift[IO] = IO.contextShift(ec)
  //implicit val timer                = cats.effect.IO.timer(ec)

  def par2[A, B](ioa: IO[A], iob: IO[B]): IO[(A, B)] =
    (ioa.start, iob.start).tupled.bracket { case (fa, fb) =>
      (fa.join, fb.join).tupled
    } { case (fa, fb) => fa.cancel >> fb.cancel }

  def fib(n: Int, a: Long = 0, b: Long = 1): IO[Long] =
    IO(a + b).flatMap { b2 =>
      if (n > 0) fib(n - 1, b, b2) else IO.pure(a)
    }

  def par02[A, B](ioa: IO[A], iob: IO[B]): IO[(A, B)] =
    ioa.start.bracket { fa =>
      iob.start.bracket { fb =>
        for {
          a <- fa.join
          b <- fb.join
        } yield (a, b)
      }(_.cancel)
    }(_.cancel)


  def ping(): IO[Unit] = {
    IO(println(Thread.currentThread().getName + " Ping ")) >> timer.sleep(1.seconds) >> ping()
  }

  def reporter(mBeanServer: MBeanServer, mBeanName: ObjectName): IO[Unit] =
    IO {
      //println(s"IsRegistered: ${mBeanServer.isRegistered(mBeanName)}")
      val beanInfo: MBeanInfo = mBeanServer.getMBeanInfo(mBeanName)
      println("******************************")
      beanInfo.getAttributes.foreach { attr =>
        val name = attr.getName
        println(name + " : " + mBeanServer.getAttribute(mBeanName, name).asInstanceOf[Int])
      }
    } >> timer.sleep(2.seconds) // >> reporter(mBeanServer, mBeanName)

  def livecheck(): IO[Unit] = {
    IO(println(Thread.currentThread().getName + " alive ")) >> timer.sleep(1.seconds) >> livecheck()
  }

  def ping2(): IO[Unit] =
    IO(println(Thread.currentThread().getName + " Ping ")) >> timer.sleep(1.seconds)

  val executorName = "slick3"
  val conPoolSize = Runtime.getRuntime.availableProcessors()
  val slickExecutor: AsyncExecutor =
    AsyncExecutor(executorName, minThreads = conPoolSize, maxThreads = conPoolSize, queueSize = 32,
      maxConnections = conPoolSize, keepAliveTime = 1.minute, registerMbeans = true)

  override def run(args: List[String]): IO[ExitCode] =
    for {
      //dbs <- IO { Databases[IO](5) }
      reporter <- reporter(
        java.lang.management.ManagementFactory.getPlatformMBeanServer,
        new ObjectName(s"slick:type=AsyncExecutor,name=$executorName")
      ).foreverM.start

      //pinger <- ping2().foreverM.start
      //pinger <- ping().start
      _      <- timer.sleep(6.seconds) >> reporter.cancel >> IO(println("Canceled"))
      //_    <- pinger.join >> IO(println("bye-bye"))
    } yield ExitCode.Success
}
