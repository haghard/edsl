package com.example

import cats.effect.Sync
import slick.util.AsyncExecutor

import scala.concurrent.duration._
import com.example.runner1.{conPoolSize, executorName}
import com.zaxxer.hikari.{HikariConfig, HikariDataSource}
import slick.jdbc.JdbcBackend.Database


trait Databases[F[_]] {
  def database: Database3
}


object Databases {

  def apply[F[_] : Sync](n: Int): Databases[F] =
    new Databases[F] {

      def slickExecutor(): AsyncExecutor =
        AsyncExecutor(executorName, minThreads = conPoolSize, maxThreads = conPoolSize, queueSize = 1 << 3,
          maxConnections = conPoolSize, keepAliveTime = 1.minute, registerMbeans = true)

      val database: Database3 = {
        val dsConf = new HikariConfig()
        dsConf.setJdbcUrl("jdbc:h2:mem:demoDb;DB_CLOSE_DELAY=-1")
        dsConf.setDriverClassName("org.h2.Driver")
        dsConf.setConnectionTimeout(3000)
        dsConf.setMaximumPoolSize(conPoolSize)
        dsConf.setIdleTimeout(1.minute.toMillis)
        dsConf.setTransactionIsolation("TRANSACTION_SERIALIZABLE")
        dsConf.addDataSourceProperty("cachePrepStmts", "true")
        dsConf.addDataSourceProperty("prepStmtCacheSize", "10")
        dsConf.addDataSourceProperty("prepStmtCacheSqlLimit", "1024")
        val dataSrc = new HikariDataSource(dsConf)
        Database3(Database.forDataSource(dataSrc, Some(conPoolSize), slickExecutor()))
      }
    }
}
