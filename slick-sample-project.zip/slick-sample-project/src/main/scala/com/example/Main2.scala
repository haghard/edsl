package com.example

import akka.actor.ActorSystem
import akka.stream.{IOResult, Materializer, OverflowStrategy}
import akka.stream.scaladsl.{Flow, GraphDSL, Merge, Sink, Source}
import com.example.ring.HashRingBuffer

import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.time.format.DateTimeFormatter
import java.time.{Clock, Instant, LocalDate, LocalTime, ZoneId, ZonedDateTime}
import java.util.TimeZone
import java.util.concurrent.ThreadLocalRandom
import scala.concurrent.duration.Duration
import scala.concurrent.{Await, Future, Promise}
import scala.util.control.NonFatal
import scala.util.{Failure, Success}


//runMain com.example.Main2
object Main2 extends App {


  implicit val sys = ActorSystem("b")
  implicit val ec = sys.dispatcher

  /*
  Source
    .fromIterator(() => (0 to 100).iterator)
    .map { i =>
      val rnd = java.util.concurrent.ThreadLocalRandom.current().nextDouble()
      if(rnd > 0.9) {
        throw new ArithmeticException("Arithmetic boom !!!")
      } else if(rnd > 0.85) {
        throw new NumberFormatException("NumberFormat boom !!!")
      } else
      i
    }
    .mapMaterializedValue(_ => "")
    //.to(Sink.foreach { i: String => ??? })


  val src: Source[Int, akka.NotUsed] = Source.fromIterator(() => (0 to 100).iterator)

  val p = Promise[IOResult]()
  val src1: Source[Int, Future[IOResult]] =
    src
      .mapMaterializedValue(_ => p.future)
      .via(Flow[Int].buffer(1, OverflowStrategy.backpressure).watchTermination() { (_, done) =>
        done.onComplete {
          case Success(_) => p.trySuccess(IOResult(0))
          case Failure(_) => p.trySuccess(IOResult(-1))
        }})

  val sink = Sink.foreach { i: Int => println(i.toString) }
  val r = Await.result(src1.to(sink).run(), Duration.Inf)
  println(r)
  */


  /*val f = Future[Either[String, Int]]{
    println("Sleeping start!")
    Thread.sleep(100)
    println("Sleeping end.")
    //Right(1)
    Left("boom")
  }.map { case Right(r) => println("Ok " + r) }

  Await.result(f, Duration.Inf)*/

  val mapping = Map(1 -> 1, 2 -> 2, 3 -> 3)

  /*val fA = Future {
    Thread.sleep(1000)
    val r : Either[String, Int] =
      if(ThreadLocalRandom.current().nextBoolean()) Right(1) else Left("err")
    Thread.sleep(1000)
    r
  }.failed
  fA.onComplete { r => println("Res: " + r) }*/


  val MD = MessageDigest.getInstance("SHA3-256")
  //val MD = MessageDigest.getInstance("MD5")
  val a = MD.digest("textA".getBytes(StandardCharsets.UTF_8))
  val b = MD.digest("textB".getBytes(StandardCharsets.UTF_8))
  val c = MD.digest("textC".getBytes(StandardCharsets.UTF_8))
  val d = MD.digest("textD".getBytes(StandardCharsets.UTF_8))
  val e = MD.digest("textE".getBytes(StandardCharsets.UTF_8))
  val f = MD.digest("textF".getBytes(StandardCharsets.UTF_8))

  val rb = HashRingBuffer(3)
  /*rb.:+(a)
  rb.:+(b)
  rb.:+(c)
  rb.:+(d)
  println(rb)
  rb.:+(e)*/

  //println(rb)
  println(rb)
  println(rb.contains(d))


  val f1 =
    Future {
     Thread.sleep(2000)
    }.flatMap { _ =>
      Future {
        if(ThreadLocalRandom.current().nextBoolean()) throw new Exception("Inner boom!") else 1
      }.recover {
        case NonFatal(ex) =>
          println(ex.getMessage)
          0
      }
    }
      .map(_ => Right(1))
      .recover { case NonFatal(ex) => Left(ex) }

  println(Await.result(f1, Duration.Inf))


  val endPeriodDate = LocalDate.now()

  ZonedDateTime.of(endPeriodDate, LocalTime.MAX, TimeZone.getDefault.toZoneId)

  val now = Instant.now()
  now.atZone(TimeZone.getDefault.toZoneId)
  now.atZone(ZoneId.of("US/Central"))

  final case class Person(name: String, age: Int)
  //object Person

  sealed trait NameOrAge
  object NameOrAge {
    final case class Name(name: String) extends NameOrAge
    final case class Age(age: Int) extends NameOrAge
  }

  val or: NameOrAge = ???
  or match {
    case NameOrAge.Name(name) => ???
    case NameOrAge.Age(age) => ???
  }


  sealed trait TransactionType
  object TransactionType {
    abstract class AbsTransactionType(val str: String) extends TransactionType
    case object _0 extends AbsTransactionType("ACH")
    case object _1 extends AbsTransactionType("IC")
  }

  //an approximate ADT
  final case class TrType private(name: String)
  object TrType {
    //smart con-tor to guard TransactionType construction
    def fromStr(name: String): Option[TrType] = {
      //some validation here
      if (name.length == 8 && name.toList.forall(_.isLetter) && name.startsWith(""))
        Some(TrType(name)) else None
    }
  }

  TrType.fromStr("")

  sealed trait UserName
  object UserName {
    /*
      abstract - Prevent creating instances of the sum types; anonymous instances can still be created. See the parse method creating instances.
      sealed - Prevent extending the types elsewhere but this file
      case class - So that we can still pattern match sum types
    */
    sealed abstract case class FirstName(value: String) extends UserName
    sealed abstract case class FirstAndLastName(first: String, last: String) extends UserName
    sealed abstract case class FullName(first: String, middle: String, last: String) extends UserName

    //smart con-tor to guard TransactionType construction
    def fromStr(str: String): Either[String, UserName] = {
      val segments = str.trim.split(".")
      segments.size match {
        case 1 => Right(new FirstName(segments(0)) {})
        case 2 => Right(new FirstAndLastName(segments(0), segments(1)) {})
        case 3 => Right(new FullName(segments(0), segments(1), segments(2)){})
        case other => Left(s"Wrong format $other")
      }
    }
  }

  UserName.fromStr("aa.bbb.cccc").map { r =>
    r match {
      case UserName.FirstName(value) => ???
      case UserName.FirstAndLastName(first, last) => ???
      case UserName.FullName(first, middle, last) => ???
    }
  }

  /*
  Instant.now(Clock.system(TimeZone.getDefault.toZoneId))

  val now1 = Instant.ofEpochMilli(System.currentTimeMillis())
  ZonedDateTime.ofInstant(now1, ZoneId.of("US/Central"))
  ZonedDateTime.ofInstant(now1, ZoneId.of("America/Chicago"))

  ZonedDateTime.ofInstant(now1, ZoneId.of("America/Toronto"))

  val tzFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss Z")
  tzFormatter.format(Instant.now())
  tzFormatter.format(ZonedDateTime.ofInstant(now1, ZoneId.of("US/Central")))

  val str = {
    val now = Instant.ofEpochMilli(System.currentTimeMillis())
    val nowTz = ZonedDateTime.ofInstant(now, ZoneId.of("US/Central"))
    tzFormatter.format(nowTz)
  }
  */

  import scala.reflect.ClassTag

  sealed trait A

  sealed trait B

  sealed trait C

  sealed trait Ref[+T]

  //generic
  final case class GenRecord[Schema] private(private val internals: Map[Class[_], Any]) {
    def ++[A](u: A)(implicit tag: ClassTag[A]): GenRecord[Schema with A] =
      GenRecord[Schema with A](internals.updated(tag.runtimeClass, u))

    def get[A](implicit ev: Schema <:< A, tag: ClassTag[A]): A =
      internals(tag.runtimeClass).asInstanceOf[A]
  }
  object GenRecord {
    def apply[A](v: A)(implicit tag: ClassTag[A]): GenRecord[A] =
      new GenRecord[A](Map(tag.runtimeClass -> v))
  }

  val genRec0: GenRecord[A with B] = GenRecord(new A {}) ++ new B {}
  genRec0.get[A]
  genRec0.get[B]
  //genRec0.get[C]// - Causes a compile-time failure

  //Problem
  genRec0.get[A with B] //works, but shouldn't because it's summoning of non-existent types.

  implicitly[A with B <:< A]
  implicitly[B with A <:< A]
  implicitly[A with B <:< B]
  implicitly[B with A <:< B]

  final case class GenRecord2[Schema] private(private val internals: Map[Class[_], Any]) {
    def ++[A](value: A)(implicit ev: Schema <:!< A, ev1: ClassTag[A]) =
      new GenRecord2[Schema with Ref[A]](internals.updated(ev1.runtimeClass, value))

    def get[A](implicit ev: Schema <:< Ref[A], ev2: ClassTag[A]): A =
      internals(ev2.runtimeClass).asInstanceOf[A]
  }
  object GenRecord2 {
    def apply[A](v: A)(implicit tag: ClassTag[A]): GenRecord2[Ref[A]] =
      new GenRecord2[Ref[A]](Map(tag.runtimeClass -> v))
  }

  val test1 = GenRecord2(new A {}) ++ new B {}
  test1.get[A]
  test1.get[B]
  //test1.get[A & B //]

  GenRecord2(1L).++("").++("")


  //You need to define this class

  import izumi.reflect.Tag
  final case class Column[+T] private(private val internals: Map[Tag[_], Any])
  object Column {
    implicit class ColumnOps[Schema <: Column[_]](val self: Schema) extends AnyVal {
      def ++[A <: Column[_]](that: A)(implicit ev: Schema <:!< A): Schema with A =
        Column(self.internals ++ that.internals).asInstanceOf[Schema with A]

      def get[A: Tag](implicit ev: Schema <:< Column[A]): A =
        self.internals(implicitly[Tag[A]]).asInstanceOf[A]
    }
    def apply[A: Tag](a: A): Column[A] =
      new Column(Map(implicitly[Tag[A]] -> a))
  }

  val genRecord = Column(1) ++ Column("a") ++ Column(List(1,2,3)) ++ Column(List("11","12","13"))

  genRecord.get[Int]
  genRecord.get[String]
  genRecord.get[List[Int]]
  genRecord.get[List[String]]

  //implicitly[Column[Int] with Column[Boolean] <:< Column[Long]]

  //genRecord.get[List[Long]] // Cannot prove that Column[Int] with Column[String] with Column[List[Int]] with Column[List[String]] <:< Column[List[Long]]

  //An approximate ADT

  /*
  final case class TransactionType0 private(name: String)
  object TransactionType0 {
    //Smart con-tor to guard construction.
    def apply(str: String): Option[TransactionType0] = {
      //Put validation here
      //println("Validation")
      if (str.length == 8 && str.toList.forall(_.isLetter) && str.startsWith("...")) Some(new TransactionType0(str))
      else None
    }
  }
  */

  /*
    With this smart c-tor in place we are able to guard construction of invalid amounts and obtain a guarantee that if any one has an amount
    instance it's definitely going to be a good data. This is how you illuminate potential of runtime errors due to bad data and illuminate
    potential for corrupting journals or databases downstream.

    //if (amount > 0) Some(new Amount(amount)) else None
    //throws away error info
  */

  //def fromInt(amount: Int): Either[Unit, Amount] = if (amount > 0) Right(new Amount(amount)) else Left(())

  sealed trait Error
  object Error {
    case object NegativeAmount extends Error
    case object SuspiciousAmount extends Error
    final case class DetailedError(msg: String) extends Error
  }

  final case class Amount private(value: Int)
  object Amount {
    def apply(amount: Int): Option[Amount] =
      //throws away error info
      fromInt(amount).toOption

    def fromInt(amount: Int): Either[Error, Amount] =
      if (amount < 0) Left(Error.NegativeAmount)
      else if (amount > 3000) Left(Error.SuspiciousAmount)
      else Right(new Amount(amount))

    def eitherOpt(amount: Int): Either[None.type, Amount] =
      if (amount > 0) Right(new Amount(amount)) else Left(None)

    def eitherOpt2(amount: Int): Either[Unit, Amount] =
      if (amount > 0) Right(new Amount(amount)) else Left(None)
  }

  /*
  Amount(123)
  Amount.fromInt(123)
  Amount.eitherOpt(345)
  Amount.eitherOpt2(345)
  */

  /*
     abstract - Prevent creating instances of the sum types; anonymous instances can still be created. See the parse method creating instances.
     sealed - Prevent extending the types elsewhere but this file
     case class - So that we can still pattern match sum types
  */


  /*def m = {
    if ((transfer.isOutgoing) && (transfer.isValidWithdrawal || transfer.isValidIraDistribution))
      Some(transfer) else None
  }*/


  //sys.terminate()
  //println(java.util.Arrays.compare(Array[Byte](1,2), Array[Byte](1,2,3)))

  /*.map {
    case Right(m) => println("Out: " + m)
    //case Left(err)  => println("Err:" + err)
  }*/

  /*val f =
    Source
      .fromIterator(() => Iterator.range(1,5))
      .collect { case i =>
        val expectedState = mapping.get(i)
        if (!expectedState.contains(i))
          expectedState
      }.runWith(Sink.foreach(println(_)))*/

  //Await.result(f, Duration.Inf)
  //Await.result(fA, Duration.Inf)

  //srcOfStrs.to(sinkOfStrs)
  /*.recover {
    case _: ArithmeticException => -1
  }.recover {
    case _: NumberFormatException => -2
  }.to(Sink.foreach { in =>
    println(s"" + in)
  }).run()*/

}
