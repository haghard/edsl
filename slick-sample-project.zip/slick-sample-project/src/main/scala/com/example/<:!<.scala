package com.example

abstract class <:!<[A, B] extends Serializable
object <:!< {
  implicit def nsub[A, B]: A <:!< B = new <:!<[A, B] {}

  @scala.annotation.implicitAmbiguous("Cannot add ${B} to [${A}] twice")
  implicit def nsubAmbig1[A, B >: A]: A <:!< B = sys.error("error1")
  implicit def nsubAmbig2[A, B >: A]: A <:!< B = sys.error("error2")
}