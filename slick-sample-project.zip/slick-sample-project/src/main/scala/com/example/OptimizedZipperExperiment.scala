package com.example

//https://gist.github.com/kitlangton/0ce8cb031c1dca96f5b7c2d51e78c6cc

sealed trait Box[A] extends Product with Serializable {
  self =>

  def zip[B](that: Box[B])(implicit zipper: Zipper[A, B]): Box[zipper.Out] =
    Box.Zip[A, B, zipper.Out](self, that, zipper)

  /*def map[B](f: A => B)(implicit tupleSize: TupleSize[B]): Box[B] =
    Box.Map(self, f, tupleSize)*/

  /*def tupleSize: Int = self match {
    case Box.Zip(left, right, _) => left.tupleSize + right.tupleSize
    case Box.Map(_, _, tupleSize) => tupleSize.size
    case Box.Succeed(_, tupleSize) => tupleSize.size
  }*/
}

/*trait LowPriorityZipper1 extends LowPriorityZipper0 {
  implicit def leftUnitZipper[A]: Zipper.WithOut[Unit, A, A]  = LowPriorityZipper1.LeftUnitZipper[A]()
  implicit def rightUnitZipper[A]: Zipper.WithOut[A, Unit, A] = LowPriorityZipper1.RightUnitZipper[A]()
}

object LowPriorityZipper1 {
  final case class LeftUnitZipper[A]() extends Zipper[Unit, A] {
    type Out = A
    override def combine(a: Unit, b: A): A = b
  }

  final case class RightUnitZipper[A]() extends Zipper[A, Unit] {
    type Out = A
    override def combine(a: A, b: Unit): A = a
  }
}*/

trait LowPriorityZipper0 {
  implicit def abZipper[A, B]: Zipper.WithOut[A, B, (A, B)] = LowPriorityZipper0.ABZipper[A, B]()
}

object LowPriorityZipper0 {
  final case class ABZipper[A, B]() extends Zipper[A, B] {
    type Out = (A, B)
    override def combine(a: A, b: B): (A, B) = (a, b)
  }
}


sealed trait Zipper[A, B] /*extends Product with Serializable*/ {
  type Out
  def combine(a: A, b: B): Out
}

object Zipper extends LowPriorityZipper0 {
  type WithOut[A, B, Out0] = Zipper[A, B] {type Out = Out0}
}

object Box {

  def apply[A](value: A): Box[A] = Succeed(value)

  final case class Succeed[A](value: A) extends Box[A]
  final case class Zip[A, B, C](lhs: Box[A], rhs: Box[B], zipper: Zipper.WithOut[A, B, C]) extends Box[C]
}

object BoxExample extends App {
  val example =
    Box(10) zip Box(2.0) zip Box(true) zip Box("b")
}
