package com.example

import cats.effect.Sync

//import cats.implicits._
//import cats.Applicative
//import cats.implicits.catsSyntaxApplicativeId

/*

trait Metrics[F[_]] {
  def report(metricName: String, value: Double): F[Unit]
}

object Metrics {
  def apply[F[_]: Sync](implicit F: Sync[F]): Metrics[F] = new Metrics[F] {
    override def report(metricName: String, value: Double): F[Unit] = {
      F.delay {
        metricName match {
          //case "MaxQueueSize" =>
          //case "MaxThreads" =>
          case "ActiveThreads" => println("activeThreads: " + value)
          case "QueueSize" => println("queueSize: " + value)
          case other => println(other)
        }
      }
    }
  }
}
*/

trait Metrics {
  def report(metricName: String, value: Double): Unit
}

object Metrics {
  def apply(): Metrics = (metricName: String, value: Double) => {
    metricName match {
      //case "MaxQueueSize" =>
      //case "MaxThreads" =>
      case "ActiveThreads" =>
        println("activeThreads: " + value)
      case "QueueSize" =>
        println("queueSize: " + value)
      case other =>
        println(other)
    }
  }
}
