package com.example

import com.example.adts.EventContent._


//No manual entry for disable code authors\;type\=a

object adts {

  type CorrelationId = String // Might be overloaded. Normally a transfer ID (from transfer-impl). Sometimes an account ID.
  type BankRelationshipId = String // Plaid ID? Maybe someday a bank relationship service ID.
  //type TransactionId = UUID
  type TransferStatus = String

  //sealed abstract class Direction(path: String)
  sealed trait Direction
  object Direction {
    abstract class AbsDirection(val m: String) extends Direction
    final case class Deposit() extends AbsDirection("->")
    final case class Withdrawal() extends AbsDirection("<-")
  }

  sealed trait TransferType
  object TransferType {
    case object Apex extends TransferType
    case object M1 extends TransferType
  }

  //bor
  sealed trait AchTransfer
  object AchTransfer {

    // These AchDeposit and AchWithdrawal models mirror their sentinel2 cousins
    final case class AchDeposit(
      achTransferId: CorrelationId,
      relationshipId: BankRelationshipId,
      amount: BigDecimal,
      transferStatus: TransferStatus
    ) extends AchTransfer

    final case class AchWithdrawal(
      achTransferId: CorrelationId,
      relationshipId: BankRelationshipId,
      amount: BigDecimal,
      transferStatus: TransferStatus
    ) extends AchTransfer
  }

  /*final case class BorAchTransfer(
    achTransferId: CorrelationId,
    relationshipId: BankRelationshipId,
    amount: BigDecimal,
    transferStatus: TransferStatus,
    T: Direction
  )

  BorAchTransfer("achTransferId", "relationshipId", BigDecimal(1.5), "Status", Direction.Deposit)
  BorAchTransfer("achTransferId", "relationshipId", BigDecimal(1.5), "Status", Direction.Withdrawal)
*/

  java.util.UUID.randomUUID().toString

  type SentinelAchTransferStatus = String

  sealed trait SentinelAchTransfer {
    val status: SentinelAchTransferStatus
  }

  object SentinelAchTransfer {
    final case class AchDeposit(
      id: String, // Apex's date based ID
      externalId: String, // OUR internal GUID based ID
      relationshipId: String,
      amount: BigDecimal,
      status: SentinelAchTransferStatus,
      //iraContributionDetails: Option[IraContributionDetails] = None
    ) extends SentinelAchTransfer

    final case class AchWithdrawal(
      id: String,
      externalId: String,
      relationshipId: String,
      amount: BigDecimal,
      status: SentinelAchTransferStatus,
      //iraDistributionDetails: Option[IraDistributionDetails],
      //fees: Option[List[SentinelAchTransferFee]] = None
      //memo: Option[String],
    ) extends AchTransfer
  }

  final case class Transfer[T <: Direction](
    achTransferId: CorrelationId,
    relationshipId: BankRelationshipId,
    amount: BigDecimal,
    transferStatus: TransferStatus
  )

  object Transfer {
    def deposit(
      achTransferId: CorrelationId,
      relationshipId: BankRelationshipId,
      amount: BigDecimal,
      transferStatus: TransferStatus
    ) = Transfer[Direction.Deposit](achTransferId, relationshipId, amount, transferStatus)

    def withdrawal(
      achTransferId: CorrelationId,
      relationshipId: BankRelationshipId,
      amount: BigDecimal,
      transferStatus: TransferStatus
    ) = Transfer[Direction.Withdrawal](achTransferId, relationshipId, amount, transferStatus)
  }

  //AchDepositBase|M1AchTransfer: ApexAchDeposit, M1AchDeposit
  //AchWithdrawalBase: ApexAchWithdrawal, M1AchWithdrawal


  final case class Event[+T](when: Long, content: T)

  sealed trait EventContent[+T]
  object EventContent {
    final case class UserEvent[+T](userId: Long, userContent: T) extends EventContent[T]
    final case class DeviceEvent[+T](deviceId: Long, deviceContent: T) extends EventContent[T]
  }

  sealed trait UserEventContent
  object UserEventContent {
    final case class UserCreated(location: String, status: String, when: Long) extends UserEventContent
    final case class UserDeleted(when: Long) extends UserEventContent
    final case class UserUpdated(newUserName: String, when: Long) extends UserEventContent
  }

  sealed trait DeviceEventContent
  object DeviceEventContent {
    final case class DeviceUpdated(src: String, reading: Option[Double]) extends DeviceEventContent
    final case object DeviceActivated extends DeviceEventContent
  }

  //UserEventContent.UserCreated("location", "status", ???)

  val usrEvent: Event[UserEvent[UserEventContent]] = ???
  usrEvent match {
    case Event(when, UserEvent(userId, userContent)) =>
      userContent match {
        case UserEventContent.UserCreated(location, status, when) => ???
        case UserEventContent.UserDeleted(when) => ???
        case UserEventContent.UserUpdated(newUserName, when) => ???
      }

    //case Event(when, DeviceEvent(userId, content)) =>
  }

  val dvsEvent: Event[DeviceEvent[DeviceEventContent]] = ???
  dvsEvent match {
    case Event(when, DeviceEvent(deviceId, deviceContent)) =>
      deviceContent match {
        case DeviceEventContent.DeviceUpdated(src, reading) => ???
        case DeviceEventContent.DeviceActivated => ???
      }
  }

  final case class Student(name: String, address: Seq[Address])
  final case class Address(city: String, state: String)

  object City {
    def unapply(s: Student): Option[Seq[String]] =
      Some(for (c <- s.address) yield c.state)
  }

  class StringSeqContains(value: String) {
    def unapply(in: Seq[String]): Boolean = in contains value
  }

  object PatternMatch {
    def main(args: Array[String]) {
      val stud = List(Student("Harris", List(Address("LosAngeles", "California"))),
        Student("Reena", List(Address("Houston", "Texas"))),
        Student("Rob", List(Address("Dallas", "Texas"))),
        Student("Chris", List(Address("Jacksonville", "Florida"))))

      val Texas = new StringSeqContains("Texas")
      val students = stud collect {
        case student @ City(Texas()) => student.name
      }
      println(students)
    }
  }
}
