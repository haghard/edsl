package com.example

sealed trait UnionTypes[T]
object UnionTypes {
  implicit case object IntTag extends UnionTypes[Int]
  implicit case object StringTag extends UnionTypes[String]
  implicit case object BoolTag extends UnionTypes[Boolean]

  def oneOf[T](v: T)(implicit t: UnionTypes[T]): T =
    t match {
      case UnionTypes.IntTag =>  //scalac know that T =:= Int
        v + 1
      case UnionTypes.StringTag => //scalac know that T =:= String
        v.substring(0, 1)
      case UnionTypes.BoolTag => //scalac know that T =:= Boolean
        v & true
    }

  def oneOf2[T](v: T)(implicit ev: Int with String with Boolean <:< T) =
    v match {
      case i: Int => i
      case str: String => str
      case bool: Boolean => bool
    }

}

object Program extends App {

  import UnionTypes._

  oneOf(1)
  oneOf("")
  oneOf(true)
  //oneOf(5.6)

  oneOf2(1)
  oneOf2("")
  oneOf2(true)
  //oneOf2(5.6)

}