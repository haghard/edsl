package com.example

import cats.effect.{ExitCase, ExitCode, IO, IOApp, Resource}
import javax.management.{MBeanInfo, MBeanServer, ObjectName}
import cats.implicits._
import java.lang.{Integer => JInt}
import java.util.concurrent.ThreadLocalRandom

import scala.concurrent.duration._

//runMain com.example.runner1
object runner1 extends IOApp {

  val executorName = "slick3"
  val conPoolSize = Runtime.getRuntime.availableProcessors()

  def reporter(mBeanServer: MBeanServer, mBeanName: ObjectName, metrics: Metrics): IO[Unit] =
    timer.sleep(1.seconds) >> IO {
      println("******************************")
      val beanInfo: MBeanInfo = mBeanServer.getMBeanInfo(mBeanName)
      //if(ThreadLocalRandom.current().nextDouble() > .5) throw new Exception("Boom !!!")
      beanInfo.getAttributes.foreach { attr =>
        val metricName = attr.getName
        val n = mBeanServer.getAttribute(mBeanName, metricName) match {
          case num: JInt => num.toDouble
          case _         => -1.0
        }
        metrics.report(metricName, n)
      }
    }  //.redeemWith({ err => IO(println(err.getMessage)) }, _ => IO.unit)


  //TODO: maybe bracket
  def run0(): Resource[IO, Databases[IO]] =
    Resource {
      for {
        dbs   <- IO(Databases[IO](5))
        args  <- IO {
          val mBeanServer = java.lang.management.ManagementFactory.getPlatformMBeanServer
          val mBeanName   = new ObjectName(s"slick:type=AsyncExecutor,name=$executorName")
          (mBeanServer.isRegistered(mBeanName), mBeanServer, mBeanName)
        }

        (isRegistered, mBeanServer, mBeanName) = args
        metricFiber <- if (isRegistered) reporter(mBeanServer, mBeanName, Metrics()).foreverM.start else IO.unit.start
      } yield (dbs, metricFiber.cancel)
    }

  def run(mBeanServer: MBeanServer, mBeanName: ObjectName): Resource[IO, Databases[IO]] =
    Resource {
      for {
        dbs      <- IO(Databases[IO](5))
        reporter <- reporter(mBeanServer, mBeanName, Metrics()).foreverM.start
      } yield (dbs, reporter.cancel)
    }

  override def run(args: List[String]): IO[ExitCode] = {
    /*
    val a = java.lang.management.ManagementFactory.getPlatformMBeanServer
    val b = new ObjectName(s"slick:type=AsyncExecutor,name=$executorName")
    */
    //val b = new ObjectName(s"slick:type=AsyncExecutor,name=executorName")

    //Thread.sleep(2000)

    for {
      //_ <- if(a.isRegistered(b)) IO.unit else IO.raiseError(new Exception("Not Registered MBeanServer !!!"))
      _ <- IO.unit
      //(db, release) = run(a, b).allocated.unsafeRunSync()

      (db, release) = run0.allocated.unsafeRunSync()

      _   <- IO(println("------1 DB executor: " + db.database.db.executor.executionContext.hashCode()))
      _   <- timer.sleep(7.seconds) >> release >> IO(println("Canceled"))
    } yield ExitCode.Success
  }
}
