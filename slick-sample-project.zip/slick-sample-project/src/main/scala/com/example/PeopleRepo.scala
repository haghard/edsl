package com.example

import akka.actor.Scheduler
import akka.dispatch.ExecutionContexts

import java.time.Instant
import java.util.UUID
import com.codahale.metrics.{Histogram, Meter}
import slick.dbio.DBIO
import slick.jdbc.TransactionIsolation
import slick.lifted.ProvenShape

import java.util.concurrent.ThreadLocalRandom
import scala.collection.Seq
import scala.concurrent.ExecutionContext
import scala.concurrent.duration.{DurationDouble, DurationInt, FiniteDuration}
import scala.util.{Failure, Success}

//import slick.jdbc.HsqldbProfile.api._
//import slick.jdbc.SQLServerProfile.api._

import scala.concurrent.Future
import slick.jdbc.H2Profile.api._

final case class PersonRow(id: Option[UUID], firstName: String, lastName: String, registrationTime: Instant, rowTag: String = "", rowTag2: String = "")

class People(tag: Tag) extends Table[PersonRow](tag, "PEOPLE") {

  val id = column[Option[UUID]]("ID", O.PrimaryKey)
  val firstName = column[String]("FIRST_NAME")
  val lastName = column[String]("LAST_NAME")
  val registrationTime = column[Instant]("REG_TS")
  val rowTag = column[String]("TAG")
  val rowTag2 = column[String]("TAG2")

  def * : ProvenShape[PersonRow] =
    (id,
      firstName,
      lastName,
      registrationTime,
      rowTag,
      rowTag2
    ) <> (PersonRow.tupled, { r => PersonRow.unapply(r) })
}

object PeopleQueries extends TableQuery(new People(_)) {

  def idsForUpdate(ids: Seq[UUID]) =
    Compiled { filter(_.id.inSet(ids)).forUpdate }

  val byId = Compiled { userId: Rep[UUID] =>
    filter(_.id === userId)//.forUpdate
  }

  val tagById = Compiled { userId: Rep[UUID] =>
    filter(_.id === userId).map(_.rowTag)//.forUpdate
  }

  val byTag = Compiled { tag: Rep[String] =>
    filter(_.rowTag === tag)
  }

  val byTag2 = Compiled { tag: Rep[String] =>
    filter(_.rowTag2 === tag)
  }

  def tagById(ids: Seq[UUID]) =
    Compiled { filter(_.id.inSet(ids)).map(_.rowTag) }

  def tag2ById(ids: Seq[UUID]) =
    Compiled { filter(_.id.inSet(ids)).map(_.rowTag2) }

  val getByIdsForUpdate = Compiled { (a: Rep[UUID], b: Rep[UUID]) =>
    filter(rep => rep.id === a || rep.id === b)
      .map(_.rowTag)
      //.forUpdate
  }

  def query(now: Instant): DBIO[Option[(Option[UUID], Instant)]] =
    sql"""SELECT ID, REG_TS FROM PEOPLE WHERE REG_TS <= $now LIMIT 1"""
      .as[(Option[UUID], Instant)].headOption
}

case class PeopleRepo(db: Database)(implicit globalMetrics: MeasuredDatabase) {
  //private val query = PeopleQueries // TableQuery[People]

  def person  = PersonRow(Some(UUID.randomUUID()), "John", "Doe", Instant.now())
  val rows    = Seq.fill(1)(person)
  val inserts = prepareStmts(rows)

  def createSchema: Future[Unit] = {
    val ses = db.createSession()
    println(s"***********************************")
    println("TransactionIsolation: " + ses.conn.getTransactionIsolation)

    ses.close()
    println(s"***********************************")
    db.run(PeopleQueries.schema.create)
  }

  def prepareStmts(persons: Seq[PersonRow]): Seq[DBIO[Int]] =
    persons.map { p =>
      println(s"***********************************")
      println(s"??????? prepare insert: $p ???????")
      println(s"***********************************")
      PeopleQueries += p
    }

  def insert2(): Future[String] = {
    val dbio = DBIO.sequence(inserts).transactionally
    db
      .run(dbio)
      .map { r =>
        println(s"${Thread.currentThread.getName} insert result ${r.mkString(",")}")
        r.mkString(",")
      }(SameThreadExecutionContext)
  }

  def insert(person: PersonRow): Future[Int /*String*/] = {

    def batch(persons: Seq[PersonRow]) /*DBIO[Set[String]]*/ = {

      //def insert(p: PersonRow): DBIO[Int] = (PeopleQueries += p)
      //val inserts = persons.map(insert)

      val inserts0 = PeopleQueries.++=(persons)

      val inserts = persons.map { p =>
        println(s"******* insert: $p")
        PeopleQueries += p
        PeopleQueries += p
      }

      /*
      (PeopleQueries ++= persons.map { p =>
        println(s"******* insert outer: $p")
        p
      }).flatMap { c =>
        (PeopleQueries ++= persons.map { p =>
          println(s"******* insert inner: $p")
          p.copy(id = Some(UUID.randomUUID()))
        }).flatMap(_.map(_ + c.getOrElse(0)))
      }(SameThreadExecutionContext).transactionally
      */

      DBIO.sequence(inserts).transactionally

      //(PeopleQueries ++= persons).transactionally
      //DBIO.sequence(inserts).transactionally


      //DBIO.sequence(inserts).transactionallyMeasured

      //val a = person
      //val b = person.copy(id = Some(UUID.randomUUID()))
      //((PeopleQueries += a) andThen (PeopleQueries += b)).map(_ => s"${a.id.get} : ${b.id.get}" )(SameThreadExecutionContext)
    }

    /*val rows = Seq.fill(5)(person).map(_.copy(id = Some(UUID.randomUUID())))
    db
      .run(batch(rows))
      .map { r =>
        println(s"${Thread.currentThread.getName} insert result ${r.mkString(",")}")
        r.mkString(",")
      }(SameThreadExecutionContext)
    */

    //val s = db.createSession()
    //(PeopleQueries += person).withTransactionIsolation(TransactionIsolation.Serializable)
    /*
    val query = for (c <- coffees) yield c.name
    val session : Session = db.createSession
    val result  = query.list()( session )
    session.close
    */

    db.run(
      (PeopleQueries += person)
        .withTransactionIsolation(TransactionIsolation.Serializable)
        //.transactionally
    )
  }

  def findByTagF(tag: String): Future[String] =
    db.run(PeopleQueries.byTag(tag).result).map { rows => s"******** findByTag $tag = " + rows.mkString(",") }(ExecutionContexts.global())

  def findByTag(tag: String): DBIO[String] =
    PeopleQueries.byTag(tag).result.map(rows => s"*** findByTag $tag: " + rows.mkString(","))(SameThreadExecutionContext)
    //db.run(PeopleQueries.byTag(tag).result).map { rows => s"******** findByTag $tag = " + rows.mkString(",") }(ExecutionContexts.global())

  def findByTag2(tag: String): Future[String] =
    db.run(PeopleQueries.byTag2(tag).result).map { rows => s"******** findByTag2 $tag = " + rows.mkString(",") }(SameThreadExecutionContext)

  def findByIds(id: UUID, id1: UUID): Future[Unit] =
    db.run(
      DBIO.sequence(
        List(
          PeopleQueries.byId(id).result.headOption,
          PeopleQueries.byId(id1).result.headOption
        )
      ).flatMap {
        case List(Some(a), Some(b)) =>
          DBIO.successful {
            println("*******" + a)
            println("*******" + b)
          }
        case _ =>
          DBIO.successful(println("************ None"))
      }(SameThreadExecutionContext)
    )

  def findById(id: UUID) =
    db
      .run(PeopleQueries.byId(id).result.headOption)
      .map { r =>
        println(s"${Thread.currentThread.getName} findById person $r")
        r
      }(SameThreadExecutionContext)


  def decider[T]: PartialFunction[T, Unit] = { case _ => }
  def retryWithDelay[T](
    future: => Future[T],
    delay: FiniteDuration = 0.5.seconds,
    retries: Int = 3,
    retrySideEffect: => Unit = (),
    decider: PartialFunction[Throwable, Unit] = decider
  )(implicit ec: ExecutionContext, scheduler: Scheduler): Future[T] = {
    future recoverWith {
      case r if decider.isDefinedAt(r) && retries > 0 =>
        retrySideEffect
        akka.pattern.after(delay, scheduler)(retryWithDelay(future, delay, retries - 1, retrySideEffect, decider))
    }
  }

  def waitForCondition[T](
    f: => Future[T],
    successCondition: T => Boolean,
    abortCondition: T => Boolean,
    retries: Int,
    retryInterval: FiniteDuration,
    label: String,
    startTime: Long = System.currentTimeMillis()
  )(implicit
    ec: ExecutionContext,
    scheduler: Scheduler
  ): Future[T] = {
    f flatMap {
      case r if successCondition(r) =>
        println(s"[$label] Condition successfully met. Elapsed=${(System.currentTimeMillis() - startTime) / 1000}s")
        Future.successful(r)

      case r if abortCondition(r) =>
        println(s"[$label] abortCondition tripped. Elapsed=${(System.currentTimeMillis() - startTime) / 1000}s")
        Future.failed(new RuntimeException(s"[$label] abortCondition detected.  lastValue=$r"))

      case _ if retries > 0 =>
        println(s"[$label] Condition not yet met.  retriesLeft=${retries - 1}")
        akka.pattern.after(retryInterval, scheduler)(
          waitForCondition(f, successCondition, abortCondition, retries - 1, retryInterval, label, startTime)
        )

      case r => Future.failed(new RuntimeException(s"Condition [$label] was not met within the allotted retry budget.  lastValue=$r"))
    }
  }


  def fetchWithRetry[T](
    fetchByKey: => Future[Option[T]],
    ex: IllegalStateException,
    limit: Int = 3,
    duration: FiniteDuration = 300.millis
  )(implicit ec: ExecutionContext, scheduler: Scheduler): Future[T] = {
    require(limit > 0, s"limit in fetchWithRetry must be > 0, but was $limit!")
    fetchByKey.transformWith {
      case Success(maybeRow) =>
        maybeRow match {
          case Some(row) =>
            Future.successful(row)
            //akka.pattern.retry()
          case None =>
            println(s"!!!!!!!!! Not found ...........")
            if (limit > 0) akka.pattern.after(duration, scheduler)(fetchWithRetry(fetchByKey, ex, limit - 1))
            else Future.failed(throw ex)
        }
      case Failure(_) =>
        if (limit > 0) akka.pattern.after(duration, scheduler)(fetchWithRetry(fetchByKey, ex, limit - 1))
        else Future.failed(throw ex)
    }
  }


  def findByRegDate(when: Instant) = {
    db.run(PeopleQueries.query(when)).map { tuple =>
      println(s"${Thread.currentThread.getName} findByRegDate $tuple")
      tuple
    }(SameThreadExecutionContext)
  }

  def deleteById(id: UUID) =
    db.run(PeopleQueries.byId(id).delete)

  def updateById(id: UUID, person: PersonRow): Future[Int] =
    db.run(PeopleQueries.byId(id).update(person.copy(id = Some(id)))).map { count =>
      println(s"${Thread.currentThread.getName} updateById $count")
      count
    }(SameThreadExecutionContext)

  //https://scala-slick.org/doc/3.3.0/sql.html
  //https://honstain.com/slick-upsert-and-select/

  //https://honstain.com/slick-upsert-and-select/
  //https://honstain.com/inventory-transfer-row-locking/

  def update3(id: UUID): Future[Int] = {
    val q = PeopleQueries.tagById(id)
    //val dbio = q.update(System.currentTimeMillis().toString)*/
    val dbio = q.result.flatMap { _ =>
      Thread.sleep(500)
      q.update(System.currentTimeMillis().toString)
    }(ExecutionContexts.global())
    db.run(dbio.transactionally)
  }



  def updateByIds(
    a: UUID, b: UUID,
    //findByTag: String => Future[String]
  ): Future[_] = {
    implicit val ec = ExecutionContexts.global()

    val dbio = PeopleQueries.idsForUpdate(Seq(a, b)).result.flatMap { rows =>
      val tagA = "aaa"
      val tagB = "bbb"
      val rowIds = rows.map(_.id.get)

      //val update = q.map(_.map(rep => (rep.rowTag, rep.rowTag2)))
      //println("=======UpdateStatement: " + update.updateStatement)

      val actions =
        for {
          _ <- PeopleQueries.tagById(rowIds).update(tagA)
          //_ <- update.update(tagA, tagB)
          _ <- this.findByTag(tagA).map(println(_))
          _ <- PeopleQueries.tag2ById(rowIds).update(tagB)

          //_ <- DBIO.from(findByTagF(tagA).map(println(_)))
          _ <- DBIO.from(Future {
              println("=======Start uploading=======" + Thread.currentThread().getName)
              Thread.sleep(3000)
              //throw new Exception("Boom !!!")
              println("=======Stop uploading=======" + Thread.currentThread().getName)
          }(SameThreadExecutionContext))
          //_ <- DBIO.from(findByTag(tagA).map(line => println(line)))  //.andThen(uB)
        } yield ()

      /*val actions =
        DBIO.from(
          Future {
            println(s"External IO. Start **********************************Selected ${ids.mkString(",")} forUpdate. **")
            Thread.sleep(5000)
            //throw new Exception("**External IO. Boom **")
            println("**External IO. Stop **")
          }(ExecutionContexts.global())/*(SameThreadExecutionContext)*/
        ).andThen(DBIO.sequence(rows.map(row => PeopleQueries.tagById(row.id.get).update("bbb"))))
      */

      /*
      val dbio = (rows.map { row =>
        (for { x <- PeopleQueries if x.id === row.id } yield x.rowTag).update("aaa")
      } ++ Seq(
        DBIO.from(
          Future {
            println("**External IO. Start **")
            Thread.sleep(3000)
            println("**External IO. Stop **")
          }(SameThreadExecutionContext)
        )
      )) ++ rows.map(row => (for { x <- PeopleQueries if x.id === row.id } yield x.rowTag).update("bbb"))
      */

      //DBIO.sequence(dbio)
      actions
      //val updates = PeopleQueries.++=(rows.map(_.copy(rowTag = "aaa")))
      //updates
    }(SameThreadExecutionContext)

    db.run(dbio.transactionally)

    /*db.run(PeopleQueries.getByIdsForUpdate(a, b).update("aaa")).map { count =>
      println(s"${Thread.currentThread.getName} updateById $count")
      count
    }(SameThreadExecutionContext)*/

    /*db.run(PeopleQueries.byId(id).update(person.copy(id = Some(id)))).map { count =>
      println(s"${Thread.currentThread.getName} updateById $count")
      count
    }(SameThreadExecutionContext)*/
  }

  //
  //scala.concurrent.ExecutionContext.parasitic

  /*def createOrUpdate(id: UUID): DBIO[Int] = {
    findById(id).flatMap { maybeUser =>
      if(maybeUser.isEmpty) insert()
      else updateById(id, )
      ???

    }

    //DBIO.successful(1)
  }*/

}
