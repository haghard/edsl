package com.example.ring

import scala.reflect.ClassTag

object MoreStages {

  //(E[]) new Object[capacity];
  //new Array[AnyRef](findNextPositivePowerOfTwo(capacity)).asInstanceOf[Array[T]])
  //new Array[AnyRef](findNextPositivePowerOfTwo(capacity)).asInstanceOf[Array[T]])

  object RingBuffer {
    def nextPowerOfTwo(value: Int): Int =
      1 << (32 - Integer.numberOfLeadingZeros(value - 1))
  }

  trait SourceElement[T] {
    def apply(v: T): Double
  }

  //https://en.wikipedia.org/wiki/Moving_average
  //https://blog.scalac.io/2017/05/25/scala-specialization.html
  class SimpleRingBuffer[@specialized(Double, Long, Int) T: SourceElement: ClassTag: Numeric] private (
    capacity: Int, buffer: Array[T]
  ) {

    private var tail: Long = 0L
    private var head: Long = 0L

    def this(capacity: Int) =
      this(capacity, Array.ofDim[T](capacity))

    def add(e: T): Unit = {
      val ind = (tail % capacity).toInt

      buffer(ind) = e
      tail += 1

      val wrapPoint = tail - capacity
      if (head <= wrapPoint)
        head = tail - capacity
    }

    def currentHead: T = {
      val ind = (head % capacity).toInt
      buffer(ind)
    }

    def sum: Double = implicitly[SourceElement[T]].apply(buffer.sum)

    def size(): Int = (tail - head).toInt

    override def toString =
      s"[head:$head tail:$tail]: [${buffer.mkString(",")}]"
  }

  class RingBuffer[T: scala.reflect.ClassTag] private (capacity: Int, mask: Int, buffer: Array[T]) {
    private var tail: Long = 0L
    private var head: Long = 0L

    def this(capacity: Int) {
      this(
        RingBuffer.nextPowerOfTwo(capacity),
        RingBuffer.nextPowerOfTwo(capacity) - 1,
        Array.ofDim[T](RingBuffer.nextPowerOfTwo(capacity))
      )
    }

    def offer(e: T): Boolean = {
      val wrapPoint = tail - capacity
      if (head <= wrapPoint) false
      else {
        val ind = (tail & mask).toInt
        buffer(ind) = e
        tail = tail + 1
        true
      }
    }

    def poll(): Option[T] =
      if (head >= tail) None
      else {
        val index      = (head & mask).toInt
        val element: T = buffer(index)
        buffer(index) = null.asInstanceOf[T]
        head = head + 1
        Some(element)
      }

    def peek(): Option[T] =
      if (head >= tail) None
      else {
        val index = head.toInt & mask
        Some(buffer(index))
      }

    def size() = (tail - head).toInt

    override def toString =
      s"nextHead: [$head/${head.toInt & mask}] nextTail:[$tail/${tail.toInt & mask}] buffer: ${buffer.mkString(",")}"
  }
}
