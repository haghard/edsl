package com.example.ring

import HashRingBuffer._

object HashRingBuffer {

  type Hash = Array[Byte]

  def nextPowerOfTwo(value: Int): Int =
    1 << (32 - Integer.numberOfLeadingZeros(value - 1))

  private[HashRingBuffer] val HexChars = "0123456789abcdef".toCharArray

  def apply(capacity: Int) =
    new HashRingBuffer(capacity)
}

final class HashRingBuffer private (capacity: Int, buffer: Array[Hash]) { //self =>
  private var tail: Long = 0L
  private var head: Long = 0L

  private def this(capacity: Int) =
    this(HashRingBuffer.nextPowerOfTwo(capacity), Array.ofDim[Hash](HashRingBuffer.nextPowerOfTwo(capacity)))

  def add(hash: Hash): Unit =
    :+(hash)

  def :+(hash: Hash): Unit = {
    val wrapPoint = tail - capacity
    if (head <= wrapPoint)
      head = head + 1

    val ind = (tail % capacity).toInt
    buffer(ind) = hash
    tail = tail + 1

    println(s"$head:$tail - ${toHex(hash)}")
  }

  /*def contains(hash: Hash): Boolean = {
    var i    = head
    var found = false

    do {
      val candidate = buffer((i % capacity).toInt)
      found = java.util.Arrays.compare(hash, candidate) == 0
      println(s"$i out of $tail = $found ")
      i += 1
    } while (i < tail && !found)

    /*while (i < tail && !found) {
      val candidate = buffer((i % capacity).toInt)
      found = java.util.Arrays.compare(hash, candidate) == 0
      j += 1
      i += 1
    }*/
    found
  }*/

  def toHex(hash: Hash): String = {
    val buf = new StringBuilder(hash.size * 2)
    hash.foreach { byte =>
      buf.append(HexChars((byte & 0xF0) >> 4))
      buf.append(HexChars(byte & 0x0F))
    }
    buf/*.take(7).*/toString()
  }

  private def hexEntries: String =
    if (tail > head) {
      val buf = new StringBuilder((tail - head).toInt * 2)
      var i = head
      do {
        if (i != head) buf.append(",")

        val bytes = buffer((i % capacity).toInt)
        /*bytes.foreach { byte =>
          buf.append(HexChars((byte & 0xF0) >> 4))
          buf.append(HexChars(byte & 0x0F))
        }*/
        buf.append(toHex(bytes))

        i += 1
      } while (i < tail)

      buf.toString()
    } else ""

  def contains(hash: Hash): Boolean = {
    if(tail > head) {

      var i = tail
      var exists = false

      //walk backwards
      do {
        val candidate = buffer((i % capacity).toInt)
        exists = java.util.Arrays.compare(hash, candidate) == 0
        println(s"ind:$i head:$head = $exists ")
        i -= 1
      } while (!exists && i >= head)

      exists
    } else false
  }

  override def toString = s"HRB($head:$tail - [$hexEntries])"
}
