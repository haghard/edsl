package com.example

import akka.actor.{ActorSystem, Scheduler}
import akka.dispatch.ExecutionContexts
import akka.stream.scaladsl.{Sink, Source}

import java.lang.management.ManagementFactory
import java.time.Instant
import java.util.UUID
import com.zaxxer.hikari.{HikariConfig, HikariDataSource}
import slick.dbio.DBIO

import javax.management.{Descriptor, MBeanInfo, ObjectName}
import slick.jdbc.JdbcBackend._
import slick.jdbc.JdbcBackend.Database
import slick.jdbc.TransactionIsolation
import slick.util.AsyncExecutor

import java.util.concurrent.atomic.AtomicLong
import concurrent.duration._
import scala.collection.immutable.HashSet
import scala.concurrent.{Await, ExecutionContext, Future, Promise}
import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.forkjoin.ThreadLocalRandom
import scala.util.{Failure, Success, Try}
import scala.util.control.NonFatal

//https://github.com/slick/slick/issues/1801

//runMain com.example.Main
object Main extends App {


  val t = 10.seconds

  val sys = ActorSystem("temp")

  sys.scheduler

  //https://www.playframework.com/documentation/2.8.x/PlaySlickAdvancedTopics#Connection-Pool
  //https://github.com/brettwooldridge/HikariCP/wiki/About-Pool-Sizing
  //https://scala-slick.org/doc/3.1.0/database.html#database-thread-pool
  //https://scala-slick.org/doc/3.2.1/sql.html
  //https://github.com/playframework/play-slick/blob/c327bd24fbb6fbf3a745481c4fd180bdfd9ddbea/docs/manual/working/scalaGuide/main/sql/slick/PlaySlick.md
  //https://www.playframework.com/documentation/2.8.x/PlaySlickAdvancedTopics#Connection-Pool


  //https://gitter.im/slick/slick?at=5a68a64f5a9ebe4f75cb8726

  /*
    https://queirozf.com/entries/slick-3-reference-and-examples
    https://github.com/slick/slick/tree/master/slick-testkit/src/test/scala/slick/test

    https://doc.akka.io/docs/akka/2.3/general/actor-systems.html#Blocking_Needs_Careful_Management
    https://www.youtube.com/watch?v=tC-joPMPJLs

    http://scala-slick.org/doc/3.3.1/queries.html#updating
    http://scala-slick.org/doc/2.1.0/queries.html

    https://scala-slick.org/doc/3.1.0/database.html#database-thread-pool

    https://github.com/brettwooldridge/HikariCP/wiki/About-Pool-Sizing
  */

  //Axiom: You want a small pool, saturated with threads waiting for connections
  //connections = ((core_count * 2) + effective_spindle_count)
  //the minimum size of the connection pool should also be set to the thread pool
  val conPoolSize = Runtime.getRuntime.availableProcessors() * 2

  val slickExecutorName = "slick3"
  val slickExecutor: AsyncExecutor =
    //AsyncExecutor("slick", numThreads = conPoolSize, queueSize = 128)
    //AsyncExecutor.default()
    AsyncExecutor(slickExecutorName, minThreads = conPoolSize, maxThreads = conPoolSize, queueSize = 32,
      maxConnections = conPoolSize, keepAliveTime = 1.minute, registerMbeans = true)

  //AsyncExecutor.default("db-ops") apply(name, 20, 1000)

  //You want a small pool of a few dozen connections at most, and you want the rest of the application threads blocked on
  // the pool awaiting connections.
  // If the pool is properly tuned it is set right at the limit of the number of queries the database is capable of processing
  // simultaneously -- which is rarely much more than (CPU cores * 2) as noted above.


  //dsConf.setJdbcUrl(s"jdbc:h2:./db/gantt;DB_CLOSE_DELAY=-1;INIT=RUNSCRIPT FROM '$script'")
  //dsConf.setUsername("sa")
  //dsConf.setPassword(password)

  val dsConf = new HikariConfig()
  dsConf.setJdbcUrl("jdbc:h2:mem:demoDb;DB_CLOSE_DELAY=-1;DEFAULT_LOCK_TIMEOUT=5000") //LOCK_TIMEOUT
  dsConf.setDriverClassName("org.h2.Driver")
  dsConf.setConnectionTimeout(3000)
  dsConf.setMaximumPoolSize(conPoolSize)
  dsConf.setIdleTimeout(1.minute.toMillis)
  //TRANSACTION_READ_COMMITTED, TRANSACTION_SERIALIZABLE, TRANSACTION_READ_COMMITTED, TRANSACTION_REPEATABLE_READ (SI), TRANSACTION_SERIALIZABLE
  dsConf.setTransactionIsolation("TRANSACTION_REPEATABLE_READ")

  //https://medium.com/@darora8/transaction-isolation-in-postgres-ec4d34a65462
  //slick.jdbc.TransactionIsolation.Serializable
  //slick.jdbc.TransactionIsolation.RepeatableRead

  //dsConf.addDataSourceProperty("cachePrepStmts", "true")
  //dsConf.addDataSourceProperty("prepStmtCacheSize", "10")
  //dsConf.addDataSourceProperty("prepStmtCacheSqlLimit", "1024")
  dsConf

  //dsConf.setTestConnectionOnCheckin(true);

  val dataSrc = new HikariDataSource(dsConf)

  val metrics = new com.codahale.metrics.MetricRegistry()
  dataSrc.setMetricRegistry(metrics)

  implicit val globalMetrics = new MeasuredDatabase(metrics)

  //Thread.sleep(2000)

  //Database.forURL()

  //maxConnections - The maximum number of connections that the DataSource can provide. This is necessary to
  //prevent deadlocks when scheduling database actions. Use `None` if there is no hard limit.
  val db: DatabaseDef = Database.forDataSource(ds = dataSrc, maxConnections = Some(conPoolSize), executor = slickExecutor)

  //val db: DatabaseDef = Database.forURL("jdbc:h2:mem:example123;DB_CLOSE_DELAY=-1", driver = "org.h2.Driver")

  val repo = PeopleRepo(db) //slick.jdbc.H2Profile, H2Driver

  val id = UUID.fromString("88b8bab5-a5d4-4be6-99d5-a5fd7f6bb436")
  val id1 = UUID.randomUUID()
  val p = PersonRow(Some(id), "John", "Doe", Instant.now())
  val p1 = PersonRow(Some(id1), "John", "Doe", Instant.now())

  val mbeanName   = new ObjectName(s"slick:type=AsyncExecutor,name=$slickExecutorName")
  val mbeanServer = java.lang.management.ManagementFactory.getPlatformMBeanServer

  val exists      = mbeanServer.isRegistered(mbeanName)
  if(exists) {
    val beanInfo: MBeanInfo = mbeanServer.getMBeanInfo(mbeanName)
    //val size = beanInfo.getAttributes.size
    println("*************** BeanInfo: " + beanInfo + " : " + mbeanName)
    println(beanInfo.getAttributes.size)

    beanInfo.getAttributes.foreach { attr =>
      val name = attr.getName
      println("***************")
      println(name + " : " + mbeanServer.getAttribute(mbeanName, name).asInstanceOf[Int])
      println("***************")
    }
  } else println(s"****** Not found: ${mbeanName.toString} *********")

  /*
  BeanInfo: javax.management.MBeanInfo[
  description=Information on the management interface of the MBean,

  attributes=[
    javax.management.MBeanAttributeInfo[
      description=MaxQueueSize, name=MaxQueueSize, type=int, read-only,
      descriptor={openType=javax.management.openmbean.SimpleType(name=java.lang.Integer), originalType=int}
    ],
    javax.management.MBeanAttributeInfo[
     description=MaxThreads, name=MaxThreads, type=int, read-only, descriptor={openType=javax.management.openmbean.SimpleType(name=java.lang.Integer), originalType=int}],

    javax.management.MBeanAttributeInfo[
     description=ActiveThreads, name=ActiveThreads, type=int, read-only, descriptor={openType=javax.management.openmbean.SimpleType(name=java.lang.Integer), originalType=int}],

    javax.management.MBeanAttributeInfo[
     description=QueueSize, name=QueueSize, type=int, read-only, descriptor={openType=javax.management.openmbean.SimpleType(name=java.lang.Integer), originalType=int}]], constructors=[javax.management.MBeanConstructorInfo[description=Public constructor of the MBean, name=slick.util.AsyncExecutor$$anon$2$$anon$5, signature=[javax.management.MBeanParameterInfo[description=, name=p1, type=slick.util.AsyncExecutor$$anon$2, descriptor={}],

    javax.management.MBeanParameterInfo[
     description=, name=p2, type=java.util.concurrent.BlockingQueue, descriptor={}]], descriptor={}]], operations=[], notifications=[], descriptor={immutableInfo=true, interfaceClassName=slick.util.AsyncExecutorMXBean, mxbean=true}]
  */

  /*
  println("MaxQueueSize: " + mbeanServer.getAttribute(mbeanName, "MaxQueueSize"))
  println("MaxThreads: " + mbeanServer.getAttribute(mbeanName, "MaxThreads"))
  println("ActiveThreads: " + mbeanServer.getAttribute(mbeanName, "ActiveThreads"))
  println("QueueSize: " + mbeanServer.getAttribute(mbeanName, "QueueSize"))
  */

  /*for {
    _ <-  repo.noop() // repo.insert(p)
    newRow = if(ThreadLocalRandom.current().nextDouble() < .5) PersonRow(Some(UUID.randomUUID()), "000", "000", Instant.now())
    else return repo.noop()
    r <- repo.insert(p)
  } yield r*/

  val cnt = new AtomicLong(8)

  def fetch(id: UUID, id1: UUID, c: Promise[Unit]): Future[_] =
    repo.findByIds(id, id1).flatMap { _ =>
      if(cnt.decrementAndGet() == 0)
        Future.successful(c.trySuccess(()))
      else
        Future.successful(Thread.sleep(4000)).flatMap(_ => repo.update3(id)).flatMap(_ => fetch(id, id1, c))
    }

  val Decider: PartialFunction[Throwable, Unit] = {
    case ex: IllegalStateException => ()
  }

  val f = repo.createSchema
    .flatMap { _ =>
      //Thread.sleep(2000)
      repo.insert(p).zip(repo.insert(p1)).flatMap { _ =>

        //val c = Promise[Unit]()
        //fetch(p.id.get, p1.id.get, c)

        println("2")

        repo.updateByIds(
          p.id.get,
          p1.id.get,
          //repo.findByTag(_)
        ).recover { case NonFatal(ex) =>
          println("******************************* UpdateByIds.Failure ***")
          ex.printStackTrace()
          //c.trySuccess(())
          1
        }
        .flatMap { _ =>
          Thread.sleep(10000)
          //repo.findByIds(p.id.get, p1.id.get)

          println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" + Decider.isDefinedAt(new IllegalStateException("Boom !!!")))

          repo.retryWithDelay(
            repo.findById(UUID.randomUUID()).map(_.getOrElse(throw new IllegalStateException("Boom !!!"))),
            retrySideEffect = {
              println("*******************Retry**************")
            },
            decider = Decider
          )(scala.concurrent.ExecutionContext.Implicits.global, sys.scheduler)

          /*repo.waitForCondition(
            repo.findById(UUID.randomUUID()),
            successCondition = { maybeRow: Option[PersonRow] => maybeRow.isDefined },
            abortCondition = { _ => false },
            retries = 3,
            retryInterval = 300.millis,
            label = ""
          )(scala.concurrent.ExecutionContext.Implicits.global, sys.scheduler)*/

          /*repo.fetchWithRetry(
            repo.findById(UUID.randomUUID()),
            new IllegalStateException("Boom !!!")
          )(scala.concurrent.ExecutionContext.Implicits.global, sys.scheduler)*/

          //repo.findByTagF("aaa").flatMap(_ => repo.findByTag2("bbb") )
        }
        //.flatMap { _ => repo.findByIds(id, id1).flatMap(_ => c.future) }
        //.flatMap { _ => repo.findByIds(p.id.get, p1.id.get) }
      }
      /*.withLatencyLogging("repo insert")*/
    }
    /*.flatMap(_ => repo.findById(id))
    .flatMap(_ => repo.findById(id))
    .flatMap(_ => repo.findByRegDate(later))
    .flatMap(_ => repo.updateById(id, p.copy(registrationTime = later/*Instant.now()*/)))
    .flatMap(_ => repo.findByRegDate(later))*/

  Await.result(f, Duration.Inf)
  //println(s"****************  Metrics: ${globalMetrics.readSnapshot.size()}  *************************")


  dataSrc.close()

}
