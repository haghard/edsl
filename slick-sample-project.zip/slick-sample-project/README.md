# slick-sample-project
Sample project with Scala and Slick
[![Build Status](https://travis-ci.org/fancywriter/slick-sample-project.svg?branch=master)](https://travis-ci.org/fancywriter/slick-sample-project)
